/*****************************************************************
      FORTRAN interface to get user-time and real time on
      AIX-system might work on other UNIX systems as well
      (must work on all BSDish systems and SYSVish systems
      with BSD-compatibility timing routines ...)!?
*****************************************************************/

#ifndef DCLOCK_H

#define DCLOCK_H

void vtime(double &,double &);

#endif
