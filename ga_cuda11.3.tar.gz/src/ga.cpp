#include <stdlib.h>
#include <sstream>
#include <iostream>
#include <fstream>
#include <math.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <algorithm>
#include <vector>
#include <list>
#include <iomanip>


#include "seqlist.h"
#include "struc_gen.h"
#include "interface_gen.h"
#include "ga.h"
#include "randomlib.h"
#include "mpi.h"
#include "dclock.h"
using namespace std;

#ifdef MY_LAMMPS
// LAMMPS include files
#include "lammps.h"
#include "input.h"
#include "atom.h"
#include "domain.h"
#include "modify.h"
#include "library.h"
#include "thermo.h"
#include "output.h"
#include "random_park.h"
#include "group.h"
#include "compute.h"
#include "fix.h"
#include "fix_box_relax.h"
#include "compute_temp.h"


using namespace LAMMPS_NS;


void ilammps_input(GAPara ga_info,int temp_nions, int temp_type){
	fstream fout;
	fstream fin("./ilmp.in",ios::in);
	if(fin && ga_info.ilmpin) {fin.close();return;}
	fin.close();
	fout.open("./ilmp.in",ios::out);
	fout << "# initialize lammps" << endl;
	fout << "units           metal" << endl;
	fout << "boundary        p p p" << endl;
	if(ga_info.lj_eam == 3)
		fout << "atom_style      charge" << endl;
	else
		fout << "atom_style      atomic" << endl;
	fout << "atom_modify     map array" << endl;
	fout << "lattice         custom 3.6150 a1 1 0 0 a2 0.1 1 0 a3 0.1 0.1 1 basis 0 0 0 basis 0.5 0.5 0.5" << endl;
	fout << "variable xtemp equal temp" << endl; //to check temperature
	fout << "region box prism 0 10 0 10 0 10 2 0 0" << endl;
	temp_type = temp_type > ga_info.ntype-1 ? temp_type: ga_info.ntype-1;
	fout << "create_box    " <<  temp_type << " box" << endl;
	for(int i = 1; i <= temp_type;i++)
		fout << "mass "<< i  <<  "   " << ga_info.amass[i] << endl;
	fout << "group all region box" << endl;
	fout << "create_atoms 1 single 0 0 0" << endl;
	fout << "region zero block 0 0.001 0 0.001  0 0.001" << endl;
	fout << "group jm region zero" << endl;

	//one more region for fixed atoms
	fout << "create_atoms 1 single 0.21 0.21 0.21" << endl;
	fout << "create_atoms 1 single 0.22 0.22 0.22" << endl;
	fout << "region one_x block 0.2 0.3 0.2 0.3 0.2 0.3 " << endl;
	fout << "group xm region one_x" << endl;

	fout << "thermo_modify lost ignore" << endl;
	fout << "min_style cg" << endl;
	fout << "min_modify dmax 0.01" << endl; 
	fout << "neighbor        1.0 bin" << endl;
	fout << "neigh_modify    every 1 delay 5 check yes" << endl;
	switch (ga_info.cellfree){
		case 0:
			if(ga_info.nfixedt !=0 && ga_info.movetop)
				fout << "fix 1 all temp/rescale 1 20.0 0.0001 0.00005 1.0" << endl;
			else
				fout << "fix  1 all nve " << endl;
			break;
		case 1:
			fout << "fix  1 all box/relax iso " << ga_info.press*1000 << " vmax 0.001" << endl; break;
		case 2:
			fout << "fix  1 all box/relax aniso " << ga_info.press*1000 << " vmax 0.001" << endl; break;
		case 3:
			if(ga_info.dimen == 2){
				fout << "fix  1 all box/relax x 0 y 0 xy 0 vmax 0.001" << endl;
				fout << "fix  3 all setforce NULL NULL 0.0" << endl;
				break;
			}
			if(ga_info.lj_eam == 3 && ga_info.mdsteps != 0){ // coul potential and md are used
				fout << "fix  1 all temp/rescale 1 20.0 0.0001 0.00005 1.0" << endl;
			}else
				fout << "fix  1 all box/relax tri " << ga_info.press*1000 << " vmax 0.001" << endl; break;
		default:
			fout << "fix  1 all nve " << endl; break;
	}
	if(ga_info.systype!=1){  //if not search for clusters 
		fout << "fix  2 jm    setforce 0.0 0.0 0.0" << endl;
	}

	if(ga_info.systype==2){  //search for interface 
		if(!ga_info.movetop) fout << "fix 3 xm setforce 0.0 0.0 0.0" << endl;
	}

	fout.close();
}

int Init_lammps(char *filename,LAMMPS *lmp,MPI_Comm comm_lammps){
	// open LAMMPS input script
	FILE *fp;
	int me;
	MPI_Comm_rank(comm_lammps,&me);
	if (me == 0) {
 		fp = fopen(filename,"r");
 		if (fp == NULL) {
		printf("ERROR: Could not open LAMMPS input script\n");
		MPI_Abort(comm_lammps,1);
  		}
	}

	// run the input script thru LAMMPS one line at a time until end-of-file
	char line[1024]; int nn;
	while (1) {
		if (me == 0) {
	    		if (fgets(line,1024,fp) == NULL) nn = 0;
		    	else nn = strlen(line) + 1;
	    		if (nn == 0) fclose(fp);
	  	}
	  	MPI_Bcast(&nn,1,MPI_INT,0,comm_lammps);
	  	if (nn == 0) break;
	  	MPI_Bcast(line,nn,MPI_CHAR,0,comm_lammps);
		//cout << line << endl;
	  	lmp->input->one(line);
	}


	return static_cast<int> (lmp->atom->natoms);
}

void Pot_Substrate(LAMMPS *lammps, int temp_type){
	lammps->input->one("pair_style none");
	lammps->input->one("pair_style hybrid tersoff");
	lammps->input->one("pair_coeff * * tersoff Si.tersoff Si Si Si Si");
	lammps->input->one("pair_coeff 1 4 none");
	lammps->input->one("pair_coeff 2 4 none");
	lammps->input->one("pair_coeff 3 4 none");
	lammps->input->one("pair_coeff 4 4 none");
}

void Init_lammps(LAMMPS *lammps,int nions, double *pos,int movetop){

	char str1[]="create_atoms ";
	char str2[]=" single 0.5 0.5 0.5 ";
	char str3[]=" single 0.0 0.0 0.0 ";
	//for fixed atoms(top)
	char str4[]=" single 0.2 0.2 0.2 ";

	char command[256];
	lammps->input->one("lattice none 1.0");
	lammps->input->one("region box delete");
	lammps->input->one("region zero delete");
	lammps->input->one("region one_x delete");

	//new region
	lammps->input->one("lattice  custom 3.6150 a1 1 0 0 a2 0.1 1 0 a3 0.1 0.1 1 basis 0 0 0");
	lammps->input->one("region box prism 0 10 0 10 0 10 2 0 0");
	lammps->input->one("delete_atoms group all");
        lammps->domain->boxlo[0] = lammps->domain->boxlo[1] = lammps->domain->boxlo[2] = 0;
        lammps->domain->boxhi[0] = 43.38;
        lammps->domain->boxhi[1] = 39.765;
        lammps->domain->boxhi[2] = 36.15;
        lammps->domain->xy = 8.676; lammps->domain->xz = 0.0; lammps->domain->yz = 0.0;
        lammps->domain->set_global_box();
        lammps->domain->set_local_box();

//	lammps->input->one("reset_timestep 0");
	for(int i = 0;i < nions;i++){
		if(pos[i*4+3]==0)continue;
		if( (int)(pos[i*4+3]/10) == 0){
			sprintf(command,"%s %d",str1,(int)pos[i*4+3]);
			strcat(command,str2);
		}
		else if( (int)(pos[i*4+3]/20) == 0){
			sprintf(command,"%s %d",str1,(int)pos[i*4+3]%10);
			strcat(command,str3);
		}
		else{
			sprintf(command,"%s %d",str1,(int)pos[i*4+3]%10); 
			if(movetop) strcat(command, str4);
			else strcat(command,str3);
		}
		lammps->input->one(command);
	}
	lammps->input->one("region zero block 0 0.001 0 0.001  0 0.001");

	//new region  -- creat for interface 
	lammps->input->one("region one_x block 0.2 0.3 0.2 0.3 0.2 0.3");
	lammps->input->one("group xm region one_x");
	lammps->input->one("group jm region zero");
	lammps->input->one("group all region box");
}

void Cal_Pool_Energy_lammps(double *latt, double *pos, double *ene, double *force, double *stress, double *press, int *struc_id, GAPara ga_info, 
		LAMMPS *lammps,int pool_id, MPI_Comm comm_intra,MPI_Comm comm_inter,double *latt_template, double *pos_template,
                double *latt_fixedt, double *latt_fixedb, double *latt_bufft, double *latt_buffb,
                double *pos_fixedt, double *pos_fixedb, double *pos_bufft, double *pos_buffb, double *vec_fixedt){
	int new_nions;
	new_nions = ga_info.nions+ga_info.temp_nions+ga_info.tmpatoms;
	double mintopz; 
	int n_badstr=0;  // # of bad structures, for interface

	int rank,grank,pool_status,images;
	int atom_type[10],ntype;
	char filename[6],potfile[64], mdcommand[100];
	double *newpos = new double [new_nions*4];
	double *oldpos = new double [new_nions*4];
	double *newforce = new double [new_nions*4];
	double *newlatt = new double [12],step,volume;
	double bondlen;
	Posion **postmp = new Posion*[1],**latvec = new Posion*[1];
	postmp[0] = new Posion[new_nions];
	latvec[0] = new Posion[3];
	MPI_Comm_size(comm_inter,&images);
        MPI_Comm_rank(comm_inter,&grank);
        MPI_Comm_rank(comm_intra,&rank);

        double *latt_tmp  = new double[4*3*ga_info.NPOOL];
        double *force_tmp = new double[4*ga_info.nions*ga_info.NPOOL]; // 3 for coordination 1 for atom type
        double *pos_tmp   = new double[4*ga_info.nions*ga_info.NPOOL]; // 3 for coordination 1 for atom type
        double *stress_tmp= new double[6*ga_info.NPOOL]; // 3 for coordination 1 for atom type
        double *ene_tmp   = new double[ga_info.NPOOL];
        double *press_tmp = new double[ga_info.NPOOL];
	double *vec_tmp = new double[3*ga_info.NPOOL];   //for interface/surface
	MPI_Bcast(latt,12*ga_info.NPOOL,MPI_DOUBLE,0,MPI_COMM_WORLD);
        MPI_Bcast(pos,4*ga_info.nions*ga_info.NPOOL,MPI_DOUBLE,0,MPI_COMM_WORLD);
	MPI_Bcast(force,4*ga_info.nions*ga_info.NPOOL,MPI_DOUBLE,0,MPI_COMM_WORLD);
	MPI_Bcast(ene,ga_info.NPOOL,MPI_DOUBLE,0,MPI_COMM_WORLD);
	MPI_Bcast(press,ga_info.NPOOL,MPI_DOUBLE,0,MPI_COMM_WORLD);
	MPI_Bcast(vec_fixedt, 3*ga_info.NPOOL, MPI_DOUBLE, 0, MPI_COMM_WORLD);

	memcpy (latt_tmp, latt, sizeof(double)*ga_info.NPOOL*12);
	memcpy (pos_tmp,  pos,  sizeof(double)*ga_info.NPOOL*4*ga_info.nions);
	memcpy (force_tmp,  force,  sizeof(double)*ga_info.NPOOL*4*ga_info.nions);
	memcpy (ene_tmp,        ene,        sizeof(double)*ga_info.NPOOL);
	memcpy (press_tmp,      press,      sizeof(double)*ga_info.NPOOL);
	memcpy (vec_tmp, vec_fixedt, sizeof(double)*ga_info.NPOOL*3);
	double vputim_0,cputim_0,vputim,cputim;
        double timer; 
        int maxiter;
	int cur_pot=0,new_comp=0;
	int offset;

	sprintf(potfile,"%s","pot.in");
	for(int i = 0; i < ga_info.NPOOL; i++){
		offset = 4*i*ga_info.nions;
                if(i%images != pool_id ){
			for(int j = 0; j < 4*ga_info.nions; j++) {
				pos_tmp[offset+j] = 0.0;
				force_tmp[offset+j] = 0.0;
			}
			for(int j = 0; j < 12; j++) latt_tmp[12*i+j] = 0.0;
			for(int j = 0; j < 6; j++)  stress_tmp[6*i+j] = 0.0;
			ene_tmp[i] = 0.0;
			press_tmp[i] = 0.0;
			for(int j=0; j<3; j++) vec_tmp[3*i+j] = 0.0;     // for interface/surface
                        continue;
                } else if (ene_tmp[i] != ENENONE) continue;

		if(ga_info.systype == 2)
			Merge_interface(pos_tmp+offset,pos_fixedt, pos_fixedb, pos_bufft, pos_buffb, oldpos, latt_tmp+i*12, latt_fixedt, latt_fixedb, latt_bufft, latt_buffb, newlatt, vec_tmp+3*i, ga_info);
		else Merge_template(pos_tmp+offset, pos_template, oldpos,latt_tmp+i*12,latt_template,newlatt,ga_info.nions,ga_info.temp_nions);

		// determing composition
		for(int j = 0; j < 10; j++) atom_type[j]=0;
		for(int j = 0; j < ga_info.nions; j++){
			atom_type[((int)oldpos[j*4+3])%10]++;
		}

		ntype=(int)oldpos[ga_info.nions*4-1]%10+1;

		// for seletive dynamics 1 -- fixed
		if (ga_info.temp_nions == 0 && ga_info.tmpatoms == 0)
			oldpos[4*atom_type[0]+3] += 10;
		Init_lammps(lammps,new_nions,oldpos,ga_info.movetop);

		if (ga_info.temp_nions == 0 && ga_info.tmpatoms == 0)
			oldpos[4*atom_type[0]+3] -= 10;

		Init_lammps(potfile,lammps,comm_intra);
		// Input the lattice and coordinate
		ilammps_put_lattice(lammps,newlatt);
		ilammps_put_coords(lammps,oldpos+4*atom_type[0]);          // no LAMMPS class function for this
		if(ga_info.GABH == 0 || ga_info.GABH == 2) {
			lammps->input->one("reset_timestep 0");

			if(ga_info.nfixedt !=0 && ga_info.movetop == 1){
				sprintf(mdcommand,"%s%d","run ",ga_info.mdsteps);
			        vtime(vputim_0,cputim_0);
				lammps->input->one("fix 21 all nve/limit 0.2");
				lammps->input->one("fix 22 xm rigid/nve single force * on on on torque * off off off");
				lammps->input->one(mdcommand);

				vtime(vputim,cputim);
				timer = vputim-vputim_0;

			}else if(ga_info.lj_eam == 3 && ga_info.mdsteps != 0){ //if coul potential used
				sprintf(mdcommand,"%s%d","run ",ga_info.mdsteps);
			        vtime(vputim_0,cputim_0);
				lammps->input->one("fix 21 all nve/limit 0.2");
				lammps->input->one(mdcommand);
				vtime(vputim,cputim);
				timer = vputim-vputim_0;
			}else{
			        vtime(vputim_0,cputim_0);
				lammps->input->one("minimize 0 1.0e-3 1000 1000");
				lammps->input->one("minimize 0 1.0e-4 50000 50000"); // by tang
				vtime(vputim,cputim);
				timer = vputim-vputim_0;
			}
		}else if(ga_info.GABH == 1){
			if(ga_info.nfixedt !=0 && ga_info.movetop == 1){
				sprintf(mdcommand,"%s%d","run ",ga_info.mdsteps);
			        vtime(vputim_0,cputim_0);
				lammps->input->one(mdcommand);
				vtime(vputim,cputim);
				timer = vputim-vputim_0;
			}else{
				lammps->input->one("minimize 0 1.0e-6 2000 2000");
				lammps->input->one("reset_timestep 0");
				ilammps_put_velocity(lammps, ga_info.temp);
				lammps->input->one("velocity relax zero linear");
				lammps->input->one("run 200");
				lammps->input->one("minimize 0 1.0e-6 2000 2000");
			}
		}
//		lammps->output->thermo->evaluate_keyword("enthalpy",ene+i);
//		lammps->input->one("compute 1 all bond/local dist");
		if(ga_info.fixsite==0){
			ilammps_get_coords(lammps,newpos+4*atom_type[0]);
			ilammps_get_lattice(lammps,latt_tmp+i*12);          
			for(int x=0; x<4*atom_type[0]; x++)
				newpos[x] = 0;
		}else
			for(int j = 0; j < 4*new_nions; j++) newpos[j] = oldpos[j];
		double *tempx = (double *)lammps_extract_variable(lammps, "xtemp", NULL);
		lammps->output->thermo->evaluate_keyword("press",press_tmp+i);
		lammps->output->thermo->evaluate_keyword("step",&step);
		lammps->output->thermo->evaluate_keyword("vol",&volume);
		stress_tmp[6*i+0]=stress_tmp[6*i+1]=stress_tmp[6*i+2]=stress_tmp[6*i+3]=stress_tmp[6*i+4]=stress_tmp[6*i+5]=0.0;
		lammps->output->thermo->evaluate_keyword("enthalpy",ene_tmp+i);
		press_tmp[i] /= 1000;
		if(ga_info.press==0.0){
			lammps->output->thermo->evaluate_keyword("pe",ene_tmp+i);
			//if( fabs(press_tmp[i]) > 1000.0) ene_tmp[i]=ENENONE;
		}else
			if( fabs(press_tmp[i] - ga_info.press) > 500.0 ) ene_tmp[i]=ENENONE;
		ilammps_get_force(lammps,newforce);      
		//Remove bad struture
                if (fabs(ene_tmp[i]) > 100000) {
                        cout << "one structure wrong  "<< struc_id[i] <<"  "<< ene_tmp[i] << "  " << volume <<endl;
                        ene_tmp[i]=ENENONE;
                }

		for(int j = 0; j < ga_info.nions; j++) newpos[j*4+3] = pos_tmp[offset+4*j+3];
		for(int j = 0; j < new_nions; j++){ 
			if(oldpos[j*4+3]>=10 && oldpos[j*4+3]<20) 
				for(int jj = 0; jj < 4; jj++) newpos[j*4+jj] = oldpos[j*4+jj];
			else if(oldpos[j*4+3]>=20)
				newpos[j*4+3] = oldpos[j*4+3];
		}

                if(ga_info.systype == 2){
			mintopz=Split_interface(newpos, pos_fixedt, pos_fixedb, pos_bufft, pos_buffb, pos_tmp+offset, latt_tmp+i*12, latt_bufft, latt_buffb, latt_fixedb[10], vec_tmp+3*i, ga_info);
			if(ga_info.movetop){
				if(mintopz > *(latt_tmp+i*12+10)+5.0 || mintopz < *(latt_tmp+i*12+10)-2.0){
					if(rank == 0){
//						cout << "min(z of top atoms) = " << mintopz << " ,while lattz(interface) = " << *(latt_tmp+i*12+10) << " --> deleted " << struc_id[i] << endl;
						n_badstr++;
					}
					ene_tmp[i]=ENENONE;
				}
			}
                        Remove_template(newforce,force_tmp+offset,ga_info.nions);
                }
                else{
                        Remove_template(newpos,pos_tmp+offset,ga_info.nions);
                        Remove_template(newforce,force_tmp+offset,ga_info.nions);
                }

	        if(rank == 0){
//			Convert_structure(newpos,postmp,1,new_nions); 
			if(ga_info.fixsite==0)
                        	Convert_structure(newpos,force_tmp+offset, postmp,1,new_nions); 
			else
                        	Convert_structure(oldpos,force_tmp+offset, postmp,1,new_nions); 
                       	Convert_structure(latt_tmp+i*12,latvec,1,3);
			Get_Type(postmp[0],new_nions,atom_type,ga_info.ntype);
			if(pool_id==0) {
				volume = latvec[0][0].x*latvec[0][1].y*latvec[0][2].z;
				cout << pool_id << " done " << struc_id[i] << ' ' << ene_tmp[i] << ' ' << press_tmp[i] << " " << *tempx
				<< ' ' << int(step) << ' '<< volume << ' ' << Check_bond(latvec[0],postmp[0],ga_info.nions) << ' ' << timer << endl;
			}
		}
	}

	MPI_Allreduce(pos_tmp, pos, ga_info.NPOOL*ga_info.nions*4,MPI_DOUBLE,MPI_SUM,comm_inter);
	MPI_Allreduce(latt_tmp,latt,ga_info.NPOOL*12,     MPI_DOUBLE,MPI_SUM,comm_inter);
	MPI_Allreduce(force_tmp, force, ga_info.NPOOL*ga_info.nions*4,MPI_DOUBLE,MPI_SUM,comm_inter);
	MPI_Allreduce(stress_tmp, stress, ga_info.NPOOL*6,MPI_DOUBLE,MPI_SUM,comm_inter);
	MPI_Allreduce(ene_tmp       ,ene,       ga_info.NPOOL,        MPI_DOUBLE,MPI_SUM,comm_inter);
	MPI_Allreduce(press_tmp     ,press,     ga_info.NPOOL,        MPI_DOUBLE,MPI_SUM,comm_inter);
	MPI_Allreduce(vec_tmp, vec_fixedt, 3*ga_info.NPOOL, MPI_DOUBLE, MPI_SUM, comm_inter);  //for interface/surface
	delete[] latt_tmp;
	delete[] pos_tmp;
	delete[] force_tmp;
	delete[] ene_tmp;
	delete[] press_tmp;
	delete[] stress_tmp;
	delete[] vec_tmp;
}

void ilammps_put_lattice(void *ptr, double *latt){
	LAMMPS *lammps = (LAMMPS *) ptr;
	lammps->domain->boxlo[0] = 0;
	lammps->domain->boxlo[1] = 0;
	lammps->domain->boxlo[2] = 0;
	lammps->domain->boxhi[0] = latt[0];
	lammps->domain->boxhi[1] = latt[5];
	lammps->domain->boxhi[2] = latt[10];

	lammps->domain->yz = latt[9];
  	lammps->domain->xz = latt[8];
  	lammps->domain->xy = latt[4];
	lammps->domain->set_global_box();
	lammps->domain->set_local_box();

}

void ilammps_get_lattice(void *ptr, double *latt){
	LAMMPS *lammps = (LAMMPS *) ptr;
	latt[0] = lammps->domain->boxhi[0]
	         -lammps->domain->boxlo[0];
	latt[5] = lammps->domain->boxhi[1]
	         -lammps->domain->boxlo[1];
	latt[10]= lammps->domain->boxhi[2]
	         -lammps->domain->boxlo[2];
	latt[9] = lammps->domain->yz;
	latt[8] = lammps->domain->xz;
	latt[4] = lammps->domain->xy;
}

void ilammps_get_force(void *ptr, double *coords){
	LAMMPS *lammps = (LAMMPS *) ptr;
	int natoms = static_cast<int> (lammps->atom->natoms);
	double *copy = new double[4*natoms];
	for (int i = 0; i < 4*natoms; i++) copy[i] = 0.0;
	double **f = lammps->atom->f;
	int *tag = lammps->atom->tag;
	int nlocal = lammps->atom->nlocal;

	int id,offset;
	for (int i = 0; i < nlocal; i++) {
		id = tag[i];
		offset = 4*(id-1);
		copy[offset+0] = f[i][0];
		copy[offset+1] = f[i][1];
		copy[offset+2] = f[i][2];
	}
	MPI_Allreduce(copy,coords,4*natoms,MPI_DOUBLE,MPI_SUM,lammps->world);
	delete [] copy;
}

void ilammps_put_velocity(void *ptr, double t_desired ){
	// t_desired in K
	LAMMPS *lammps = (LAMMPS *) ptr;
	double **v = lammps->atom->v;
	int nlocal = lammps->atom->nlocal;
	int *type = lammps->atom->type;
	int *mask = lammps->atom->mask;
	double *mass = lammps->atom->mass;
	double *rmass = lammps->atom->rmass;
	int dimension = lammps->domain->dimension;
	int m;
	double vx,vy,vz,factor;
	double boltz = 8.617343e-5;
	double UL =1E-10;
	double UT =1E-12;
	double AMTOKG=1.6605402E-27;
	double EVTOJ=1.60217733E-19;
	double FACT= (AMTOKG/EVTOJ)*(UL/UT)*(UL/UT);

	int igroup = lammps->group->find("relax");
	int groupbit = lammps->group->bitmask[igroup];

	int natoms = static_cast<int> (lammps->atom->natoms);

	for (int i = 1; i <= natoms; i++) {
		m = lammps->atom->map(i);
		if (m >= 0 && m < nlocal) {
			if (mask[m] & groupbit) {
				if (mass) factor = 1.0/sqrt(mass[type[m]]);
				else factor = 1.0/sqrt(rmass[m]);
				factor = sqrt(t_desired*boltz/FACT)*factor;
				v[m][0] = RandomGaussian(0.0,factor);
				v[m][1] = RandomGaussian(0.0,factor);
				v[m][2] = RandomGaussian(0.0,factor);
			}
		}
	}
}

void ilammps_get_coords(void *ptr, double *coords){
	LAMMPS *lmp = (LAMMPS *) ptr;

	// error if tags are not defined or not consecutive

	if (lmp->atom->tag_enable == 0 || lmp->atom->tag_consecutive() == 0) return;
	if (lmp->atom->natoms > MAXSMALLINT) return;

	int natoms = static_cast<int> (lmp->atom->natoms);
	double *copy = new double[4*natoms];
	for (int i = 0; i < 4*natoms; i++) copy[i] = 0.0;

	double **x = lmp->atom->x;
	int *tag = lmp->atom->tag;
	int nlocal = lmp->atom->nlocal;

	int id,offset;
	for (int i = 0; i < nlocal; i++) {
		id = tag[i];
		offset = 4*(id-1);
		copy[offset+0] = x[i][0];
		copy[offset+1] = x[i][1];
		copy[offset+2] = x[i][2];
	}

	MPI_Allreduce(copy,coords,4*natoms,MPI_DOUBLE,MPI_SUM,lmp->world);
	delete [] copy;
}

void ilammps_put_coords(void *ptr, double *coords){
	LAMMPS *lmp = (LAMMPS *) ptr;

	// error if no map defined by LAMMPS

	if (lmp->atom->map_style == 0) return;
	if (lmp->atom->natoms > MAXSMALLINT) return;

	int natoms = static_cast<int> (lmp->atom->natoms);
	double **x = lmp->atom->x;

	int m,offset;
	for (int i = 0; i < natoms; i++) {
		if ((m = lmp->atom->map(i+1)) >= 0) {
			offset = 4*i;
			x[m][0] = coords[offset+0];
			x[m][1] = coords[offset+1];
			x[m][2] = coords[offset+2];
		}
	}
}
#endif 

void MY_MPI_SPLIT(int images,MPI_Comm &comm_inter, MPI_Comm &comm_intra,int &pool_id,int &rank, int &grank){
	int nprocs,nprocs_pool,me;
        int ndims=2,dims[2],periods[2],remain_dims[2];
	MPI_Comm comm_pool;
	MPI_Comm_rank(MPI_COMM_WORLD,&me);
	if(me==0)
		cout << "Divide into " << images << " stations" << endl;
	MPI_Comm_size(MPI_COMM_WORLD,&nprocs);
	nprocs_pool = nprocs/images;
	pool_id = me/nprocs_pool;
        dims[0] = images; dims[1] = nprocs_pool;
        periods[0] = periods[1] = 0;
        MPI_Cart_create(MPI_COMM_WORLD,ndims,dims, periods, 0, &comm_pool);
        remain_dims[0] = 1; remain_dims[1] = 0;
        MPI_Cart_sub(comm_pool,remain_dims,&comm_inter);
        remain_dims[0] = 0; remain_dims[1] = 1;
        MPI_Cart_sub(comm_pool,remain_dims,&comm_intra);
	MPI_Comm_rank(comm_intra, &rank);
        MPI_Comm_rank(comm_inter,&grank);
}

int Init_GA_Info(GAPara &ga_info){
	//parameters that should be set up in ga.in
	ga_info.systype = -1;
	ga_info.NPOOL = ga_info.NPOOL_DFT = 0;
	ga_info.NGEN = ga_info.NGEN_DFT = 0;
	ga_info.nions = ga_info.ntype = -1;
	for(int i=0; i<10; i++){
		ga_info.atom_type_min[i] = ga_info.atom_type_max[i] = 0;
	}
	ga_info.criteria = -1.0;

	//parameters with default setting
	ga_info.if_restart = 0;
	ga_info.pwscf = 0;
	ga_info.scale_V = 0;
	ga_info.ilmpin = 0;
	ga_info.e1conv = ga_info.e2conv = 0.00001;
	ga_info.n1conv = 1000;
	ga_info.n2conv = 0;
	ga_info.alldft = 0;
	ga_info.recalce = 0;
	ga_info.cur_id = 100000000;
	ga_info.images = ga_info.images_dft = 999999;
	ga_info.cell_fac = 2.0;
	ga_info.rcut = 1.5;
	ga_info.dkp = 0.05;
	ga_info.GABH = 0;
	for(int i=0; i<10; i++){
		ga_info.amass[i] = 10.0;
		ga_info.c_p[i] = 0.0;
		ga_info.vol[i] = 15.0;
	}
	ga_info.angle_min = 60.0; ga_info.angle_max = 120.0;
	ga_info.press = ga_info.press_dft = 0.0;
	ga_info.cellfree = 3;
	ga_info.lj_eam = 0;
	ga_info.fixsite = 0;
	ga_info.dimen = 3;
	ga_info.ztotal = 20;
	ga_info.zslab = 4;
	ga_info.pmut = 0.05; //mutation probablity
	ga_info.mut_control[0] = 0;
	for(int i=1; i<10; i++)
		ga_info.mut_control[i] = 1;
	ga_info.mdsteps = 0;
	ga_info.eweight = 100.0;
	ga_info.sweight = 50.0;

	//parameters for interface/surface
	ga_info.nfixedt = ga_info.nfixedb = ga_info.nbufft = ga_info.nbuffb =0;
	ga_info.b_to_i = 0.5;
	ga_info.tmpatoms = 0;
	ga_info.movetop = 0;
	ga_info.vacuum = -1.0;
	ga_info.temp_nions = 0;
	return 1;
}

int Read_GA_Info(GAPara &ga_info){
	ifstream fin("ga.in");
	string ss, buf;
	string atomn, maxn, minn, vatom, eatom, potential, mass, mutcontrol;
	while(getline(fin, ss)){
		string eq;
		stringstream reads(ss);
		reads >> buf;
		if(buf == "system"){
			reads >> eq >> ga_info.systype;
		}else if(buf == "restart"){
			reads >> eq >> ga_info.if_restart;
		}else if(buf == "id"){
			reads >> eq >> ga_info.cur_id;
		}else if(buf == "cstation"){
			reads >> eq >> ga_info.images;
		}else if(buf == "dstation"){
			reads >> eq >> ga_info.images_dft;
		}else if(buf == "cpool"){
			reads >> eq >> ga_info.NPOOL;
		}else if(buf == "dpool"){
			reads >> eq >> ga_info.NPOOL_DFT;
		}else if(buf == "cgen"){
			reads >> eq >> ga_info.NGEN;
		}else if(buf == "dgen"){
			reads >> eq >> ga_info.NGEN_DFT;
		}else if(buf == "rcut"){
			reads >> eq >> ga_info.rcut;
		}else if(buf == "cellf"){
			reads >> eq >> ga_info.cell_fac;
		}else if(buf == "recalce"){
			reads >> eq >> ga_info.recalce;
		}else if(buf == "natoms"){
			reads >> eq >> ga_info.nions;
		}else if(buf == "ntype"){
			reads >> eq >> ga_info.ntype;
		}else if(buf == "maxnatom"){
			maxn = ss;
		}else if(buf == "minnatom"){
			minn = ss;
		}else if(buf == "avolume"){
			vatom = ss;
		}else if(buf == "aenergy"){
			eatom = ss;
		}else if(buf == "maxangle"){
			reads >> eq >> ga_info.angle_max;
		}else if(buf == "minangle"){
			reads >> eq >> ga_info.angle_min;
		}else if(buf == "press"){
			reads >> eq >> ga_info.press;
			ga_info.press_dft = ga_info.press;
		}else if(buf == "cellfree"){
			reads >> eq >> ga_info.cellfree;
		}else if(buf == "pot"){
			reads >> eq >> potential;
		}else if(buf == "fixsite"){
			reads >> eq >> ga_info.fixsite;
		}else if(buf == "dimen"){
			reads >> eq >> ga_info.dimen;
		}else if(buf == "zslab"){
			reads >> eq >> ga_info.zslab;
		}else if(buf == "ztotal"){
			reads >> eq >> ga_info.ztotal;
		}else if(buf == "criteria"){
			reads >> eq >> ga_info.criteria;
		}else if(buf == "nfixed"){
			reads >> eq >> ga_info.nfixedt >> ga_info.nfixedb;
		}else if(buf == "nbuff"){
			reads >> eq >> ga_info.nbufft >> ga_info.nbuffb;
		}else if(buf == "movetop"){
			reads >> eq >> ga_info.movetop;
		}else if(buf == "bot2interface"){
			reads >> eq >> ga_info.b_to_i;
		}else if(buf == "vacuum"){
			reads >> eq >> ga_info.vacuum;
		}else if(buf == "mdsteps"){
			reads >> eq >> ga_info.mdsteps;
		}else if(buf == "amass"){
			mass = ss;
		}else if(buf == "pmut"){
			reads >> eq >> ga_info.pmut;
		}else if(buf == "mutcontrol"){
			mutcontrol = ss;
		}else if(buf == "e1conv"){
			reads >> eq >> ga_info.e1conv;
		}else if(buf == "e2conv"){
			reads >> eq >> ga_info.e2conv;
		}else if(buf == "n1conv"){
			reads >> eq >> ga_info.n1conv;
		}else if(buf == "n2conv"){
			reads >> eq >> ga_info.n2conv;
		}else if(buf == "atomn"){
			atomn = ss;
		}else if(buf == "eng_weight"){
			reads >> eq >> ga_info.eweight;
		}else if(buf == "stress_weight"){
			reads >> eq >> ga_info.sweight;
		}else if(buf == "ilmpin"){
			reads >> eq >> ga_info.ilmpin;
		}else if(buf == "scale_V"){
			reads >> eq >> ga_info.scale_V;
		}else if(buf == "pwscf"){
			reads >> eq >> ga_info.pwscf;
		}
	}
	fin.close();
	if(ga_info.systype==0)
		cout << "===============    Search for crystals    ===============" << endl;
	else if(ga_info.systype==1){
		cout << "===============    Search for clusters    ===============" << endl;
		ifstream fin("latt.in");
		if(!fin.is_open()){
			cout << "WARNING: no latt.in found. The box will be set to 50 x 50 x 50." << endl;
		}
		fin.close();
	}
	else if(ga_info.systype==2)
		cout << "===============    Search for interface/surface    ===============" << endl;
	else{
		cout << "ERROR: Unknown system type.\nPlease check the setting of 'system' in ga.in." << endl;
		exit(1);
	}
	if(ga_info.NGEN == 0 && ga_info.NGEN_DFT == 0){
		cout << "ERROR: generations for both classical and DFT searches were set to 0.\n";
		cout << "Please check 'cgen' & 'dgen' in ga.in." << endl;
		exit(1);
	}

	if(ga_info.NGEN_DFT == 0)ga_info.NPOOL_DFT = 0;
	if(ga_info.NPOOL == 0 && ga_info.NPOOL_DFT == 0){
		cout << "ERROR: pool sizes for both classical and DFT searches were set to 0.\n";
		cout << "Please check 'cpool' & 'dpool' in ga.in." << endl;
		exit(1);
	}

	if(ga_info.nions < 0){
		cout << "ERROR: total number of atoms was not set.\nPlease check 'natoms' in ga.in." << endl;
		exit(1);
	}
	if(ga_info.ntype < 0){
		cout << "ERROR: number of atom type was not set.\nPlease check 'ntype' in ga.in." << endl;
		exit(1);
	}

	if(atomn.length() == 0){
		if(maxn.length() == 0 || minn.length() == 0){
			cout << "ERROR: number of atoms for each type was not set properly.\n";
			cout << "Please check 'atomn' or ('maxn' & 'minn') in ga.in." << endl;
			exit(1);
		}else{
			stringstream read1(maxn);
			read1 >> buf >> buf;
			for(int i=0; i<ga_info.ntype; i++)
				read1 >> ga_info.atom_type_max[i];
			stringstream read2(minn);
			read2 >> buf >> buf;
			for(int i=0; i<ga_info.ntype; i++)
				read2 >> ga_info.atom_type_min[i];
		}
	}else{
		stringstream readn(atomn);
		readn >> buf >> buf;
		for(int i=0; i<ga_info.ntype; i++){
			readn >> ga_info.atom_type_max[i];
			ga_info.atom_type_min[i] = ga_info.atom_type_max[i];
		}
	}
	if(ga_info.if_restart){
		int tmp_npool = Read_Pool_Size("./pool.in");
		if(tmp_npool == 0){
			cout << "Warning: no pool.in found." << endl;
			cout << "Start from random population." << endl;
			ga_info.if_restart = 0;
		}
		if(ga_info.recalce)
			cout << "Energy of the structures in pool.in will be recalculated." << endl;
	}
	if(vatom.length() != 0){
		stringstream read3(vatom);
		read3 >> buf >> buf;
		for(int i=0; i<ga_info.ntype; i++)
			read3 >> ga_info.vol[i];
	}
	if(eatom.length() != 0){
		stringstream read4(eatom);
		read4 >> buf >> buf;
		for(int i=0; i<ga_info.ntype; i++)
			read4 >> ga_info.c_p[i];
	}
	if(mass.length() != 0){
		stringstream read5(mass);
		read5 >> buf >> buf;
		for(int i=0; i<ga_info.ntype; i++)
			read5 >> ga_info.amass[i];
	}else{
		if(potential == "coul" || (ga_info.movetop && ga_info.nfixedt != 0))
			cout << "Warning: Atom mass was not given. When running MD, mass will be set to 10 for all the atoms." << endl;
	}
	if(mutcontrol.length() != 0){
		stringstream read6(mutcontrol);
		read6 >> buf >> buf;
		for(int i=0; i<ga_info.ntype; i++)
			read6 >> ga_info.mut_control[i];
	}

	ga_info.comp_number = ga_info.atom_type_max[1] - ga_info.atom_type_min[1] + 1;
	cout << "Atom Type = " << ga_info.ntype << "; Atom number = " << ga_info.nions << ".\n";
	cout << "LMP Pool size = " << ga_info.NPOOL << "; DFT Pool size = " << ga_info.NPOOL_DFT << ".\n";
	cout << "LMP Generations = " << ga_info.NGEN << "; DFT Generations = " << ga_info.NGEN_DFT << ".\n";
	cout << "Rcut = " << ga_info.rcut << " A.\n";
	switch (ga_info.cellfree){
		case 0:
			cout << "no cell relaxation. " << endl; break;
		case 1:
			cout << "isotropic cell relaxation. " << endl; break;
		case 2:
			cout << "anisotropic cell relaxation. " << endl; break;
		case 3:
			cout << "all free cell relaxation. " << endl; break;
		default:
			cout << "no cell relaxation. " << endl;
	}
	if(potential.length() != 0) cout << "Use " << potential << " potential." << endl;
	else cout << "No potential type was specified." << endl;
	if(potential == "eam")ga_info.lj_eam = 0;
	else if(potential == "lj")ga_info.lj_eam = 1;
	else if(potential == "morse")ga_info.lj_eam = 2;
	else if(potential == "coul")ga_info.lj_eam = 3;
	else ga_info.lj_eam = 0;
	if(ga_info.criteria < 0){
		cout << "Warning: No criteria for checking structures was set. Default (Rcut/8) will be used." << endl;
		ga_info.criteria = ga_info.rcut/8;
	}
	cout << "Structure comparison criteria is " << ga_info.criteria << ".\n";
	if(ga_info.pmut == 0){
		cout << "Mutation is turned off." << endl;
	}else if(ga_info.pmut <0 || ga_info.pmut > 1){
		cout << "Warning: Probability for mutation should be between 0 and 1." << endl;
		cout << "Reset to default value." << endl;
		ga_info.pmut = 0.05;
	}else{
		cout << "Probability for mutation equals to " << ga_info.pmut << ".\n";
		cout << "Mutation control factor for each type =  ";
		for(int i=0; i<ga_info.ntype; i++)
			cout << ga_info.mut_control[i] << "  ";
		cout << endl;
	}
	if(ga_info.dimen==2){
		cout << "***          Two dimensional structure search          ***" << endl;
		cout << "Thickness of the unit cell = " << ga_info.ztotal << endl;
		cout << "Thickness of the layer = " << ga_info.zslab << endl;
		if(ga_info.pmut<0.5)ga_info.pmut = ga_info.pmut*2;
		cout << "Probability for shifting atoms in z directions = " << ga_info.pmut/2 << endl;
	}
	if(ga_info.fixsite)
		cout << "Fixed site run." << endl;

	//interface
	if(ga_info.systype==2){
		if(ga_info.nfixedt!=0 && ga_info.movetop)
			cout << "TOP fixed atoms are allowed to move ..." << endl;
		else if(ga_info.nfixedt != 0)
			cout << "TOP fixed atoms are NOT allowed to move (as a rigid body)." << endl;
		ga_info.tmpatoms=ga_info.nfixedt+ga_info.nfixedb+ga_info.nbufft+ga_info.nbuffb;
		if(ga_info.tmpatoms==0){
			cout << "System Type = 2 (interface/surface), yet no template atoms are allowed!\nPlease check ga.in! "<< endl;
			exit(0);
		}
		cout << "The bottom part will be moved to " << ga_info.b_to_i << " angstroms below z=0 plane, where the interface starts." << endl;
		if(ga_info.vacuum < 0){
			cout << "Warning: No vacuum region was set. Default will be used." << endl;
			ga_info.vacuum = 20.0;
		}
		cout << "A vacuum region with height = " << ga_info.vacuum << " angstroms will be added." << endl;
		if(ga_info.nfixedt != 0 && ga_info.movetop){
			if(ga_info.mdsteps == 0){
				cout << "Warning: No MD steps was set to move the top bulk. Default (5000) will be used." << endl;
				ga_info.mdsteps = 5000;
			}
			cout << "MD steps = " << ga_info.mdsteps << ".\n";
		}
	}
	ga_info.temp_nions = Read_template_head();

	if (ga_info.NGEN !=0 && ga_info.NGEN_DFT != 0) {
		ga_info.onfly = 1;
		cout << "===============   Running Adaptive GA   ==================" << endl;
		fstream fin("./potfit.in",ios::in);
		if(fin) {fin.close();}
		else
			Potfit_Input(ga_info);
	}else ga_info.onfly = 0;
	if(ga_info.NGEN ==0) {
		ga_info.NPOOL=ga_info.NPOOL_DFT;
		ga_info.alldft = 1;
		cout << "===============   Running First Principles GA   ==================" << endl;
	}else if (ga_info.NGEN_DFT == 0)
		cout << "===============   Running Classical GA   ==================" << endl;
	// write out the chemical potential for potfit
	if(ga_info.onfly && eatom.length() != 0){
		ofstream atomenergy("atom_energy.dat");
		for(int i = 1; i < ga_info.ntype; i++)
			atomenergy << ga_info.c_p[i] << " ";
		atomenergy << endl;
		atomenergy.close();
	}

	//write_oldin(ga_info);
	return 1;
}

void write_oldin(GAPara ga_info){
	cout << "====== start ======" << endl;
	cout << ga_info.systype << endl;
	cout << ga_info.if_restart << endl;
	cout << ga_info.cur_id << endl;
	cout << ga_info.images << "  " << ga_info.images_dft << endl;
	cout << ga_info.NPOOL << "  " << ga_info.NPOOL_DFT << endl;
	cout << ga_info.NGEN << "  " << ga_info.NGEN_DFT << endl;
	cout << ga_info.rcut << "  "  << ga_info.cell_fac << endl;
	cout << ga_info.dkp << "  " << ga_info.recalce << endl;
	cout << ga_info.nions << endl;
	cout << ga_info.ntype << endl;
	for(int i=0; i<ga_info.ntype; i++)
		cout << ga_info.atom_type_min[i] << "  ";
	cout << endl;
	for(int i=0; i<ga_info.ntype; i++)
		cout << ga_info.atom_type_max[i] << "  ";
	cout << endl;
	for(int i=0; i<ga_info.ntype; i++)
		cout << ga_info.vol[i] << "  ";
	cout << endl;
	for(int i=0; i<ga_info.ntype; i++)
		cout << ga_info.c_p[i] << "  ";
	cout << endl;
	cout << ga_info.angle_min << "  " << ga_info.angle_max << endl;
	cout << ga_info.press << "  " << ga_info.press_dft << endl;
	if(ga_info.lj_eam != 3)cout << "eam" << endl;
	else cout << "coul" << endl;
	cout << ga_info.fixsite << endl;
	cout << ga_info.dimen << endl;
	cout << ga_info.criteria << endl;
	cout << "====== done ======" << endl;
}

void Init_Pool(Posion *latt[],Posion *pos[],double *ene, int *struc_id, int *atom_type, GAPara ga_info, double *vec_fixedt){
	Posion **latt_db,**pos_db;
	int *db_id,*nions_db,db_size,*real_nions,db_choice;
	int nx,ny,nz;
	real_nions = new int[ga_info.NPOOL];
	db_id = new int[2000];
	nions_db = new int[2000];
	latt_db = new Posion*[2000];
	pos_db = new Posion*[2000];
        for ( int i = 0; i < 2000; i++)  nions_db[i] = 1;
	db_size = Read_Database(latt_db,pos_db,db_id,nions_db);
	db_choice = -1;
      	struc_id[ga_info.NPOOL] = ga_info.cur_id;
        for ( int i = 0; i < ga_info.NPOOL; i++) {
		real_nions[i] = ga_info.nions - atom_type[i*ga_info.ntype];
		latt[i] = new Posion[3];
		pos[i] = new Posion[ga_info.nions];
		do{
			db_choice++;
		}while ( (real_nions[i] % nions_db[db_choice]) != 0 && db_choice < db_size); // pick up one in database
		if( (real_nions[i] % nions_db[db_choice] == 0) && db_choice < db_size) {
			cout << "test init_Pool ..." << endl;
			Int_Fact(real_nions[i] / nions_db[db_choice],nx,ny,nz);
			Expand_Cell(latt_db[db_choice],pos_db[db_choice],latt[i],pos[i]+atom_type[i*ga_info.ntype],nions_db[db_choice],nx,ny,nz);
			Sort_Type(pos[i],ga_info.nions);
			Put_Type(pos[i],ga_info.nions,atom_type+i*ga_info.ntype,ga_info.ntype);
			KarDir(latt[i],pos[i],ga_info.nions);
			Mutate_Cell(latt[i],0.00);
			DirKar(latt[i],pos[i],ga_info.nions);
			Adjust_volume(latt[i], pos[i], atom_type+i*ga_info.ntype,ga_info.vol,ga_info.ntype,ga_info.nions);
			struc_id[i] += db_id[db_choice]*100000;
		} else
	                Init_Structure(latt[i],pos[i], atom_type+i*ga_info.ntype,ga_info, vec_fixedt+i*3);
                struc_id[i]=struc_id[ga_info.NPOOL]++;
		ene[i] = ENENONE;
		//if(i%8==0) cout << '=';
	}
	if(db_choice < db_size)
		cout << "Some more fitting prototype available, increase poolsize." << endl;
	cout << "Pool initialization finished." << endl;
}

void Gen_kpoints(double *latt, int *kpoints,GAPara ga_info){
	double a;
	a = sqrt(latt[0]*latt[0]+latt[1]*latt[1]+latt[2]*latt[2]);
	kpoints[0] = nearbyint(1.0/(a*ga_info.dkp));
	if(kpoints[0] == 0) kpoints[0]=1;
	a = sqrt(latt[4]*latt[4]+latt[5]*latt[5]+latt[6]*latt[6]);
	kpoints[1] = nearbyint(1.0/(a*ga_info.dkp));
	if(kpoints[1] == 0) kpoints[1]=1;
	a = sqrt(latt[8]*latt[8]+latt[9]*latt[9]+latt[10]*latt[10]);
	kpoints[2] = nearbyint(1.0/(a*ga_info.dkp));
	if(kpoints[2] == 0) kpoints[2]=1;
	if(ga_info.dimen==2) kpoints[2]=1;
}


void Sort_Pool(Posion *latt[], Posion *pos[], double *ene,double *stress, double *press, int *struc_id, int *atom_type, vector<float> *bondlist, GAPara ga_info, double *vec){
        Posion *postmp;
	vector<float> vectmp;
        double enetmp,ene_1,ene_2, tmp_vec[3];
	int itmp;
        int comp_number = ga_info.atom_type_max[1] - ga_info.atom_type_min[1] + 1;
        int sub_poolsize = ga_info.NPOOL / comp_number;
        for ( int l = 0; l < comp_number; l++)
        for ( int i = l*sub_poolsize; i < (l+1)*sub_poolsize; i++)
                for ( int j = (l+1)*sub_poolsize-1; j > i ; j--){
			ene_1 = ene[j];
			ene_2 = ene[j-1];
                        if (ene_1 < ene_2) {
				//swap the vector
				if(ga_info.nfixedt != 0){
					for(int x=0; x<3; x++)tmp_vec[x]=vec[j*3+x];
					for(int x=0; x<3; x++)vec[j*3+x]=vec[(j-1)*3+x];
					for(int x=0; x<3; x++)vec[(j-1)*3+x]=tmp_vec[x];
				}

                                enetmp=ene[j]; ene[j]=ene[j-1]; ene[j-1]=enetmp;
                                enetmp=press[j]; press[j]=press[j-1]; press[j-1]=enetmp;
				for(int k = 0; k < 6; k++){
					enetmp=stress[j*6+k];
					stress[j*6+k]=stress[(j-1)*6+k];
					stress[(j-1)*6+k]=enetmp;
				}
				postmp=pos[j]; pos[j]=pos[j-1]; pos[j-1]=postmp;
				postmp=latt[j]; latt[j]=latt[j-1]; latt[j-1]=postmp;
				itmp=struc_id[j]; struc_id[j]=struc_id[j-1]; struc_id[j-1]=itmp;
				vectmp=bondlist[j]; bondlist[j]=bondlist[j-1]; bondlist[j-1]=vectmp;
        			for ( int k = 0; k < ga_info.ntype; k++){
					itmp = atom_type[j*ga_info.ntype+k];
					atom_type[j*ga_info.ntype+k] = atom_type[(j-1)*ga_info.ntype+k];
					atom_type[(j-1)*ga_info.ntype+k] = itmp; 
				} 
                        }
                }
}

void Sort_Pool_Enthalpy(Posion *latt[], Posion *pos[], double *ene,double *stress, double *press, int *struc_id, int nions, int poolsize){
        Posion *postmp;
        double enetmp,ene_1,ene_2,press_1,press_2;
	int itmp;
	int sub_poolsize = 1;
	if(sub_poolsize<=1) sub_poolsize=poolsize;
	int ngroup = poolsize/sub_poolsize;
        for ( int l = 0; l < ngroup; l++)
        for ( int i = l*sub_poolsize; i < (l+1)*sub_poolsize; i++)
                for ( int j = l*sub_poolsize; j < (l+1)*sub_poolsize - (i-l*sub_poolsize) - 1; j++){
#ifdef ENTHAL
			ene_1 = ene[j]/nions - (-23.403+0.0077686*press[j])/3;
			ene_2 = ene[j+1]/nions - (-23.403+0.0077686*press[j+1])/3;
#else  
			ene_1 = ene[j];
			ene_2 = ene[j+1];
#endif
                        if (ene_1 > ene_2) {
                                //swap 
                                enetmp=ene[j]; ene[j]=ene[j+1]; ene[j+1]=enetmp;
                                enetmp=press[j]; press[j]=press[j+1]; press[j+1]=enetmp;
				for(int k = 0; k < 6; k++){
                                	enetmp=stress[j*6+k]; stress[j*6+k]=stress[(j+1)*6+k]; stress[(j+1)*6+k]=enetmp;
				}
                                postmp=pos[j]; pos[j]=pos[j+1]; pos[j+1]=postmp;
                                postmp=latt[j]; latt[j]=latt[j+1]; latt[j+1]=postmp;
                                itmp=struc_id[j]; struc_id[j]=struc_id[j+1]; struc_id[j+1]=itmp;
                        }
                }
}

void Next_Gen(Posion *latvec[],Posion *pos[],double *ene, int *struc_id, Posion *site, int nsite, int *atom_type, int *comp_status, vector<float> *bondlist, GAPara ga_info){
	int tmp_type[10],offset,comp_offset;
	float ave_mating_p =0.0, mating_p=0.0;
	int comp_number = ga_info.atom_type_max[1] - ga_info.atom_type_min[1] + 1;
	int sub_poolsize = ga_info.NPOOL / comp_number;
        double vputim_0,cputim_0,vputim,cputim;
        Posion **posnew = new Posion*[2];
        Posion **latt_new = new Posion*[2];
	posnew[0]=new Posion[ga_info.nions]; latt_new[0]= new Posion[3];
	posnew[1]=new Posion[ga_info.nions]; latt_new[1]= new Posion[3];

	cout << "generating child structures......" << endl;
	int nmut = 0, badsetting = 0;
	for(int j = 0; j < comp_number; j++){
        	for(int k = sub_poolsize/4*3; k < sub_poolsize; k++){
	                offset = sub_poolsize*j + k;
			int l = 0, xparent;
			//mutate
			double pmutate = RandomDouble(0.0, 1.0);
			if(pmutate < ga_info.pmut){
				while(1){
					xparent = int(fabs(RandomGaussian(0,sub_poolsize/3)));
					if(xparent < sub_poolsize){
						xparent += j*sub_poolsize;
						if(ene[xparent]!=9999.0)break;
					}
				}
				for(int x=0; x<3; x++)
					latt_new[0][x]=latvec[xparent][x];
				for(int x=0; x<ga_info.nions; x++)
					posnew[0][x]=pos[xparent][x];
				double muttype = RandomDouble(0.0, 1.0);
				if(muttype < 0.5 || ga_info.dimen != 2)
					Mutate_Type(posnew[0], ga_info);
				else Mutate_2Dz(posnew[0], ga_info);
				nmut++;
			}else{
				bool success=0; int xc = 0;
				while(!success){
		        	        int m,n, compm, compn;
					compm = RandomInt(0,comp_number-1);
					compn = RandomInt(0,comp_number-1);
		                	while(1){
						m = int(fabs(RandomGaussian(0,sub_poolsize/3)));
						n = int(fabs(RandomGaussian(0,sub_poolsize/3)));
						if(m < n&&n<sub_poolsize){
							m = m+compm*sub_poolsize;
							n = n+compn*sub_poolsize;
							if(ene[m]!=9999.0 && ene[n]!=9999.0)break;
						}
					}
		 	               	if(ga_info.atom_type_max[0] != 0){
 	 		                       atom_type[offset*ga_info.ntype] = atom_type[offset*ga_info.ntype+1];
 	 	        	               for(int kk = 2; kk < ga_info.ntype; kk++){
 	 	                	               atom_type[offset*ga_info.ntype+kk] = RandomInt(ga_info.atom_type_min[kk],ga_info.atom_type_max[kk]);
 	 	                        	       atom_type[offset*ga_info.ntype] +=atom_type[offset*ga_info.ntype+kk];
		 	                       }
 	 		                       atom_type[offset*ga_info.ntype] = ga_info.nions-atom_type[offset*ga_info.ntype];
 	 	        	       	}
        
 	 	               		mating_p = Mating2( pos[m], pos[n], latvec[m], latvec[n], latt_new, posnew, 
		 	                                 atom_type+offset*ga_info.ntype, site,nsite,ga_info);
 	 		               	if(mating_p == 0.0 || mating_p == 1.0) {continue;} //remate
					xc++;
					if(xc > 1000){k--; break;}                //exit the loop
					double tmpmindis = Check_bond(latt_new[l], posnew[l], ga_info.nions);
					if(tmpmindis < ga_info.rcut*0.75) {continue;}      //remate
					ave_mating_p += mating_p;
					success = 1;
				}
				if(xc > 500)badsetting++;
			}
			Get_Type(posnew[l],ga_info.nions,tmp_type,ga_info.ntype);
	               	comp_status[j]++;
			if(ga_info.dimen==3)
               			Adjust_volume(latt_new[l], posnew[l], atom_type+offset*ga_info.ntype,ga_info.vol,ga_info.ntype,ga_info.nions);
 	               	if((mating_p < 0.2 || mating_p > 0.8) && ga_info.ntype > 2)
				Shuffle_Type(posnew[l],ga_info.nions);
        	       	Copy_posion(posnew[l],pos[offset],ga_info.nions);
               		Copy_posion(latt_new[l],latvec[offset],3);
	 	        ene[offset] = ENENONE;
			struc_id[offset] = struc_id[ga_info.NPOOL]++;
			bondlist[offset].clear();
		}
	}
	if(badsetting > 0)
		cout << "** " << badsetting << " warnings: too many trials to generate one child structure, please check if rcut is set properly." << endl;

	if(ga_info.pmut != 0)cout << nmut << " structures are generated from mutation." << endl;
	if(nmut != comp_number*sub_poolsize/4)
		cout << "Mating completed, average mating percentage: " << ave_mating_p/(comp_number*sub_poolsize/4-nmut)<< endl;
	for(int j = 0; j < comp_number; j++){
		for(int k = comp_status[j]; k < sub_poolsize; k++){
		        offset = sub_poolsize*j + k;
			//to deal with the interface
			double x[3];
		        Init_Structure(latvec[offset],pos[offset], atom_type+offset*ga_info.ntype, ga_info, x);
		        ene[offset] = ENENONE;
		        struc_id[offset] = struc_id[ga_info.NPOOL]++;
		        comp_status[j]++;
			bondlist[offset].clear();
		        cout << "New structure generated" << endl;
		}
	}
}

double Mating2(const Posion *pos1, const Posion *pos2, const Posion *latt1, const Posion *latt2, Posion *newlatt[],Posion *newstruc[], 
	      int *atom_type_target, Posion *site,int nsite,GAPara ga_info){
        int i,j,nions=ga_info.nions;
        Posion slice_dir,shift_atom;
        Posion plane_1, plane_2;
	Posion slab_1[2],slab_2[2];
	Posion *postmp1, *postmp2;
	Posion **posdbg;
        double vputim_0,cputim_0,vputim,cputim;
        double a[3],center,width,d,mating_p,mating_width;
        int *inout_1,*inout_2,nin_1,nin_2;
	int *tmp_type = new int[ga_info.ntype];
	postmp1 = new Posion[nions];
	postmp2 = new Posion[nions];
	posdbg = new Posion*[2];
	posdbg[0] = new Posion[nions];
	posdbg[1] = new Posion[nions];
        for (i = 0; i < nions; i++){
		postmp1[i] = pos1[i];
		postmp2[i] = pos2[i]; 
	}
	// Lattice mating
	KarDir(latt1,postmp1,nions); KarDir(latt2,postmp2,nions);
	DirKar(latt1,postmp1,nions); DirKar(latt2,postmp2,nions);
	double rcut_new = Check_bond(latt1,postmp1,nions);
	mating_width = rcut_new*2.5;
	rcut_new*=0.6;
	KarDir(latt1,postmp1,nions); KarDir(latt2,postmp2,nions);
	newlatt[0][0]   = (latt1[0] + latt2[0]) / 2;
	newlatt[0][1]   = (latt1[1] + latt2[1]) / 2;
	newlatt[0][2]   = (latt1[2] + latt2[2]) / 2;
	newlatt[1][0] = (latt1[0] + latt2[0]) / 2;
	newlatt[1][1] = (latt1[1] + latt2[1]) / 2;
	newlatt[1][2] = (latt1[2] + latt2[2]) / 2;
	double oldvol = Cell_Volume(latt1);
	double newvol = Cell_Volume(newlatt[0]);
	if(ga_info.dimen==3)newvol = cbrt(newvol/oldvol);
	else newvol = sqrt(newvol/oldvol); // 2D

	newlatt[0][0] = newlatt[0][0]/newvol;
	newlatt[0][1] = newlatt[0][1]/newvol;
	newlatt[1][0] = newlatt[1][0]/newvol;
	newlatt[1][1] = newlatt[1][1]/newvol;
	if(ga_info.dimen==3) {
		newlatt[1][2] = newlatt[1][2]/newvol;
		newlatt[0][2] = newlatt[0][2]/newvol;
	}

	//if unit cell is too thin||long
	if(ga_info.dimen==3){
		double xa, xb, xc, xalpha, xbeta, xgamma;
		Get_Cell_Para(newlatt[0], xa, xb, xc, xalpha, xbeta, xgamma);
		if(fabs(xalpha*180/3.1415926-90) > 45 || fabs(xbeta*180/3.1415926-90) > 45 || fabs(xgamma*180/3.1415926-90) > 45){
			double rnum = RandomDouble(0, 1);
			if(rnum < 0.7)
				return 0;
		}
		if(xa > 2*xb*xc || xb > 2*xa*xc || xc > 2*xa*xb){
			double rnum = RandomDouble(0, 1);
			if(rnum < 0.5)
				return 0;
		}
	}

        inout_1=new int[nions];
        inout_2=new int[nions];

	int which_plane= 0;
	for (i = 0; i < 3; i++)
		a[i]=sqrt(newlatt[0][i].x*newlatt[0][i].x
			 +newlatt[0][i].y*newlatt[0][i].y
		         +newlatt[0][i].z*newlatt[0][i].z);
	if(a[0]>a[1]&&a[0]>a[2]) which_plane=0;
	if(a[1]>a[0]&&a[1]>a[2]) which_plane=1;
	if(ga_info.dimen==3) if(a[2]>a[0]&&a[2]>a[1]) which_plane=2;
	// determine slice plane direction;        
	mating_width /= a[which_plane]; 
        for (i = 0; i < 2; i=i+2){

		// set mating slab
		// choose slab direction and width
	        center=RandomDouble(0.1,0.9);
		width = RandomDouble(0.125,0.4);

	        // plane_1 is center slice + slicewidth, plane_2 is -.
       	 	//width = (center.x+center.y+center.z)/3;
		nin_1=nin_2=0;
                for (j = 0; j < nions; j++){
			newstruc[i][j].x=newstruc[i][j].y=newstruc[i][j].z=newstruc[i][j].ityp = 0;
			newstruc[i+1][j].x=newstruc[i+1][j].y=newstruc[i+1][j].z=newstruc[i+1][j].ityp = 0;
			inout_1[j] = Within_Planes(postmp1[j],center, width, which_plane);
			if(postmp1[j].ityp > 10) inout_1[j]=1;
			nin_1+=inout_1[j];

			inout_2[j] = Within_Planes(postmp2[j],center, width, which_plane);
			if(postmp2[j].ityp > 10) inout_2[j]=1;
			nin_2+=inout_2[j]; 
                }
                int child_1=0,child_2=0; // child atoms generation counting
		// Swap atoms
		mating_p = double(nin_1)/double(nions);
		for (j = nions-1; j >= 0; j--){
                     	if ( inout_1[j]==0 ) {
     				if (child_1 < nions && postmp1[j].ityp != 0){
                             		newstruc[i][child_1]=postmp1[j];
					//posdbg[0][child_1]=postmp1[j];
					//posdbg[0][child_1].ityp=1;
                             		child_1++;
     				}
                     	} else {
     				if (child_2 < nions && postmp1[j].ityp != 0){
                             		newstruc[i+1][child_2]=postmp1[j];
					//posdbg[1][child_2]=postmp1[j];
					//posdbg[1][child_2].ityp=1;
                             		child_2++;
     				}
                     	}
                     	if ( inout_2[j]==1 ) {
     				if (child_1 < nions && postmp2[j].ityp != 0){
                             		newstruc[i][child_1]=postmp2[j];
					//posdbg[0][child_1]=postmp2[j];
					//posdbg[0][child_1].ityp=2;
                       		      	child_1++;
     				}
                     	} else {
     				if (child_2 < nions && postmp2[j].ityp != 0){
                             		newstruc[i+1][child_2]=postmp2[j];
					//posdbg[1][child_2]=postmp2[j];
					//posdbg[1][child_2].ityp=2;
                             		child_2++;
     				}
                     	}
             	}
		double enetmp[2];
//        	DirKar(newlatt[0],posdbg[0],nions);
 //       	DirKar(newlatt[0],posdbg[1],nions);

        	DirKar(newlatt[i],newstruc[i],nions);
        	KarDir(newlatt[i],newstruc[i],nions);
		Sort_Type(newstruc[i],nions);
		Get_Type(newstruc[i],nions,tmp_type,ga_info.ntype);
		int one_fix=0;
		// looking for atom at origin
		for (j = 0; j < nions; j++)
			if(newstruc[i][j].x == 0.0 && newstruc[i][j].y == 0.0 && newstruc[i][j].z == 0.0 &&
			   newstruc[i][j].ityp == 1 ){
				one_fix = 1;
				newstruc[i][j] = newstruc[i][tmp_type[0]];
				newstruc[i][tmp_type[0]].x=newstruc[i][tmp_type[0]].y=newstruc[i][tmp_type[0]].z=0;
				if(newstruc[i][tmp_type[0]].ityp>10) cout << "*" << endl;
				newstruc[i][tmp_type[0]].ityp = 0;
				tmp_type[0]++;
				tmp_type[1]--;
				atom_type_target[1]--;
				break;
			}

		// adjust structure by type switch
		// choose in slabs
		int undefined = 0;

		for (j = tmp_type[0]; j < nions; j++){
			if( (Within_Planes(newstruc[i][j],center-width,mating_width,which_plane)  ||
			     Within_Planes(newstruc[i][j],center+width,mating_width,which_plane)) &&
			     tmp_type[newstruc[i][j].ityp%10] > atom_type_target[newstruc[i][j].ityp%10]&&
			     newstruc[i][j].ityp < 10 ) {
				tmp_type[newstruc[i][j].ityp]--;
				undefined++;
				if(newstruc[i][j].ityp>10) cout << "***" << endl;
				newstruc[i][j].ityp = 999;
			}
		}
		// choose outside of slabs
		Shuffle_atom(newstruc[i],nions);
		Sort_Type(newstruc[i],nions);
		for (j = tmp_type[0]; j < nions - undefined; j++){
			if( tmp_type[newstruc[i][j].ityp%10] > atom_type_target[newstruc[i][j].ityp%10] && newstruc[i][j].ityp < 10 ) {
				tmp_type[newstruc[i][j].ityp]--;
				if(newstruc[i][j].ityp>10) cout << "*****" << endl;
				newstruc[i][j].ityp = 999;
			}
		}
		// switch
		for (j = tmp_type[0]; j < nions; j++){
			if(newstruc[i][j].ityp == 999) {
				for (int k = 1; k < ga_info.ntype; k++){
					if(tmp_type[k] < atom_type_target[k] ){
						tmp_type[k]++;
						newstruc[i][j].ityp = k;
					}
				}
			}
		}
		for (j = tmp_type[0]; j < nions; j++)
			if(newstruc[i][j].ityp == 999) 
				newstruc[i][j].x=newstruc[i][j].y=newstruc[i][j].z=newstruc[i][j].ityp = 0;

		// adjust structure by adding new atom in slabs.
		Posion add_atom;
		Sort_Type(newstruc[i],nions);
		Get_Type(newstruc[i],nions,tmp_type,ga_info.ntype);

		int insert_ok = 0;
		for (j = 1; j < ga_info.ntype; j++) {
                        int accept = 1;
			if(tmp_type[j] < atom_type_target[j] ){
                                while(accept&&accept<1000){
                                        add_atom.x=RandomDouble(0,1);
                                        add_atom.y=RandomDouble(0,1);
                                        add_atom.z=(ga_info.dimen==3?RandomDouble(0,1):0.0);
					if(nsite != 0) add_atom = site[RandomInt(1,nsite)-1];
					add_atom.ityp = j;
                                        int k;
                                        for (k = 0; k < nions; k++) 
                                                if(Bond_length(newlatt[i],newstruc[i][k],add_atom) < rcut_new ){
							accept++;break;
						}
                                        if (k==nions) 
						if( Within_Planes(add_atom,center-width, mating_width, which_plane) ||
						    Within_Planes(add_atom,center+width, mating_width, which_plane)) {
							accept = 0;
							newstruc[i][tmp_type[0]-1].x = add_atom.x;
							newstruc[i][tmp_type[0]-1].y = add_atom.y;
							newstruc[i][tmp_type[0]-1].z = add_atom.z;
							newstruc[i][tmp_type[0]-1].ityp = j;
							if(newstruc[i][tmp_type[0]-1].ityp>10)
								cout << "******************" << endl;
							tmp_type[0]--;
							tmp_type[j]++;
						} else accept++;
                                }
				j--;
			}
			if(accept>=100) {insert_ok=1;break;}
		}

		if(one_fix == 1) {
			newstruc[i][tmp_type[0]-1].ityp = 1;
			atom_type_target[1]++;
		}
//		cout << rcut_new << endl;
		if(insert_ok){rcut_new*=0.99;i-=2;continue;};
		Sort_Type(newstruc[i],nions);
		Get_Type(newstruc[i],nions,tmp_type,ga_info.ntype);
        	DirKar(newlatt[i],newstruc[i],nions);
        }
	delete[] postmp1;
	delete[] postmp2;
	delete[] inout_1;
	delete[] inout_2;
	return mating_p;
}

int Within_Planes(Posion pos,double center, double width,int which_plane){
        // abc is sqrt(A^2+B^2+C^2) for later Point-Plane distance calculation;
	double x;
	switch (which_plane){
		case 0: x=pos.x;break;
		case 1: x=pos.y;break;
		case 2: x=pos.z;break;
		default: x=pos.x;
	}
	if(x < (center+width) && x > (center-width)){
		return 1;
	} else{
		return 0;
	}
}


double Mating(const Posion *pos1, const Posion *pos2, const Posion *latt1, const Posion *latt2, Posion *newlatt[],Posion *newstruc[], int nions, 
	      int *atom_type_target, int ntype, double rcut,Posion *site,int nsite){
        int i,j;
        Posion center,slice_dir,shift_atom;
        Posion plane_1, plane_2;
	Posion slab_1[2],slab_2[2];
	Posion *postmp1, *postmp2;
	Posion **posdbg;
        double width,d,mating_p,mating_width = rcut*4;
        int *inout_1,*inout_2,nin_1,nin_2;
	int *tmp_type = new int[ntype];
	postmp1 = new Posion[nions];
	postmp2 = new Posion[nions];
	posdbg = new Posion*[2];
	posdbg[0] = new Posion[nions];
	posdbg[1] = new Posion[nions];
        for (i = 0; i < nions; i++){
		postmp1[i] = pos1[i];
		postmp2[i] = pos2[i]; 
	}
// Lattice mating
	KarDir(latt1,postmp1,nions); KarDir(latt2,postmp2,nions);
	DirKar(latt1,postmp1,nions); DirKar(latt2,postmp2,nions);
	KarDir(latt1,postmp1,nions); KarDir(latt2,postmp2,nions);
	newlatt[0][0]   = (latt1[0] + latt2[0]) / 2;
	newlatt[0][1]   = (latt1[1] + latt2[1]) / 2;
	newlatt[0][2]   = (latt1[2] + latt2[2]) / 2;
	newlatt[1][0] = (latt1[0] + latt2[0]) / 2;
	newlatt[1][1] = (latt1[1] + latt2[1]) / 2;
	newlatt[1][2] = (latt1[2] + latt2[2]) / 2;
	double oldvol = Cell_Volume(latt1);
	double newvol = Cell_Volume(newlatt[0]);
	newvol = cbrt(newvol/oldvol);
	newlatt[0][0] = newlatt[0][0]/newvol;
	newlatt[0][1] = newlatt[0][1]/newvol;
	newlatt[0][2] = newlatt[0][2]/newvol;
	newlatt[1][0] = newlatt[1][0]/newvol;
	newlatt[1][1] = newlatt[1][1]/newvol;
	newlatt[1][2] = newlatt[1][2]/newvol;
	DirKar(newlatt[0],postmp1,nions); DirKar(newlatt[1],postmp2,nions);
	
        inout_1=new int[nions];
        inout_2=new int[nions];
	double rcut_new = rcut;

// determine slice plane direction;        
        for (i = 0; i < 2; i=i+2){
// set mating slab
	        center=(newlatt[0][0]+newlatt[0][1]+newlatt[0][2])/2.0;
//	        slice_dir=newlatt[0][0]*RandomDouble(0,1.0)+newlatt[0][1]*RandomDouble(0,1.0)+newlatt[0][2]*RandomDouble(0,1.0);
		switch(RandomInt(0,2)){
			case 0:
				XPro(newlatt[0][0],newlatt[0][1],slice_dir);
				break;
			case 1:
				XPro(newlatt[0][1],newlatt[0][2],slice_dir);
				break;
			case 2:
				XPro(newlatt[0][2],newlatt[0][0],slice_dir);
				break;
		}
	        double norm=slice_dir.x*slice_dir.x+slice_dir.y*slice_dir.y+slice_dir.z*slice_dir.z;
	        norm = sqrt(norm); slice_dir=slice_dir/norm;
// choose slab width
		width = (center.x*slice_dir.x+center.y*slice_dir.y+center.z*slice_dir.z)*RandomDouble(0.0,1.0);

	        center=newlatt[0][0]*RandomDouble(0,1)
		      +newlatt[0][1]*RandomDouble(0,1)
		      +newlatt[0][2]*RandomDouble(0,1);
	        // plane_1 is center slice + slicewidth, plane_2 is -.
       	 	//width = (center.x+center.y+center.z)/3;
	        plane_1 = center + slice_dir*width/2.0;
		slab_1[0] = plane_1 - slice_dir*mating_width/2.0; slab_1[1] = plane_1 + slice_dir*mating_width/2.0;
	        plane_2 = center - slice_dir*width/2.0;
		slab_2[0] = plane_2 - slice_dir*mating_width/2.0; slab_2[1] = plane_2 + slice_dir*mating_width/2.0;
	
	        // change to Ax+By+Cz+D=0 form, D=1;
	        d = -(slice_dir.x*plane_1.x+slice_dir.y*plane_1.y+slice_dir.z*plane_1.z);
                plane_1 = slice_dir/d;
	        d = -(slice_dir.x*slab_1[0].x+slice_dir.y*slab_1[0].y+slice_dir.z*slab_1[0].z);
                slab_1[0] = slice_dir/d;
	        d = -(slice_dir.x*slab_1[1].x+slice_dir.y*slab_1[1].y+slice_dir.z*slab_1[1].z);
                slab_1[1] = slice_dir/d;
	
	        d = -(slice_dir.x*plane_2.x+slice_dir.y*plane_2.y+slice_dir.z*plane_2.z);
                plane_2 = slice_dir/d;
	        d = -(slice_dir.x*slab_1[0].x+slice_dir.y*slab_1[0].y+slice_dir.z*slab_1[0].z);
                slab_2[0] = slice_dir/d;
	        d = -(slice_dir.x*slab_1[1].x+slice_dir.y*slab_1[1].y+slice_dir.z*slab_1[1].z);
                slab_2[1] = slice_dir/d;

		// Divide the supercell
		double d_1,d_2,abc_1,abc_2;
                abc_1=sqrt(plane_1.x*plane_1.x+plane_1.y*plane_1.y+plane_1.z*plane_1.z);
                abc_2=sqrt(plane_2.x*plane_2.x+plane_2.y*plane_2.y+plane_2.z*plane_2.z);


                nin_1=0;nin_2=0;

                for (j = 0; j < nions; j++){
			newstruc[i][j].x=newstruc[i][j].y=newstruc[i][j].z=newstruc[i][j].ityp = 0;
			newstruc[i+1][j].x=newstruc[i+1][j].y=newstruc[i+1][j].z=newstruc[i+1][j].ityp = 0;
			posdbg[0][j].x=posdbg[0][j].y=posdbg[0][j].z=posdbg[0][j].ityp= 0;
			posdbg[1][j].x=posdbg[1][j].y=posdbg[1][j].z=posdbg[1][j].ityp= 0;
			inout_1[j] = Within_Planes(plane_1, plane_2, postmp1[j], width);
			nin_1+=inout_1[j];
			inout_2[j] = Within_Planes(plane_1, plane_2, postmp2[j], width);
			nin_2+=inout_2[j]; 

                }
                int child_1=0,child_2=0; // child atoms generation counting
		if(nin_1 ==0 || nin_2 == 0 || nin_1 == nions || nin_2 == nions) {
//			i = i - 2;continue;;
		}
     //		cout << "mating percentage = " << float(nin_1)/float(nions) << endl;
		mating_p = double(nin_1)/double(nions);
		for (j = 0; j < nions; j++){
                     	if ( inout_1[j]==0 ) {
     				if (child_1 < nions && postmp1[j].ityp != 0){
                             		newstruc[i][child_1]=postmp1[j];
					posdbg[0][child_1]=postmp1[j];
					posdbg[0][child_1].ityp=1;
                             		child_1++;
     				}
                     	} else {
     				if (child_2 < nions && postmp1[j].ityp != 0){
                             		newstruc[i+1][child_2]=postmp1[j];
					posdbg[1][child_2]=postmp1[j];
					posdbg[1][child_2].ityp=1;
                             		child_2++;
     				}
                     	}
                     	if ( inout_2[j]==1 ) {
     				if (child_1 < nions && postmp2[j].ityp != 0){
                             		newstruc[i][child_1]=postmp2[j];
					posdbg[0][child_1]=postmp2[j];
					posdbg[0][child_1].ityp=2;
                       		      	child_1++;
     				}
                     	} else {
     				if (child_2 < nions && postmp2[j].ityp != 0){
                             		newstruc[i+1][child_2]=postmp2[j];
					posdbg[1][child_2]=postmp2[j];
					posdbg[1][child_2].ityp=2;
                             		child_2++;
     				}
                     	}
             	}
		//Print_Structure(newlatt[i],postmp2,atom_type,ntype,10);
		Sort_Type(posdbg[0],nions);
		Sort_Type(posdbg[1],nions);
		double enetmp[2];
//		Write_xyz("./posdbg.xyz",posdbg, enetmp,2,nions);

                Check_Child_bond(newlatt[i], newstruc[i],nions,rcut_new);
		Sort_Type(newstruc[i],nions);
		Get_Type(newstruc[i],nions,tmp_type,ntype);
		int one_fix=0;
		for (j = 0; j < nions; j++)
			if(newstruc[i][j].x == 0.0 && newstruc[i][j].y == 0.0 && newstruc[i][j].z == 0.0 &&
			   newstruc[i][j].ityp == 1 ){
				one_fix = 1;
				newstruc[i][j] = newstruc[i][tmp_type[0]];
				newstruc[i][tmp_type[0]].x=newstruc[i][tmp_type[0]].y=newstruc[i][tmp_type[0]].z=0;
				newstruc[i][tmp_type[0]].ityp = 0;
				tmp_type[0]++;
				tmp_type[1]--;
				atom_type_target[1]--;
				break;
			}

//		Print_Structure(newlatt[i],newstruc[i],tmp_type,ntype,nions);

		// adjust structure by type switch
		// switch in slabs
		int undefined = 0;

		for (j = tmp_type[0]; j < nions; j++){
			if( (Within_Planes(slab_1[0], slab_1[1], newstruc[i][j],mating_width) ||
			     Within_Planes(slab_2[0], slab_2[1], newstruc[i][j],mating_width))&& 
			     tmp_type[newstruc[i][j].ityp] > atom_type_target[newstruc[i][j].ityp] ) {
				tmp_type[newstruc[i][j].ityp]--;
				undefined++;
				newstruc[i][j].ityp = 999;
			}
		}
		// switch in others
		Shuffle_atom(newstruc[i],nions);
		Sort_Type(newstruc[i],nions);
		for (j = tmp_type[0]; j < nions - undefined; j++){
			if( tmp_type[newstruc[i][j].ityp] > atom_type_target[newstruc[i][j].ityp] ) {
				tmp_type[newstruc[i][j].ityp]--;
				newstruc[i][j].ityp = 999;
			}
		}

		for (j = tmp_type[0]; j < nions; j++){
			if(newstruc[i][j].ityp == 999) {
				for (int k = 1; k < ntype; k++){
					if(tmp_type[k] < atom_type_target[k] ){
						tmp_type[k]++;
						newstruc[i][j].ityp = k;
					}
				}
			}
		}
		for (j = tmp_type[0]; j < nions; j++)
			if(newstruc[i][j].ityp == 999) 
				newstruc[i][j].x=newstruc[i][j].y=newstruc[i][j].z=newstruc[i][j].ityp = 0;

		// adjust structure by adding new atom in slabs.
		Posion add_atom;
		Sort_Type(newstruc[i],nions);
		Get_Type(newstruc[i],nions,tmp_type,ntype);
        	KarDir(newlatt[i],newstruc[i],nions);

		int insert_ok = 0;
		for (j = 1; j < ntype; j++) {
                        int accept = 1;
			if(tmp_type[j] < atom_type_target[j] ){
                                while(accept&&accept<1000){
                                        add_atom.x=RandomDouble(0,1);
                                        add_atom.y=RandomDouble(0,1);
                                        add_atom.z=RandomDouble(0,1);
					if(nsite != 0) add_atom = site[RandomInt(1,nsite)-1];
					add_atom.ityp = j;
                                        int k;
                                        for (k = 0; k < nions; k++) 
                                                if(Bond_length(newlatt[i],newstruc[i][k],add_atom) < rcut_new ){
							accept++;break;
						}
                                        if (k==nions) {
						DirKar(newlatt[i],&add_atom,1);
						if( Within_Planes(slab_1[0], slab_1[1], add_atom,mating_width) ||
						    Within_Planes(slab_2[0], slab_2[1], add_atom,mating_width)) {
							KarDir(newlatt[i],&add_atom,1);
							accept = 0;
							newstruc[i][tmp_type[0]-1].x = add_atom.x;
							newstruc[i][tmp_type[0]-1].y = add_atom.y;
							newstruc[i][tmp_type[0]-1].z = add_atom.z;
							newstruc[i][tmp_type[0]-1].ityp = j;
							tmp_type[0]--;
							tmp_type[j]++;
//							cout << "error" << endl;
						} else accept++;
					}
                                }
				j--;
			}
			if(accept>=1000) {insert_ok=1;break;}
		}
		if(one_fix == 1) {
			newstruc[i][tmp_type[0]-1].ityp = 1;
			atom_type_target[1]++;
		}
		if(insert_ok){rcut_new=rcut_new*0.99;i=i-2;cout << rcut_new << endl;continue;};
		Sort_Type(newstruc[i],nions);
		Get_Type(newstruc[i],nions,tmp_type,ntype);
        	DirKar(newlatt[i],newstruc[i],nions);
//                cout << Check_Child_bond(newlatt[i], newstruc[i],nions,rcut) << ' ' << rcut << endl;
                cout <<  Check_bond(newlatt[i], newstruc[i],nions) << ' ' << rcut << endl;
        }
	delete[] postmp1;
	delete[] postmp2;
	delete[] inout_1;
	delete[] inout_2;
	return mating_p;
}

int Within_Planes(Posion plane_1, Posion plane_2, Posion pos, double width){
        // abc is sqrt(A^2+B^2+C^2) for later Point-Plane distance calculation;
	double abc_1,abc_2,d_1,d_2;
	abc_1=sqrt(plane_1.x*plane_1.x+plane_1.y*plane_1.y+plane_1.z*plane_1.z);
	abc_2=sqrt(plane_2.x*plane_2.x+plane_2.y*plane_2.y+plane_2.z*plane_2.z);
	d_1 = plane_1.x*pos.x + plane_1.y*pos.y + plane_1.z*pos.z + 1; d_1 = fabs(d_1)/abc_1;
	d_2 = plane_2.x*pos.x + plane_2.y*pos.y + plane_2.z*pos.z + 1; d_2 = fabs(d_2)/abc_2;
	if(d_1 > width || d_2 > width){
	// outside slab
		return 0;
	} else{
	// inside slab
		return 1;
	}
}


 
void Mutate_Type(Posion *pos, GAPara ga_info){
        double tmp;
	int m,n,s1,s2;
	int ntype,*atom_type;
	int nions = ga_info.nions;
	ntype = pos[nions-1].ityp + 1;
	if(ntype <=2 ) return;
	atom_type = new int[ntype];
	Get_Type(pos,nions,atom_type,ntype);
	for (int i = 0; i < 2; i++){
		m = RandomInt(0, nions-1); n = RandomInt(0, nions-1);
		s1 = pos[m].ityp; s2 = pos[n].ityp;
		if(s1 == s2){
			i--; continue;
		}
		if(ga_info.mut_control[s1] == 0 || ga_info.mut_control[s2] == 0 || ga_info.mut_control[s1] != ga_info.mut_control[s2]){
			i--; continue;
		}
		tmp = pos[m].x; pos[m].x = pos[n].x; pos[n].x = tmp;
		tmp = pos[m].y; pos[m].y = pos[n].y; pos[n].y = tmp;
		tmp = pos[m].z; pos[m].z = pos[n].z; pos[n].z = tmp;
		//cout << "Type Mutated " << m << ' ' << n << endl;
	}
	delete[] atom_type;
}
                        
void Mutate_2Dz(Posion *pos, GAPara ga_info){
	int nions = ga_info.nions;
	double shiftz = 0.0;
	for(int i=0; i<nions; i++){
		double p1=RandomDouble(0,1);
		if(p1<0.5){   //shift z of atom i by an amount of shiftz
			if(ga_info.zslab/10 > 0.2)shiftz = 0.2;
			else shiftz=ga_info.zslab/10;
			double p2=RandomDouble(0,1);
			if(p2<0.5 && pos[i].z-shiftz >= 0)
				pos[i].z = pos[i].z - shiftz;
			else if(pos[i].z+shiftz < ga_info.zslab)
				pos[i].z = pos[i].z + shiftz;
		}
	}
}

void Check_Pool(Posion *latt[], Posion *pos[], double *ene, int *struc_id, int *atom_type,vector<float> * bondlist, int sub_poolsize,GAPara ga_info,int whereis, 
                double *latt_fixedt, double *latt_fixedb, double *latt_bufft, double *latt_buffb, 
                double *pos_fixedt, double *pos_fixedb, double *pos_bufft, double *pos_buffb, double *vec_fixedt){
	double ene_1,ene_2,dev, dev_vec, vec_dev[3], tmp_dev;
//	Posion tmp_latt[3];  //for vector comparison
//	for(int x=0; x<3; x++)tmp_latt[x] = latt[0][x];
	int new_nions = ga_info.nions+ga_info.temp_nions+ga_info.tmpatoms;
	double *newpos = new double[new_nions*4];
	double *pos_inter = new double[ga_info.nions*4];
	double newlatt[12];
	double latt_inter[12];

	Posion **latt_tmp = new Posion*[1];
	latt_tmp[0] = new Posion[3];
	Posion **pos_tmp = new Posion*[1];
	pos_tmp[0] = new Posion[ga_info.nions];
	Posion **latt_all = new Posion*[1];
	latt_all[0] = new Posion[3];
	Posion **pos_all = new Posion*[1];
	pos_all[0] = new Posion[new_nions];

	int ndeleted=0;
	int poolsize = ga_info.NPOOL;
	if(sub_poolsize<=1) sub_poolsize=poolsize;
	int ngroup = poolsize/sub_poolsize;
        if(Read_template_head() == 0 && Read_site_head() == 0 && ga_info.systype !=2 && ga_info.dimen != 2){
		for ( int l = 0; l < poolsize; l++) {
			int tmptmp;
			tmptmp = RandomInt(0,atom_type[l*ga_info.ntype+1]-1)+atom_type[l*ga_info.ntype];
			Posion shift_atom = pos[l][tmptmp];
			pos[l][tmptmp]=pos[l][atom_type[l*ga_info.ntype]];
			pos[l][atom_type[l*ga_info.ntype]] = shift_atom;
		 	for (int i = atom_type[l*ga_info.ntype]; i < ga_info.nions; i++) {
				pos[l][i].x -= shift_atom.x;
				pos[l][i].y -= shift_atom.y;
				pos[l][i].z -= shift_atom.z;
			}
		}
	}
        for ( int l = 0; l < ngroup; l++)
        for ( int i = l*sub_poolsize+sub_poolsize/4*whereis; i < (l+1)*sub_poolsize; i++){
                if(Check_bond(latt[i],pos[i],ga_info.nions) < 0.6){
                	Init_Structure(latt[i],pos[i],atom_type+i*ga_info.ntype,ga_info,vec_fixedt+i*3);
			bondlist[i].clear();
                        ene[i]=ENENONE;
                }
	}

	bool out = 1;
        for ( int l = 0; l < poolsize; l++) KarDir(latt[l],pos[l],ga_info.nions);
        for ( int l = 0; l < ngroup; l++)
        for ( int i = l*sub_poolsize; i < (l+1)*sub_poolsize; i++){
                for ( int j = l*sub_poolsize+sub_poolsize/4*whereis; j < (l+1)*sub_poolsize; j++){
			if(i != j && fabs(ene[i]-ene[j])/ga_info.nions < 0.5 && ene[i] != ENENONE) {
				if(ga_info.systype == 2){
					//structure i
					if(bondlist[i].size()==0)
					{
					DirKar(latt[i], pos[i], ga_info.nions);
					for(int xx=0; xx<3; xx++)latt_tmp[0][xx] = latt[i][xx];
					for(int xx=0; xx<ga_info.nions; xx++)pos_tmp[0][xx]=pos[i][xx];
					Convert_structure(pos_tmp, pos_inter, 1, ga_info.nions);
					Convert_structure(latt_tmp, latt_inter, 1, 3);
					Merge_interface(pos_inter,pos_fixedt, pos_fixedb, pos_bufft, pos_buffb, newpos, latt_inter, latt_fixedt, latt_fixedb, latt_bufft, latt_buffb, newlatt, vec_fixedt+3*i, ga_info);
					for(int x=0; x<new_nions; x++)newpos[x*4+3]=int(newpos[x*4+3]+0.01)%10;
					Convert_structure(newpos, pos_all, 1, new_nions);
					Convert_structure(newlatt, latt_all, 1, 3);
					KarDir(latt[i],pos[i],ga_info.nions);
					KarDir(latt_all[0], pos_all[0], new_nions);
					CreateBondList(latt_all[0], pos_all[0], new_nions, bondlist+i,ga_info.rcut*4.0);
					}
					//structure j
					if(bondlist[j].size()==0)
					{
					DirKar(latt[j], pos[j], ga_info.nions);
					for(int xx=0; xx<3; xx++)latt_tmp[0][xx] = latt[j][xx];
					for(int xx=0; xx<ga_info.nions; xx++)pos_tmp[0][xx]=pos[j][xx];
					Convert_structure(pos_tmp, pos_inter, 1, ga_info.nions);
					Convert_structure(latt_tmp, latt_inter, 1, 3);
					Merge_interface(pos_inter,pos_fixedt, pos_fixedb, pos_bufft, pos_buffb, newpos, latt_inter, latt_fixedt, latt_fixedb, latt_bufft, latt_buffb, newlatt, vec_fixedt+3*j, ga_info);
					for(int x=0; x<new_nions; x++)newpos[x*4+3]=int(newpos[x*4+3]+0.01)%10;
					Convert_structure(newpos, pos_all, 1, new_nions);
					Convert_structure(newlatt, latt_all, 1, 3);
					KarDir(latt[j],pos[j],ga_info.nions);
					KarDir(latt_all[0], pos_all[0], new_nions);
					CreateBondList(latt_all[0], pos_all[0], new_nions, bondlist+j,ga_info.rcut*4.0);
					}
				}else{
					if(bondlist[i].size()==0)CreateBondList(latt[i], pos[i], ga_info.nions, bondlist+i,ga_info.rcut*4.0);
					if(bondlist[j].size()==0)CreateBondList(latt[j], pos[j], ga_info.nions, bondlist+j,ga_info.rcut*4.0);
				}
				dev = Compare_Structure(bondlist[i],bondlist[j]);
//				cout << "vector checked " << struc_id[i] << ' ' << struc_id[j] << ' ' << dev_vec << endl;
//				cout << "structure checked " << struc_id[i] << ' ' << struc_id[j] << ' ' << dev << endl;
			} else {dev = ga_info.criteria;}
                        if (dev < ga_info.criteria) {
				if(ene[i] <= ene[j]){
					ene[j] = ENENONE;
					ndeleted++;
					cout << "structure " << struc_id[j] << " deleted, same as " << struc_id[i] <<" " << dev;
					if(ga_info.systype == 2) cout << " " << dev_vec << endl;
					else cout << endl;
                			Init_Structure(latt[j],pos[j],atom_type+j*ga_info.ntype,ga_info, vec_fixedt+j*3);
					bondlist[j].clear();
	        			KarDir(latt[j],pos[j],ga_info.nions);
				}
				else{
                                        ene[i] = ENENONE;
                                        ndeleted++;
                                        cout << "structure " << struc_id[i] << " deleted, same as " << struc_id[j] <<" "<<dev;
					if(ga_info.systype == 2) cout << " " << dev_vec << endl;
					else cout << endl;
                                        Init_Structure(latt[i],pos[i],atom_type+i*ga_info.ntype,ga_info, vec_fixedt+i*3);
                                        bondlist[i].clear();
                                        KarDir(latt[i],pos[i],ga_info.nions);
				}
                        }
                }
	}
        for ( int l = 0; l < poolsize; l++) DirKar(latt[l],pos[l],ga_info.nions);
	cout << ndeleted << " structures deleted" << endl;
}

int CreateBondList(Posion *latt, Posion *pos, int nions, vector<float> *bondlist,double neighcut){
	double d1,d2,d3, a_frac,b_frac,c_frac;
        int I1,I2,I3;
	int ntypes = pos[nions-1].ityp;
	const double bond_type = 100.0;
	Posion latt_b[3],dr;
	vector<float> bondtmp;
	double len;
	int first,last,ii,jj,kk;
        for (int i = 0; i < nions; i++)
                if (pos[i].ityp != 0){ first = i; break; }
#ifdef PWSCF
        for (int i = 0; i < nions; i++)
                if (pos[i].ityp == 2){ last = i-1; break; }
#else
	last = nions;
#endif
	bondlist->clear();
	Latt_A2B(latt,latt_b);
	a_frac = sqrt(latt_b[0].x*latt_b[0].x+latt_b[0].y*latt_b[0].y+latt_b[0].z*latt_b[0].z);
	b_frac = sqrt(latt_b[1].x*latt_b[1].x+latt_b[1].y*latt_b[1].y+latt_b[1].z*latt_b[1].z);
	c_frac = sqrt(latt_b[2].x*latt_b[2].x+latt_b[2].y*latt_b[2].y+latt_b[2].z*latt_b[2].z);
	I1=int(neighcut*a_frac-.001);
	I2=int(neighcut*b_frac-.001);
	I3=int(neighcut*c_frac-.001);

        for (int m = -I1-1; m <= I1+1; m++)
        for (int n = -I2-1; n <= I2+1; n++)
        for (int l = -I3-1; l <= I3+1; l++){
	        for (int i = first; i < last; i++)
			for (int j = first; j < last; j++){
				if(pos[i].ityp == 0 || pos[j].ityp == 0)continue;
                		dr.x=dr.y=dr.z=0.0;
				d1 = pos[i].x-pos[j].x+10.5;
				d2 = pos[i].y-pos[j].y+10.5;
				d3 = pos[i].z-pos[j].z+10.5;
				d1 = m + d1 - 0.5 - int(d1);
				d2 = n + d2 - 0.5 - int(d2);
				d3 = l + d3 - 0.5 - int(d3);
                		dr = dr + latt[0]*d1;
		                dr = dr + latt[1]*d2;
               			dr = dr + latt[2]*d3;
		                len = sqrt(dr.x*dr.x + dr.y*dr.y + dr.z*dr.z);
				if(len > 0.5 && len < neighcut) {
						ii = pos[i].ityp-1;
						jj = pos[j].ityp-1;
						kk = (ii <= jj) ? ii * ntypes + jj - ((ii * (ii + 1)) / 2) : jj * ntypes + ii - ((jj * (jj + 1)) / 2);
						bondlist->push_back(len+double(kk)*bond_type);
				}
                	}
	}
	sort(bondlist->begin(),bondlist->end());
	return bondlist->size();
}

double Compare_Structure(vector<float> bond1,vector<float> bond2){
        float total_dev = 0.0;
        int j,k,bondsize1 = bond1.size();
        int bondsize2 = bond2.size();
        int bondsize = bondsize1<bondsize2?bondsize1:bondsize2;
        float scalefact = bond1[0]/bond2[0];
        float max = 0.0,diff;
        int i_max=0;

// compare scheme I
	j=k=0;
	//cout << "Bond size = " << bondsize << endl;
        for ( int i = 0; i < bondsize; i++) { 
		diff=bond1[j]-bond2[k];
		if(diff > 50)
			k++;
		else if(diff<-50)
			j++;
		else{
			diff = fabs(diff);
	                if (diff > max) max = diff;
			j++;k++;
		}
		if(j>bondsize || k > bondsize) break;
        }


// compare scheme II
/*	bondsize = bondsize > 10000? 10000:bondsize;
	j=k=0;
        for ( int i = 0; i < bondsize; i++) { 
		diff=fabs(bond1[i]-bond2[i]);
	        if (diff > max) max = diff;
        }
*/
       	//         cout << bond1[i] << ' ' << bond2[i] << endl;
                //	total_dev += fabs(bond1[i] - bond2[i]);
//        return total_dev;
        return max;
}

int Check_Child(Posion *parent, Posion *child, int nions){
        int ifsame=0;
        for (int i = 0; i < nions; i++)
                for (int j = 0; j < nions; j++)
                if (child[i].x==parent[j].x &&
                    child[i].y==parent[j].y &&
                    child[i].z==parent[j].z &&
                    child[i].ityp==parent[j].ityp)
                        ifsame++;

        if (ifsame == nions) return 1;
        else return 0;
}

int Check_Child_bond(Posion *latt, Posion *pos, int nions, double rcut){
        KarDir(latt,pos,nions);
	int ret = 0;
        for (int i = 0; i < nions; i++)
                for (int j = i+1; j < nions; j++) {
                        if(Bond_length(latt,pos[i],pos[j]) < rcut && pos[i].ityp != 0 && pos[j].ityp != 0){
                                pos[j].x=pos[j].y=pos[j].z=pos[j].ityp=0;
				ret = 1;
                        }
                }
        DirKar(latt,pos,nions);
	return ret;
}

double Check_bond(const Posion *latt, Posion *pos, int nions){
        KarDir(latt,pos,nions);
	double minbond=99.0,tmp;
        for (int i = 0; i < nions; i++)
                for (int j = i+1; j < nions; j++) {
			if(pos[i].ityp == 0 || pos[i].ityp == 0)continue;
                        tmp = Bond_length(latt,pos[i],pos[j]);
			if (tmp < minbond) minbond = tmp;
                }
        DirKar(latt,pos,nions);
	return minbond;
}

int test_file(char *str){
        fstream fin(str,ios::in);
        if(!fin) {
		fin.open(str,ios::out);
		fin.flush();
        	fin.close();
		return 1;
	}
        return 0;
}

int Accept(double e, double t){
	double p = exp(e/t);
	double accept = RandomDouble(0,1);
	if( accept <= p ) return 1;
	else return 0;
}

void MC_Move(Posion *pos, int nions, double temp, int mdsteps){
	// temperature in eV unit;
	double vx,vy,vz,factor;
  	double boltz = 8.617343e-5;
  	double UL =1E-10;
  	double UT =1E-15;
  	double AMTOKG=1.6605402E-27;
  	double EVTOJ=1.60217733E-19;
  	double FACT= (AMTOKG/EVTOJ)*(UL/UT)*(UL/UT);


        factor = sqrt(temp*boltz/FACT);
  	for (int j = 0; j < mdsteps; j++) {
	  	for (int i = 1; i < nions; i++) {
			;
//        		pos[i].x += RandomGaussian(0.0,factor);
 //       		pos[i].y += RandomGaussian(0.0,factor);
  //      		pos[i].z += RandomGaussian(0.0,factor);
		}
	}
}
void Potfit_Input(GAPara ga_info){
	cout << "Writing potfit.in .. ";
        fstream fout("./potfit.in",ios::out);
        fout << "ntypes          "  << ga_info.ntype-1 << endl;
        fout << "config          pot.config" << endl;
	fout << "startpot        mypot_start" << endl;
        fout << "endpot          mypot_end" << endl;
	fout << "tempfile        mypot.tmp" << endl;
	fout << "plotfile        mypot.plot" << endl;
	fout << "output_prefix   out" << endl;
	fout << "flagfile        STOP \n" << endl;

	fout << "# general options " << endl;
	fout << "plotpointfile   sampling " << endl;
        fout << "opt   1 " << endl;
        fout << "anneal_temp     1.0 " << endl;
        fout << "plotmin         0.0 " << endl;
        fout << "eng_weight      " << ga_info.eweight << endl;
	fout << "stress_weight   " << ga_info.sweight << endl;
        fout << "d_eps           0.0001 " << endl;
	fout << "write_lammps    1" << endl;
        fout.close();
	cout << "done." << endl;
}

void LJ_POT(char *filename_in,char *filename_out,GAPara ga_info){
        fstream fin(filename_in,ios::in);
        fstream fout(filename_out,ios::out);
        double p1,p2,p_min,p_max;
        char str[256];
        for(int i=0;i<6;i++) fin.getline(str,256);
        fout <<"pair_style lj/cut 8.0" << endl;
        for(int i = 1; i < ga_info.ntype; i++)
                for(int j = i; j < ga_info.ntype; j++){
                        fin.getline(str,256);
                        fin.getline(str,256);
                        fin.getline(str,256);
                        fin >> str >> p1 >> p_min >> p_max;
                        fin >> str >> p2 >> p_min >> p_max;
                        p1=fabs(p1); p2=fabs(p2);
                        fout << "pair_coeff " << i << ' ' << j << ' '  << p1 << ' ' << p2  << endl;
                        fin.getline(str,256);
                        fin.getline(str,256);
                }
        fin.close();
        fout.close();
}

void MORSE_POT(char *filename_in,char *filename_out,GAPara ga_info){
        fstream fin(filename_in,ios::in);
        fstream fout(filename_out,ios::out);
        double p1,p2,p3,p_min,p_max;
        char str[256];
        for(int i=0;i<6;i++) fin.getline(str,256);
        fout <<"pair_style morse 6.0" << endl;
//              cout <<"pair_modify shift yes" << endl;
        for(int i = 1; i < ga_info.ntype; i++)
                for(int j = i; j < ga_info.ntype; j++){
                        fin.getline(str,256);
                        fin.getline(str,256);
                        fin.getline(str,256);
                        fin >> str >> p1 >> p_min >> p_max;
                        fin >> str >> p2 >> p_min >> p_max;
                        fin >> str >> p3 >> p_min >> p_max;
                        //p1=fabs(p1); p2=fabs(p2);p3=fabs(p3);
                        fout << "pair_coeff " << i << ' ' << j << ' '  << p1 << ' ' << p2  << ' ' << p3 << " 6.0"<< endl;
                        fin.getline(str,256);
                        fin.getline(str,256);
                }
        fin.close();
        fout.close();
}

void potgen(char *filename){
        fstream fin(filename,ios::in);
        fstream fout("./SiO.pot",ios::in);
        double p,p_min,p_max;
        char str[256];
        for(int i=0;i<6;i++){
                fin.getline(str,256);
                fout << str << endl;
        }
        for(int i=0;i<3;i++){
                fin.getline(str,256); fout << str << endl;
                fin.getline(str,256); fout << str << endl;
                fin.getline(str,256); fout << str << endl;
                fin >> str >> p >> p_min >> p_max;
                p_max = (p<10)?(p+10.0):p*2.0;
                fout << str << ' ' << p << ' ' << p_min+1e-10 << ' ' << p_max << endl;
                fin >> str >> p >> p_min >> p_max;
                fout << str << ' ' << p << ' ' << p_min+1e-10 << ' ' << 20.0 << endl;
                fin.getline(str,256); fout << str << endl;
                fin.getline(str,256);
        }
        for(int i=0;i<43;i++){
                fin.getline(str,256);
                fout << str << endl;
        }

        fin.close();
        fout.close();
}

void EAM_POT(char *filename_in,char *filename_out,GAPara ga_info){
	int temp_nions = Read_template_head();
        fstream fout(filename_out,ios::out);
	if(temp_nions==0){
		fout << "pair_style eam/alloy" << endl;
		if(ga_info.ntype==2) fout << "pair_coeff * * ./adaptive.alloy Fe" << endl;
		if(ga_info.ntype==3) fout << "pair_coeff * * ./adaptive.alloy Fe Co" << endl;
		if(ga_info.ntype==4) fout << "pair_coeff * * ./adaptive.alloy Fe Co Ni" << endl;
	}else{
		fout << "pair_style hybrid/overlay eam/alloy" << endl;
		fout << "pair_coeff * * tersoff  Si.tersoff Si Si Si Si" << endl;
		fout << "pair_coeff * * eam/alloy ./adaptive.alloy Fe Co Ni Co " << endl;
		fout << "pair_coeff 1 4 none" << endl;
		fout << "pair_coeff 2 4 none" << endl;
		fout << "pair_coeff 3 4 none" << endl;
		fout << "pair_coeff 4 4 none" << endl;
		fout.close();
	}
}


int WhereWeAre(int comp){
	fstream fin;
	char filename[32];
	for(int i = 0; i < 1000; i++){
		sprintf(filename,"%s_%d_%d","./pool_dft",comp,i);
		fin.open(filename, ios::in);
		if(!fin) return i;
		else fin.close();
	}
	return 0;
}
