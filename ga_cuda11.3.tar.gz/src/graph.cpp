#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <math.h>

#include "seqlist.h"
#include "graph.h"

using namespace std;
   // Overload operator for Posion
void Pause(void){
        char a;
        cout <<  " Pause ";
        cin >> a;
        return;
}

void Debug(double info){
	cerr << "jimin" << " " << info << endl;
}

void int_to_str(int a, char *str,int len){
	sprintf(str,"%0*d",len,a);
}



Posion operator+(Posion pos1,Posion pos2){
        Posion temp;
        temp.x = pos1.x + pos2.x;
        temp.y = pos1.y + pos2.y;
        temp.z = pos1.z + pos2.z;
        return temp;
}

Posion operator-(Posion pos1,Posion pos2){
        Posion temp;
        temp.x = pos1.x - pos2.x;
        temp.y = pos1.y - pos2.y;
        temp.z = pos1.z - pos2.z;
	temp.ityp = pos1.ityp;
        return temp;
}

Posion operator*(Posion pos1,Posion pos2){
        Posion temp;
        temp.x = pos1.x * pos2.x;
        temp.y = pos1.y * pos2.y;
        temp.z = pos1.z * pos2.z;
        return temp;
}


Posion operator*(Posion pos1,double c){
        Posion temp;
        temp.x = pos1.x*c;
        temp.y = pos1.y*c;
        temp.z = pos1.z*c;
        return temp;
}

Posion operator/(Posion pos1,double c){
        Posion temp;
        temp.x = pos1.x/c;
        temp.y = pos1.y/c;
        temp.z = pos1.z/c;
        return temp;
}

Posion operator+(Posion pos1,double c){
        Posion temp;
        temp.x = pos1.x+c;
        temp.y = pos1.y+c;
        temp.z = pos1.z+c;
        return temp;
}

Posion operator-(Posion pos1,double c){
        Posion temp;
        temp.x = pos1.x-c;
        temp.y = pos1.y-c;
        temp.z = pos1.z-c;
        return temp;
}

ostream &operator<<(ostream &stream, Posion pos){
  stream << setiosflags(ios::fixed) << setw(10) << setprecision(6) << pos.x << ' ';
  stream << setiosflags(ios::fixed) << setw(10) << setprecision(6) << pos.y << ' ';
  stream << setiosflags(ios::fixed) << setw(10) << setprecision(6) << pos.z ;
  return stream;
}

istream &operator>>(istream &stream, Posion pos){
  stream >> pos.x >> pos.y >> pos.z;
  return stream;
}

// Class Graph declaration

POS Graph::RowCol (POS col, POS row) {
  if ( row == col )
    return graphsize * (graphsize - 1 ) / 2 + 1;
  else {
    if ( col < row )
      return  (graphsize * 2 - col) * (col - 1) / 2 + row - col;
    else
      return  (graphsize * 2 - row) * (row - 1) / 2 + col - row;
  }
}

Graph::~Graph(){
        delete []edgelist;
        delete []adjacentlist; // store neighor list, both in same vertex order
}


Graph::Graph(void) {
        edgelist = new SeqList<double>[100];
        adjacentlist = new SeqList<int>[100];
}

Graph::Graph(const char * filename) {
  double temp;
  POS i,j;
  ifstream fin;
  fin.open(filename, ios::in);
  if (!fin) {
    cout << "Can not find the specified file!"<<endl;
    cout << "Please Enter The Right Name : ";
    char file[256];
    cin >> file;
  	fin.open(file, ios::in);
    if (!fin) {
        cout << "Welcome To Use Jacob SoftWare!"<< endl;
        exit (0);
  	}
  }
  fin >> graphsize;
//  edgelist.Resize (graphsize * (graphsize - 1) / 2);
//  adjacentlist.Resize(graphsize * (graphsize - 1) / 2);
  edgelist = new SeqList<double>[graphsize];
  adjacentlist = new SeqList<int>[graphsize];
  for ( i = 0; i < graphsize ; i++) 
     for ( j = i+1; j < graphsize ; j++) {
       	if(!fin.eof()) fin >> temp;
        if ( temp < MAXVALUE) {
           edgelist[i].Insert( temp );
           edgelist[j].Insert( temp );
	   adjacentlist[i].Insert(j+1);
	   adjacentlist[j].Insert(i+1);
        }
  }
/*  if ( edgelist.GetSize() != graphsize * (graphsize - 1) / 2 ) {
	cerr << "file error" <<endl;
	exit (0);
  }*/
  fin.close();
  cout <<  " Graph initialized " << endl;

}

Graph::Graph(const Posion *pos, const int graphsize, const double rcut)
{
  int temp;
  POS i,j;
  double distance;
  Graph::graphsize=graphsize;
  edgelist = new SeqList<double>[graphsize];
  adjacentlist = new SeqList<int>[graphsize];
  for ( i = 0; i < graphsize ; i++) 
     for ( j = i+1; j < graphsize ; j++) {
        distance = 0.0;
        distance += (pos[i].x-pos[j].x) * (pos[i].x-pos[j].x);
        distance += (pos[i].y-pos[j].y) * (pos[i].y-pos[j].y);
        distance += (pos[i].z-pos[j].z) * (pos[i].z-pos[j].z);
        distance = sqrt(distance);
        if (distance <= rcut) {
           edgelist[i].Insert( 1 );
           edgelist[j].Insert( 1 );
	   adjacentlist[i].Insert(j+1);
	   adjacentlist[j].Insert(i+1);
        }
     }
  cout <<  " Graph initialized " << endl;
}

Graph::Graph(const Posion *pos, Posion &bound_lo, Posion &bound_hi, const int graphsize, const double rcut)
{
        int temp,*bin_points,*bin,ix,ixx,iyy,iy,iz,izz,ib;
	POS i=0,j=0,k=0;
	Posion nbin,binsize,postmp;
	double distance,rsq,rcutsq,dx,dy,dz;
	Graph::graphsize=graphsize;
	edgelist = new SeqList<double>[graphsize];
	adjacentlist = new SeqList<int>[graphsize];
        bin = new int[graphsize];
        rcutsq=rcut*rcut;
	// set bin
        bound_hi.x+=1.0;
        bound_hi.y+=1.0;
        bound_hi.z+=1.0;
	nbin=(bound_hi-bound_lo)/(rcut*1.1);
        nbin.x=int(nbin.x);	
        nbin.y=int(nbin.y);	
        nbin.z=int(nbin.z);	
        bin_points=new int[(int)(nbin.x*nbin.y*nbin.z)];

        binsize=bound_hi-bound_lo;
//        binsize=binsize+binsize*20.0;
        binsize.x=binsize.x/nbin.x;
        binsize.y=binsize.y/nbin.y;
        binsize.z=binsize.z/nbin.z;
        cout << nbin << endl;
        cout << binsize << endl;

	for ( i = 0; i < (int)(nbin.x*nbin.y*nbin.z); i++) bin_points[i]=-1;

	for ( i = 0; i < graphsize ; i++){
                postmp=pos[i]-bound_lo;
                ix=(int)(postmp.x/binsize.x); //locate each atom in the bin cells.
                iy=(int)(postmp.y/binsize.y); //locate each atom in the bin cells.
                iz=(int)(postmp.z/binsize.z); //locate each atom in the bin cells.
                ib = iz*nbin.y*nbin.x + iy*nbin.x + ix;
                bin[i] = bin_points[ib];
                bin_points[ib] = i;
        }
	for ( i = 0; i < graphsize ; i++){
                postmp=pos[i]-bound_lo;
                ixx=(int)(postmp.x/binsize.x);
                iyy=(int)(postmp.y/binsize.y);
                izz=(int)(postmp.z/binsize.z);
 //               cout << ixx << ' ' << iyy << ' ' << izz << endl;
//                cout << pos[i]-bound_lo << endl;
                for ( j = 0; j < 27; j++){
                        ix=ixx+j%3-1;
                        if (ix < 0) ix = nbin.x - 1;
                        if (ix == nbin.x) ix = 0;

                        iy = iyy + ((int)j/3)%3 - 1;
                        if (iy < 0) iy = nbin.y - 1;
                        if (iy == nbin.y) iy = 0;

                        iz = izz + j/9 - 1;
                        if (iz < 0) iz = nbin.z - 1;
                        if (iz == nbin.z) iz = 0;

                        ib = iz*nbin.y*nbin.x + iy*nbin.x + ix ;
                        k = bin_points[ib];
                        while (k != -1){

                                dx = pos[i].x - pos[k].x;
                                dy = pos[i].y - pos[k].y;
                                dz = pos[i].z - pos[k].z;
//            dx = dx - idynper(1)*perlen(1)*nint(dx/perlen(1))
//            dy = dy - idynper(2)*perlen(2)*nint(dy/perlen(2))
//            dz = dz - idynper(3)*perlen(3)*nint(dz/perlen(3))
                                rsq = dx*dx + dy*dy + dz*dz;
                                if(rsq <= rcutsq and rsq != 0) {
//                                        cout << sqrt(rsq) << endl;
//                                        Pause();
	                                edgelist[i].Insert( sqrt(rsq) );
	                                adjacentlist[i].Insert(k+1);
                                }
                                k = bin[k];
                        }

                }

        }
        SortNeighbors();
        delete bin;
        delete bin_points;
	cout <<  " Graph initialized " << endl;
}

 void Graph::Set_Bin(Posion &binbox, Posion &boxlo, Posion &boxhi,const double rcut ){
        binbox=(boxhi-boxlo)/rcut;
}

 int Graph::IfNeighbor(const int vertex1, const int vertex2){
        // determine whether the two vertex are connected, if not, return 0;
        // if yes, return position of vertex2 in edgelist & adjacentlist.
        return adjacentlist[vertex1-1].Find(vertex2);
}

double Graph::GetWeight(const int vertex1, const int vertex2) {
  POS pos;
  if ( vertex1 > graphsize || vertex2 > graphsize || vertex1 <= 0 || vertex2 <= 0) {
    cerr << vertex1 << ' ' << vertex2  << ' ' << graphsize << endl;
    cerr << "vertex not exists"<<endl;
    exit(1);
  }

  pos = IfNeighbor(vertex1, vertex2);
  return edgelist[vertex1-1].Get(pos);
}


int Graph::GetNeighbors(const int vertex, SeqList<int> &connctv) {
   int degree = adjacentlist[vertex-1].GetSize();
   connctv.Resize(degree);
   int j = 0;
   for ( int i = 1; i <= degree; i++) connctv.Insert(adjacentlist[vertex-1].Get());
   return degree;
}

int Graph::GetNeighborNumber(const int& vertex) {
   return adjacentlist[vertex-1].GetSize();
}

 SeqList<int>& Graph::Get_2_Neighbors(const int vertex1, const int vertex2, int &n ) {
  SeqList<int> line(graphsize), *save = new SeqList<int>(graphsize);
  int degree,joint;
  degree = adjacentlist[vertex1-1].GetSize();
  for (int i = 1; i <= degree; i++) {
    line.Insert (adjacentlist[vertex1-1].Get());
    joint = line.Get();
    if (IfNeighbor(joint, vertex2) != 0) save->Insert(joint);
  }
  return  *save;
}
//Shortest Path (Dijkstra algorithm)
SeqList<int>& Graph::ShortPath(const int vertex1, const int vertex2, double &length)
{
  SeqList<int> set1(graphsize), set2(graphsize), 
		  pathup(graphsize),*path = new SeqList<int>(graphsize);
  SeqList<double> L(graphsize);
  double min_edge = MAXVALUE, edge;
  int i, j;
  int lastout = vertex1, cur_ver, min_ver;
  cout <<  " Looking for the path from "  << vertex1 << " to " << vertex2 << endl;
  for ( i = 1; i <= graphsize; i++ )
  {
	set1.Insert(i);
	L.Insert(MAXVALUE);
	pathup.Insert(0);
  }
  L.Change(vertex1, 0);
  set1.Delete(vertex1);
  set2.Insert(vertex1);  // initialize
  for ( i = 1; i <= graphsize; i++)
  {
	for ( j = i + 1; j <= graphsize; j++)
	{
	  if ((edge = GetWeight(cur_ver = set1.Get(), lastout)) == MAXVALUE)
		continue;
	  else if ((edge += L.Get(lastout)) < L.Get(cur_ver))
	  {
        L.Change(cur_ver, edge);
        pathup.Change(cur_ver, lastout);
      }
    }
    min_edge = MAXVALUE;
    set1.Rewind();
    for (int j = i + 1; j <= graphsize; j++)
    {
      if ((edge = L.Get(cur_ver = set1.Get())) < min_edge)
      {
        min_edge = edge;
        min_ver = cur_ver;
      }
    }
    lastout = min_ver;
    if(lastout == vertex2) break;
    set1.Delete(lastout = min_ver);
    set2.Insert(lastout);
    set1.Rewind();
  }
  length = min_edge;
  cur_ver = vertex2;
  path->Insert(vertex2);
  for(;(cur_ver = pathup.Get(cur_ver)) != vertex1;
       path->Insert(cur_ver));
  path->Insert(vertex1);
  return *path;
}

void Graph::ChangeEdgeWeight(const int vertex1,
                             const int vertex2,
                             double weight)
{
  POS pos = edgelist[vertex1-1].Find(vertex2);
  if (pos != 0) edgelist[vertex1-1].Change(pos,weight);
  else {
          edgelist[vertex1-1].Insert(weight);
          edgelist[vertex2-1].Insert(weight);
          adjacentlist[vertex1-1].Insert(vertex2);
          adjacentlist[vertex2-1].Insert(vertex1);
  }
}

void Graph::SortNeighbors(){
        int i,j,k,NN;
        // Bubble sort
        for (i = 0; i < graphsize ; i++){
                NN=adjacentlist[i].GetSize();
                for (j = 0; j < NN; j++)
                        for (k = 0; k < NN-j-1; k++)
                                if (edgelist[i].Get(k+1) > edgelist[i].Get(k+2)) {
                                        edgelist[i].Swap(k+1,k+2);
                                        adjacentlist[i].Swap(k+1,k+2);
                                }
        }
}



