#include <string.h>
#ifndef GA_H

#define GA_H

#include <iostream>
#include <fstream>
#include <vector>

#include "seqlist.h"
#include "struc_gen.h"
#include "mpi.h"

#define ENENONE 9999
#define N_ONFLY 16

struct GAPara{
	bool onfly,alldft,recalce,if_restart,fixsite;
	bool ilmpin, scale_V, pwscf;  //pwscf controls the first-principles method
        int ntype,nions,cur_id,images,images_dft,NPOOL,NPOOL_DFT,comp_number,comp_min,comp_max,GABH;
        int i_dft,NECO,NGEN,NGEN_DFT,lj_eam,temp_nions,cellfree;
        int rank,grank,dimen,systype; 
	int nfixedt, nfixedb, nbufft, nbuffb, tmpatoms;  //system = interface/surface
	int movetop, mdsteps;          //for top atoms, move -> run MD 
	double vacuum, b_to_i;         //dimension of the vacuum; bottom_to_interface d;
	double zslab, ztotal;		//dimension of the 2D structure search
	int atom_type_min[10];
	int atom_type_max[10];
	int mut_control[10];
	double c_p[10], vol[10], amass[10];
	double e1conv, e2conv; int n1conv, n2conv;   //convergence checking
	double rcut,cell_fac,dkp,angle_min,angle_max,press,press_dft,criteria,pmut;
	double eweight, sweight;   //weight for potfit
        double temp,e_diff,alpha_1,alpha_2,beta_1,beta_2,beta_3; // for basin hopping
};

using namespace std; 
#ifdef MY_LAMMPS

#include "lammps.h"         // these are LAMMPS include files
#include "input.h"
#include "atom.h"
#include "domain.h"
#include "library.h"

using namespace LAMMPS_NS;

void ilammps_input(GAPara,int temp_nions,int);
int  Init_lammps(char *,LAMMPS *,MPI_Comm);
void Init_lammps(LAMMPS *,int,double*,int);
void Pot_Substrate(LAMMPS *,int);
void ilammps_put_lattice(void *, double *);
void ilammps_get_lattice(void *, double *);
void ilammps_get_force(void *, double *);
void ilammps_put_velocity(void *, double );
void ilammps_get_coords(void *ptr, double *coords);
void ilammps_put_coords(void *ptr, double *coords);
void Cal_Pool_Energy_lammps(double *,double *,double *,double *,double *,double*,int *, GAPara, LAMMPS *,int,MPI_Comm,MPI_Comm,double*,double*, double *,double *,double *,double *,double *,double *,double *,double *, double*);

#endif
void MY_MPI_SPLIT(int ,MPI_Comm &, MPI_Comm &,int &,int &,int &);

void Init_Pool(Posion *latt[],Posion *pos[],double *, int *,int *, GAPara, double *);

int  Read_GA_Info(GAPara&);
int  Init_GA_Info(GAPara&);
void write_oldin(GAPara);
void Cal_Pool_Energy(double *,double *,double *,double *,double *,double*,int *, GAPara, MPI_Comm,MPI_Comm,double*,double*,int);
/*
void Cal_Pool_Energy_Vasp(double *,double *,double*,double *,double *,double *, int *, double*, double*, GAPara, int,MPI_Comm,MPI_Comm,char*, double *,double *,double *,double *,double *,double *,double *,double *, double*);
void Cal_Pool_Energy_Pwscf(double *,double *,double*,double *,double *,double *, int *, double*, double*, GAPara, int,MPI_Comm,MPI_Comm,char*, double *,double *,double *,double *,double *,double *,double *,double *, double*);
*/
void Gen_kpoints(double *, int *,GAPara );


void Sort_Pool(Posion **, Posion **, double *, double*, double *, int *, int*, vector<float> *, GAPara, double *vec);
void Sort_Pool_Enthalpy(Posion **, Posion **, double *, double*, double *, int *, int, int);
int  CreateBondList(Posion *, Posion *, int, vector<float>*,double);
void Check_Pool(Posion **, Posion **, double *, int*, int*, vector<float> *, int ,GAPara ,int, double *,double *,double *,double *,double *,double *,double *,double *, double*);
double Compare_Structure(vector<float> ,vector<float> );
void Next_Gen(Posion **,Posion **,double*, int *, Posion *, int, int *, int *, vector<float>*, GAPara);
double Mating2(const Posion *, const Posion *, const Posion*, const Posion *, Posion**, Posion **, int *, Posion *,int,GAPara);
int Within_Planes(Posion, double width,double,int);
double Mating(const Posion *, const Posion *, const Posion*, const Posion *, Posion**, Posion **, int , int *, int, double,Posion *,int);
int Within_Planes(Posion plane_1, Posion plane_2, Posion pos, double width);
void Mutate_Type(Posion *, GAPara );
void Mutate_2Dz(Posion *, GAPara );
int Check_Child(Posion *, Posion *, int );
int Check_Child_bond(Posion *, Posion *, int nions, double);
double Check_bond(const Posion *, Posion *, int nions);
int test_file(char *);
int Accept(double ,double);
void MC_Move(Posion *, int, double ,int);
void Potfit_Input(GAPara ga_info);
void LJ_POT(char *filename_in,char *filename_out,GAPara ga_info);
void MORSE_POT(char *filename_in,char *filename_out,GAPara ga_info);
void EAM_POT(char *filename_in,char *filename_out,GAPara ga_info);
void potgen(char *filename);
int WhereWeAre(int);

#endif // GA_H
