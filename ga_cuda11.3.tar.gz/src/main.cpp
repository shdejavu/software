#include <stdio.h>
#include <math.h>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <vector>
#include <list>

#include "seqlist.h"
//for crystal search 
#include "struc_gen.h"
//for cluster search 
#include "cluster_gen.h"
//for interface/surface search 
#include "interface_gen.h"
#include "graph.h"
#include "ga.h"
#include "randomlib.h"
#include "version.h"

#include "mpi.h"
#include "dclock.h"

#ifdef MY_LAMMPS

//LAMMPS include files
#include "lammps.h" 
#include "input.h"
#include "atom.h"
#include "domain.h"
#include "library.h"
#include "output.h"
#include "thermo.h"

using namespace LAMMPS_NS;

#endif

using namespace std;

int main(int argc, char *argv[]){
        int sub_poolsize,sub_poolsize_dft,temp_type=0,temp_fact=0,npool_total,npool_max = 50000,comp_number,comp_min,comp_max,pot_stat;
	int *comp_status,*struc_id,*struc_id_total,*atom_type,NGEN,i_dft=0;
	double *pos_queue,*force_queue,*stress_queue,*latt_queue,*pos_template, *latt_template;
	//for interface 
	double *pos_fixedt,*latt_fixedt,*pos_fixedb,*latt_fixedb,*pos_bufft,*latt_bufft,*pos_buffb,*latt_buffb;
	//store the positions of the top fixed atoms relative to the initial setting 
	double *vec_fixedt;

        double *ene,*press,*ene_total,*press_total,*stress_total;
	double *force_queue_dft,*stress_queue_dft,*ene_dft;
	double vputim_0,cputim_0,vputim,cputim;
	double ene_ave,ene_ave_pre=0.0,ene_min,ene_min_pre=0.0;
	int ene_ave_count=0,ene_min_count=0;
        int rank,grank,force_idx,stress_idx,ene_idx;
	char scratch_dir[64]=" ";
        vector<float> *bondlist;
	int nsite;
	Posion *site;
	char *lmp_command[5];
	lmp_command[0]="lammps"; lmp_command[1]="-log"; lmp_command[2]="none"; lmp_command[3]="-screen"; lmp_command[4]="none";
        int nstrdel;
	struct GAPara ga_info;

       // setup MPI
        MPI_Init(&argc,&argv);
	int me,nprocs;
	MPI_Comm_rank(MPI_COMM_WORLD,&me);
	MPI_Comm_size(MPI_COMM_WORLD,&nprocs);

	MPI_Datatype MPI_GA;
	MPI_Datatype type[2]={MPI_INT,MPI_DOUBLE};
	int blocklen[2]={44,35};
	MPI_Aint disp[2]={0,sizeof(int)*44};
	MPI_Type_struct(2, blocklen, disp, type, &MPI_GA);
	MPI_Type_commit(&MPI_GA);

        if(me==0){
		cout << "aga v1.0.0, 7Jul14. Compilation time is "<< VERSION_DATE << endl;
		// setup random seed
		struct timeval time;
		gettimeofday(&time,NULL);
		srand(time.tv_usec) ;
		RandomInitialise(time.tv_usec/1000,time.tv_usec/1000);
		cout << "Random seed = " <<  time.tv_usec/1000 << endl;
		Init_GA_Info(ga_info);
		Read_GA_Info(ga_info);
		//temporary solution for pure dft search
		if(ga_info.alldft){
			fstream checkin("./pool.in", ios::in);
			if(checkin) {ga_info.NGEN_DFT = 2; ga_info.if_restart = 1;}
			else ga_info.NGEN_DFT = 1;
			checkin.close();
		}
		if(ga_info.onfly)
			i_dft =  WhereWeAre(ga_info.atom_type_min[1]);
		if(ga_info.onfly || ga_info.NGEN==0)
			npool_max = 64000;
		if(ga_info.onfly)
			NGEN = ga_info.NGEN;
		else NGEN = (ga_info.NGEN == 0)? ga_info.NGEN_DFT:ga_info.NGEN;
                if(ga_info.images > nprocs)
			ga_info.images = nprocs;
		else if(ga_info.images < nprocs && ga_info.NGEN != 0){
			cout << "##########################################################" << endl;
			cout << "# Warning: speed cannot improve much with mupltiple CPUs #" << endl;
			cout << "# to perform LAMMPS calculation.                         #" << endl;
			cout << "# It is recommended to set cstation = NCPU.              #" << endl;
			cout << "##########################################################" << endl;
		}
                if(ga_info.images_dft > nprocs)
			ga_info.images_dft = nprocs;
                comp_number = ga_info.atom_type_max[1] - ga_info.atom_type_min[1] + 1;
                cout << "Composition Size = " << comp_number << endl;
                sub_poolsize = ga_info.NPOOL / comp_number;
                sub_poolsize_dft = ga_info.NPOOL_DFT / comp_number;
                comp_status =  new int[comp_number];
		if( (nsite = Read_site_head()) != 0) {
			int itmp;
			site = new Posion[nsite];
			fstream site_in("./site.in", ios::in);
			site_in >> nsite;
        		for (int i = 0; i < nsite; i++)
				site_in >> site[i].x >> site[i].y >> site[i].z >> itmp;
			site_in.close();
		}
        }
        MPI_Bcast(&ga_info,sizeof(GAPara),MPI_BYTE,0,MPI_COMM_WORLD);
	MPI_Bcast(&NGEN,1,MPI_INT,0,MPI_COMM_WORLD);
	MPI_Bcast(&i_dft,1,MPI_INT,0,MPI_COMM_WORLD);
	//for interface 
	vec_fixedt  = new double[3*ga_info.NPOOL];
	pos_fixedt  = new double[4*ga_info.nfixedt];
	pos_fixedb  = new double[4*ga_info.nfixedb];
	pos_bufft   = new double[4*ga_info.nbufft];
	pos_buffb   = new double[4*ga_info.nbuffb];
	latt_fixedt = new double[12];
	latt_fixedb = new double[12];
	latt_bufft  = new double[12];
	latt_buffb  = new double[12];
	if(me==0 && ga_info.systype==2) {
		cout << "Preparing for interface/surface ..." << endl;

		for(int x=0; x<3*ga_info.NPOOL; x++)vec_fixedt[x]=0;
		Read_interface("fixed_atoms.in",latt_fixedt,latt_fixedb,pos_fixedt,pos_fixedb,ga_info.nfixedt,ga_info.nfixedb);
		Read_interface("buff_atoms.in",latt_bufft,latt_buffb,pos_bufft,pos_buffb,ga_info.nbufft,ga_info.nbuffb);
		if(int(pos_fixedt[ga_info.nfixedt*4-1]+0.01)%10 > int(pos_fixedb[ga_info.nfixedb*4-1]+0.01)%10)
			temp_type = int(pos_fixedt[ga_info.nfixedt*4-1]+0.01)%10;
		else temp_type = int(pos_fixedb[ga_info.nfixedb*4-1]+0.01)%10;
		cout << "temp_type = " << temp_type << endl;
		cout << "Top & Bottom atoms = " << ga_info.tmpatoms << endl;
		cout << "total atoms = " << ga_info.nions+ga_info.tmpatoms << endl;
		Order_interface(latt_bufft[10], latt_buffb[10], pos_fixedt, pos_bufft, pos_buffb, pos_fixedb, vec_fixedt, ga_info);
	}

	pos_template   = new double[4*ga_info.temp_nions];
	latt_template  = new double[12];
	// if we have template atoms (2nd way for surface)
	if(me==0)
		if(ga_info.temp_nions != 0) {
                	cout << "We have some substrate. Take care!" << endl;
			temp_fact = 1;
			Read_template(latt_template, pos_template, ga_info.temp_nions);
			temp_type = int(pos_template[ga_info.temp_nions*4-1]+0.01)%10;
		}else if(ga_info.systype != 2) {
			temp_type = ga_info.ntype-1;
		}
	if(ga_info.temp_nions != 0 ){
		MPI_Bcast(latt_template,12,MPI_DOUBLE,0,MPI_COMM_WORLD);
		MPI_Bcast(pos_template,ga_info.temp_nions*4,MPI_DOUBLE,0,MPI_COMM_WORLD);
	}

	if(ga_info.systype == 2){
		MPI_Bcast(vec_fixedt, 3*ga_info.NPOOL, MPI_DOUBLE, 0, MPI_COMM_WORLD);
		MPI_Bcast(pos_fixedt, 4*ga_info.nfixedt, MPI_DOUBLE, 0, MPI_COMM_WORLD);
		MPI_Bcast(pos_fixedb, 4*ga_info.nfixedb, MPI_DOUBLE, 0, MPI_COMM_WORLD);
		MPI_Bcast(pos_bufft, 4*ga_info.nbufft, MPI_DOUBLE, 0, MPI_COMM_WORLD);
		MPI_Bcast(pos_buffb, 4*ga_info.nbuffb, MPI_DOUBLE, 0, MPI_COMM_WORLD);
		MPI_Bcast(latt_fixedt, 12, MPI_DOUBLE, 0, MPI_COMM_WORLD);
		MPI_Bcast(latt_fixedb, 12, MPI_DOUBLE, 0, MPI_COMM_WORLD);
		MPI_Bcast(latt_bufft, 12, MPI_DOUBLE, 0, MPI_COMM_WORLD);
		MPI_Bcast(latt_buffb, 12, MPI_DOUBLE, 0, MPI_COMM_WORLD);
	}
	MPI_Bcast(&temp_type,1,MPI_INT,0,MPI_COMM_WORLD);
        atom_type = new int[ga_info.ntype*ga_info.NPOOL];
        int *tmp_type = new int[ga_info.ntype];

	// Split processes
	int nprocs_pool = nprocs/ga_info.images,pool_id;
	MPI_Comm comm_inter,comm_intra;
	MY_MPI_SPLIT(ga_info.images,comm_inter,comm_intra,pool_id,rank,grank);

	// open LAMMPS input script
#ifdef MY_LAMMPS
	LAMMPS *lmp = new LAMMPS(5,lmp_command,comm_intra);
	if(!ga_info.alldft)
		ilammps_input(ga_info,ga_info.temp_nions,temp_type);
        MPI_Barrier(MPI_COMM_WORLD);
	if(!ga_info.alldft)
		Init_lammps("./ilmp.in",lmp,comm_intra);
#endif
	//MY_MPI_SPLIT(ga_info.images_dft,comm_inter,comm_intra,pool_id,rank,grank);

        for(int i = 0;i < 63; i++) scratch_dir[i]=' ';
        scratch_dir[63] = '\0';
        if(argc > 1) {
                strncpy(scratch_dir,argv[1],strlen(argv[1]));
                scratch_dir[strlen(argv[1])]='\0';
        }else scratch_dir[0]='\0';

        char dirname[4];
        int_to_str(grank+1,dirname,3);
        strcat(scratch_dir,dirname);
//        if(rank == 0)
//        mkdir(scratch_dir,0700);
        for(int i = 0;i < 63; i++) scratch_dir[i]=' ';
        scratch_dir[63] = '\0';
        if(argc > 1) {
                strncpy(scratch_dir,argv[1],strlen(argv[1]));
        }
        scratch_dir[strlen(scratch_dir)] = ' ';

	Posion **pos = new Posion*[ga_info.NPOOL];
	Posion **latvec = new Posion*[ga_info.NPOOL];
	Posion **pos_total,**latt_total;
	Posion **latt_temp  = new Posion*[ga_info.NPOOL];
	pos_queue      = new double[4*ga_info.nions*ga_info.NPOOL]; // 3 for coordination 1 for atom type
	force_queue    = new double[4*ga_info.nions*ga_info.NPOOL]; 
	stress_queue   = new double[6*ga_info.NPOOL]; 
	force_queue_dft    = new double[4*(ga_info.nions)*ga_info.NPOOL]; 
	stress_queue_dft   = new double[6*ga_info.NPOOL]; 
	latt_queue     = new double[4*3*ga_info.NPOOL];
	ene       = new double[ga_info.NPOOL];
	ene_dft   = new double[ga_info.NPOOL];
	press     = new double[ga_info.NPOOL];
	struc_id  = new int[ga_info.NPOOL+1]; //last struc_id[ga_info.NPOOL] for max-ID number

	if(ga_info.temp_nions != 0)
      		for (int i = 0; i < ga_info.NPOOL; i++){
			latt_temp[i] = new Posion[3];
      			for (int j = 0; j < 3; j++) {
			latt_temp[i][j].x  = latt_template[4*j+0];
			latt_temp[i][j].y  = latt_template[4*j+1];
			latt_temp[i][j].z  = latt_template[4*j+2];
			}
		}

        // initialize pool structures
	if (me == 0){
		bondlist  = new vector<float>[ga_info.NPOOL];
		pos_total = new Posion*[npool_max];
		latt_total = new Posion*[npool_max];
       		for (int i = 0; i < npool_max; i++) {
			pos_total [i] = new Posion[ga_info.nions];
			latt_total[i] = new Posion[3];
		}

		ene_total= new double[npool_max];
		press_total= new double[npool_max];
		stress_total= new double[npool_max*6];
		struc_id_total = new int[npool_max];
        	for (int i = 0; i < ga_info.NPOOL; i++)
			press[i]=ene[i] = ENENONE;
		comp_min = ga_info.atom_type_min[1];
		comp_max = ga_info.atom_type_max[1];
		// multi-composition run
		Generate_composition(ga_info.atom_type_min, ga_info.atom_type_max, atom_type, ga_info.NPOOL, ga_info.ntype, ga_info.nions);
       		for (int i = 0; i < comp_number; i++) comp_status[i] = 0;
		if ( ga_info.if_restart ) {
			cout << "Reading pool.in .." << endl;
			Read_Pool("./pool.in",latvec,pos,ene,press,struc_id,comp_status,atom_type,ga_info, vec_fixedt);
			Read_Pool("./pool_new.dat",latt_total,pos_total,ene_total,press_total,struc_id_total,npool_total,ga_info.nions,ga_info.ntype);
			Check_Pool(latvec,pos,ene,struc_id,atom_type,bondlist,sub_poolsize,ga_info,0,latt_fixedt, latt_fixedb, latt_bufft, latt_buffb, pos_fixedt, pos_fixedb, pos_bufft, pos_buffb,vec_fixedt);
			Sort_Pool(latvec,pos,ene,stress_queue,press,struc_id,atom_type,bondlist,ga_info, vec_fixedt);
                      	for(int j = 0; j< ga_info.NPOOL; j++) {
				KarDir(latvec[j],pos[j],ga_info.nions); DirKar(latvec[j],pos[j],ga_info.nions);
	                      	//if(ga_info.fixsite==0&&ga_info.dimen==3) Align_Structure(latvec[j],pos[j],ga_info.nions);
				if(ga_info.recalce)ene[j] = ENENONE;
			}
		} else {
			npool_total = 0;
			Init_Pool(latvec,pos,ene,struc_id,atom_type,ga_info,vec_fixedt);
       			for (int i = 0; i < comp_number; i++)
				comp_status[i] = sub_poolsize;
		}
               	for(int j = 0; j< ga_info.NPOOL; j+=sub_poolsize)
			Print_composition(atom_type+j*ga_info.ntype,ga_info.ntype);
               	for(int j = 0; j< ga_info.NPOOL; j++)
			Get_Type(pos[j],ga_info.nions,atom_type+j*ga_info.ntype,ga_info.ntype);

		char filename[6];
		for (int i = 0; i < ga_info.NPOOL; i++) {
			int_to_str(i,filename,5);filename[0]='.';
			if(ene[i] == ENENONE) remove(filename);
			else test_file(filename);
		}
		
	}

        MY_MPI_SPLIT(ga_info.images,comm_inter,comm_intra,pool_id,rank,grank);

       	for (int i = 1; i <= NGEN; i++){
		if(me==0) cout << "==================================================" << endl;
		if(i_dft > ga_info.NGEN_DFT) break;
		if(me==0){
       			Write_Pool("./results.pool0",latvec,pos,ene,press,struc_id,ga_info.NPOOL,ga_info.nions,ga_info.ntype);
			Write_Vec("./vec.pool0", vec_fixedt, struc_id, ga_info.nfixedt, ga_info.NPOOL);
			Convert_structure(pos,pos_queue,ga_info.NPOOL,ga_info.nions);
			Convert_structure(latvec,latt_queue,ga_info.NPOOL,3);
		}
               	MPI_Barrier(MPI_COMM_WORLD);
//		if(ga_info.onfly && i_dft == 0) i=NGEN;
		MPI_Bcast(struc_id,ga_info.NPOOL,MPI_INT,0,MPI_COMM_WORLD);
		vtime(vputim_0,cputim_0);

		if(ga_info.NGEN!=0){ // classical calculation
#ifdef MY_LAMMPS
			if( i < NGEN ) 
       				Cal_Pool_Energy_lammps(latt_queue, pos_queue, ene, force_queue, stress_queue,press,struc_id,ga_info,lmp,pool_id, comm_intra,comm_inter,latt_template,pos_template, latt_fixedt, latt_fixedb, latt_bufft, latt_buffb, pos_fixedt, pos_fixedb, pos_bufft, pos_buffb, vec_fixedt);
#endif

/*
			if(ga_info.onfly && i == NGEN){ 
				for (int j = 0; j < comp_number; j++) {
					for (int jj = 0; jj < ga_info.NPOOL/comp_number; jj++) 
						ene_dft[j*sub_poolsize+jj] = ENENONE/2;
					for (int jj = 0; jj < ga_info.NPOOL_DFT/comp_number; jj++) 
						ene_dft[j*sub_poolsize+jj] = ENENONE;
				}

				if(me==0){
		                        char filename[6];
       			                for (int j = 0; j < ga_info.NPOOL; j++) {
                		                int_to_str(j,filename,5);filename[0]='.';
                        		        if(ene_dft[j] == ENENONE) remove(filename);
                                		else test_file(filename);
	                                	Get_Type(pos[j],ga_info.nions,atom_type+j*ga_info.ntype,ga_info.ntype);
        	                	}
				}
#ifdef MYPWSCF
       	        		Cal_Pool_Energy_Pwscf(latt_queue, pos_queue, ene_dft, force_queue_dft,stress_queue_dft,press,struc_id,
					latt_template,pos_template, ga_info, pool_id,comm_intra,comm_inter,scratch_dir, latt_fixedt, latt_fixedb, latt_bufft, latt_buffb, pos_fixedt, pos_fixedb, pos_bufft, pos_buffb, vec_fixedt);
#else
	       	        	Cal_Pool_Energy_Vasp (latt_queue, pos_queue, ene_dft, force_queue_dft,stress_queue_dft,press,struc_id,
					latt_template,pos_template, ga_info, pool_id,comm_intra,comm_inter,scratch_dir, latt_fixedt, latt_fixedb, latt_bufft, latt_buffb, pos_fixedt, pos_fixedb, pos_bufft, pos_buffb, vec_fixedt);
#endif
			}
*/

		} else { // DFT calculation: changed to do dft outside
/*
			for (int j = 0; j < ga_info.NPOOL_DFT; j++) ene_dft[j] = ene[j];
#ifdef MYPWSCF
       	        	Cal_Pool_Energy_Pwscf(latt_queue, pos_queue, ene_dft, force_queue_dft,stress_queue_dft,press,struc_id,
				latt_template,pos_template, ga_info, pool_id,comm_intra,comm_inter,scratch_dir, latt_fixedt, latt_fixedb, latt_bufft, latt_buffb, pos_fixedt, pos_fixedb, pos_bufft, pos_buffb, vec_fixedt);
#else
       	        	Cal_Pool_Energy_Vasp (latt_queue, pos_queue, ene_dft, force_queue_dft,stress_queue_dft,press,struc_id,
				latt_template,pos_template, ga_info, pool_id,comm_intra,comm_inter,scratch_dir, latt_fixedt, latt_fixedb, latt_bufft, latt_buffb, pos_fixedt, pos_fixedb, pos_bufft, pos_buffb, vec_fixedt);
#endif
*/
		}
		vtime(vputim,cputim);
        	MPI_Barrier(MPI_COMM_WORLD);

		if (me == 0) {
			cout << vputim-vputim_0 << " seconds " << endl;
			vtime(vputim_0,cputim_0);
			// ==================================== Genetic algorithm ===========================================
			Convert_structure(pos_queue,force_queue, pos,ga_info.NPOOL,ga_info.nions);
			Convert_structure(latt_queue,latvec,ga_info.NPOOL,3);

                      	for(int j = 0; j< ga_info.NPOOL; j++) 
				Correct_structure(latvec[j],pos[j],ene[j],press[j],stress_queue+j*6,ga_info.nions,ga_info.ntype);
                      	if(ga_info.fixsite==0&&ga_info.dimen==3)
				for(int j = 0; j< ga_info.NPOOL; j++)
					Align_Structure(latvec[j],pos[j],ga_info.nions);
// potfit deleted


			// add to total pool
       			for (int j = 0; j < comp_number; j++){
				int k;
				if((ga_info.if_restart==0&&i==0) || npool_total < ga_info.NPOOL) k = 0;
				else k = sub_poolsize / 4 * 3;
	       			for (; k < comp_status[j]; k++) {
					ene_total[npool_total]  = ene[j*sub_poolsize+k];
					press_total[npool_total]  = press[j*sub_poolsize+k];
       					//struc_id_total[npool_total]=100000000+npool_total;
					struc_id_total[npool_total]  = struc_id[j*sub_poolsize+k];
       					for (int n = 0; n < 6; n++)
						stress_total[npool_total*6+n]=stress_queue[(j*sub_poolsize+k)*6+n];
       					for (int n = 0; n < ga_info.nions; n++)
						pos_total[npool_total][n] = pos[j*sub_poolsize+k][n];
	       				for (int n = 0; n < 3; n++) 
						latt_total[npool_total][n] = latvec[j*sub_poolsize+k][n];
					if(npool_total < npool_max-1)
						npool_total++;
				}
			}

			//sort pool by energies
			if(i < NGEN || ga_info.onfly == 0){
				if ( (nstrdel > (int) (ga_info.NPOOL/4)) || i==1) {
					cout << "Check whole pool" <<endl;
	                		Check_Pool(latvec,pos,ene,struc_id,atom_type,bondlist,sub_poolsize,ga_info,0,latt_fixedt, latt_fixedb, latt_bufft, latt_buffb, pos_fixedt, pos_fixedb, pos_bufft, pos_buffb,vec_fixedt);
				}
				else
	                		Check_Pool(latvec,pos,ene,struc_id,atom_type,bondlist,sub_poolsize,ga_info,3,latt_fixedt, latt_fixedb, latt_bufft, latt_buffb, pos_fixedt, pos_fixedb, pos_bufft, pos_buffb, vec_fixedt);
	                	Sort_Pool(latvec,pos,ene,stress_queue,press,struc_id,atom_type,bondlist,ga_info, vec_fixedt);
				// getting number of deleted structures
				nstrdel = 0;
				for (int jj = 0; jj < ga_info.NPOOL; jj++) {
					if ( ene[jj] != ENENONE ) nstrdel++;
				}
				nstrdel = ga_info.NPOOL - nstrdel;
				if(!(ga_info.alldft && i==1))
					cout << "nstrdel = " << nstrdel << endl;
///

				float ave_vol=0.0, ave_bond=0.0;
       				for (int jj = 0; jj < ga_info.NPOOL; jj++) {
					ave_vol += latvec[jj][0].x*latvec[jj][1].y*latvec[jj][2].z;
				}
				ave_vol /= (float) ga_info.NPOOL;
				cout << "Average volume = " << ave_vol << endl;
			}
			vtime(vputim,cputim);
			cout << vputim-vputim_0 << " seconds " << endl; 
			vtime(vputim_0,cputim_0);
//=======================================================================================================
// output
                	cout << "Generation " << setw(4) << i_dft << setw(5) << i;
       			for (int j = 0; j < comp_number; j++) {
				comp_status[j] = sub_poolsize/4*3;
				ene_ave = 0.0;
       				for (int k = 0; k < comp_status[j]; k++) {
					ene_ave += ene[j*sub_poolsize+k];
				}
				ene_ave/=comp_status[j];
				ene_min = ene[j*sub_poolsize];
				char filename[12];
				cout << setiosflags(ios::fixed) << setw(11) << setprecision(3) << ene_min;
				cout << " ( " << setiosflags(ios::fixed) << setw(8) << setprecision(3) << ene_ave << " )";
				if(fabs(ene_min-ene_min_pre)<ga_info.e1conv)
					ene_min_count++;
				else ene_min_count=0;
				ene_min_pre = ene_min;
				if(fabs(ene_ave-ene_ave_pre)<ga_info.e2conv)
					ene_ave_count++; 
				else ene_ave_count=0;
				ene_ave_pre = ene_ave;
			} cout << endl;
			cout << "convergence check "  << ene_min_count << "  " << ene_ave_count << endl;
			if(ene_min_count>=ga_info.n1conv && ene_ave_count>=ga_info.n2conv) {
				cout << "GA converged." << endl;
				i=NGEN;
			}
//=======================================================================================================
	        	Write_Pool("./results.pool",latvec,pos,ene,press,struc_id,ga_info.NPOOL,ga_info.nions,ga_info.ntype);
			Write_Vec("./vec.pool", vec_fixedt, struc_id, ga_info.nfixedt, ga_info.NPOOL);
//			if(i%50 == 0)
				Write_Pool("./pool_new.dat",latt_total,pos_total,ene_total,press_total,struc_id_total,npool_total,ga_info.nions,ga_info.ntype);

			// mating for next generation
			if(i < NGEN){
				if(ga_info.systype==0){
					Next_Gen(latvec,pos,ene, struc_id, site, nsite, atom_type, comp_status, bondlist, ga_info);
				}
				else if(ga_info.systype==1){   //for cluster search  
					Next_Gen_cluster(latvec,pos,ene, struc_id, site, nsite, atom_type, comp_status, bondlist, ga_info);
				}
                                else if(ga_info.systype==2){   //for interface or surface
					Next_Gen_interface(latvec,pos,ene, struc_id, site, nsite, atom_type, comp_status, bondlist, vec_fixedt, ga_info);
				}
			}

			if(ga_info.NGEN==0){
	                        char filename[6];
       		                 for (int j = 0; j < ga_info.NPOOL; j++) {
                	                int_to_str(j,filename,5);filename[0]='.';
                        	        if(ene[j] == ENENONE) remove(filename);
                                	else test_file(filename);
	                                Get_Type(pos[j],ga_info.nions,atom_type+j*ga_info.ntype,ga_info.ntype);
        	                }
			}

       			for (int ii = 0; ii < comp_number; ii++)
				comp_status[ii] = sub_poolsize;
			vtime(vputim,cputim);

			cout << vputim-vputim_0 << " seconds " << endl;
			if(pot_stat!=0)i_dft == ga_info.NGEN_DFT;
		} // GA Part 
               	MPI_Barrier(MPI_COMM_WORLD);
		MPI_Bcast(&i,1,MPI_INT,0,MPI_COMM_WORLD);
		MPI_Bcast(&NGEN,1,MPI_INT,0,MPI_COMM_WORLD);
		MPI_Bcast(&i_dft,1,MPI_INT,0,MPI_COMM_WORLD);
       	} // LMP loop

        MPI_Barrier(MPI_COMM_WORLD);

	if(me == 0) {
		if(ga_info.alldft){
			int nn=Pool2poscar(latt_queue, pos_queue, ene, pos_fixedt, pos_fixedb, pos_bufft, pos_buffb, latt_fixedt, latt_fixedb, latt_bufft, latt_buffb, vec_fixedt, ga_info, struc_id, latt_template,pos_template);
			cout << nn << " Structures were output in VASP format." << endl;
		}else{
			cout << "Classical GA search completed." << endl;
			if(ga_info.onfly){
				int nn=Pool2poscar(latt_queue, pos_queue, ene, pos_fixedt, pos_fixedb, pos_bufft, pos_buffb, latt_fixedt, latt_fixedb, latt_bufft, latt_buffb, vec_fixedt, ga_info, struc_id, latt_template,pos_template);
				cout << nn << " Structures were output in VASP format." << endl;
				cout << "Preparation for first-principles calculation finished." << endl;
			}
		}
	}

  	MPI_Finalize();
        return 0;
}
