#include <time.h>
#include <stdlib.h>
#include <math.h>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <sys/time.h>

#include "seqlist.h"
#include "struc_gen.h"
#include "ga.h"
#include "randomlib.h"

void Generate_composition(int *atom_min, int *atom_max, int *atom_type, int poolsize, int ntype, int nions){
	int offset,total,tmin,tmax;
	int min_tmp,max_tmp;
	int comp_group = atom_max[1]-atom_min[1] + 1;
	int subpoolsize = poolsize/comp_group;
	int *fix_comp = new int[comp_group*ntype];
	string ss;
	fstream fin("./comp.in",ios::in);
	if(fin){
        	for (int i = 0; i < comp_group; i++) {
        		for (int j = 0; j < ntype; j++) 
				fin >> fix_comp[i*ntype+j];
			getline(fin, ss);
        		for (int k = 0; k < subpoolsize; k++) {
				offset = ntype*(subpoolsize*i+k);
        			for (int j = 0; j < ntype; j++) 
					atom_type[offset+j]=fix_comp[i*ntype+j];
			}
		}
		cout << "Compositions read. " << endl;
		fin.close();
		return;
	}
		
        for (int i = 0; i < poolsize; i++) {
		total = 0;
		offset = ntype*i;
		tmin=tmax=0;
        	for (int j = 0; j < ntype; j++) {
			if(j != 1){
				tmin += atom_min[j];
				tmax += atom_max[j];
			}
		}
		total = atom_type[offset+1] = atom_min[1]+i/subpoolsize;
        	for (int j = ntype -1 ; j >= 0; j--) {
			if(j != 1){ 
				tmin -= atom_min[j];
				tmax -= atom_max[j];
				min_tmp = atom_min[j] < (nions-total-tmax) ?(nions-total-tmax):atom_min[j];
				max_tmp = atom_max[j] > (nions-total-tmin) ?(nions-total-tmin):atom_max[j];
				atom_type[offset+j] = RandomInt(atom_min[j], atom_max[j] > (nions-total-tmin) ?(nions-total-tmin):atom_max[j]);
				atom_type[offset+j] = RandomInt(min_tmp, max_tmp);
				total += atom_type[offset+j];
			}
//			if(j == 1 && comp_group !=1) atom_type[offset+j] = atom_min[1]+i/(poolsize/comp_group);

		}
		if(atom_min[0] == atom_max[0])
			atom_type[offset + ntype - 1] += (nions-total);
		else
			atom_type[offset] += (nions-total);
	}
	cout << "Compositions generated" << endl;
}

void Adjust_composition(const int *atom_min, const int *atom_max, int *atom_type, int ntype, int nions){
	int *atom_tmp = new int[ntype];
	int *atom_min_tmp = new int[ntype];
	int *atom_max_tmp = new int[ntype];
	int rem_nions = 0,cur_nions = 0;
       	for (int j = 0; j < ntype; j++) {
		cur_nions += atom_type[j];
	}
	rem_nions = nions - cur_nions;
       	for (int j = 0; j < ntype; j++) {
		if(atom_type[j] < atom_min[j]){
			rem_nions -= (atom_min[j] - atom_type[j]);
			atom_type[j] = atom_min[j];
		} else if(atom_type[j] > atom_max[j]){
			rem_nions += (atom_type[j] - atom_max[j]);
			atom_type[j] = atom_max[j];
		} 

	}
	if(rem_nions < 0){ // need to substract
       		for (int j = 0; j < ntype; j++) {
			atom_max_tmp[j] = atom_type[j];
			atom_min_tmp[j] = atom_type[j]+rem_nions;
			if(atom_min_tmp[j] < atom_min[j]) atom_min_tmp[j] = atom_min[j];
			atom_max_tmp[j] -= atom_min_tmp[j];
			atom_min_tmp[j] = 0;
		}
	} else if(rem_nions > 0){
       		for (int j = 0; j < ntype; j++) {
			atom_min_tmp[j] = atom_type[j];
			atom_max_tmp[j] = atom_type[j]+rem_nions;
			if(atom_max_tmp[j] > atom_max[j]) atom_max_tmp[j] = atom_max[j];
			atom_max_tmp[j] -= atom_min_tmp[j];
			atom_min_tmp[j] = 0;
		}
	} else return;

	atom_min_tmp[1] = atom_max_tmp[1] = 0;
	Generate_composition(atom_min_tmp, atom_max_tmp, atom_tmp, 1, ntype, abs(rem_nions));

       	for (int j = 0; j < ntype; j++) {
		atom_type[j] += (abs(rem_nions)/rem_nions*atom_tmp[j]);
	}
}

void Generate_composition(int poolsize, int nions, int *atom_type, int ntype,int sub_poolsize,int comp_min, int comp_step){
	int ngroup = poolsize/sub_poolsize;
	int offset;
	// two component system now
        for (int i = 0; i < ngroup; i++)
        	for (int j = 0; j < sub_poolsize; j++){
			offset = (i*sub_poolsize+j)*ntype;
			atom_type[offset+0] = atom_type[0];
			atom_type[offset+1] = comp_min+i*comp_step;
			atom_type[offset+2] = nions - (comp_min+i*comp_step);
	}
}

int Init_Cell(Posion *latt, double volume, GAPara ga_info){
	double xx,yy,zz,xy,xz,yz,alpha,beta,gamma,len_ave;
	float if_fixed = 0;
	string ss;
	fstream latt_in("./latt.in", ios::in);
	if(latt_in) latt_in >> if_fixed;
	if ( if_fixed != 0.0) {
		latt_in >> latt[0].x >> latt[0].y >> latt[0].z ;
		getline(latt_in, ss);
		latt_in >> latt[1].x >> latt[1].y >> latt[1].z ;
		getline(latt_in, ss);
		latt_in >> latt[2].x >> latt[2].y >> latt[2].z ;
		getline(latt_in, ss);
		latt[0] = latt[0] * if_fixed;
		latt[1] = latt[1] * if_fixed;
		latt[2] = latt[2] * if_fixed;
		latt_in.close();

		if(volume != 0.0 && ga_info.systype != 1 && ga_info.scale_V){
			//rescale the volume of the unit cell to preset volume
			double oldvol = Cell_Volume(latt);
			double newvol = cbrt(volume/oldvol);
			latt[0] = latt[0]*newvol;
			latt[1] = latt[1]*newvol;
			latt[2] = latt[2]*newvol;
		}
		return 1;
	} else if (ga_info.systype == 1){
		latt[0].x = latt[1].y = latt[2].z = 50.0;
		latt[0].y = latt[0].z = 0;
		latt[1].x = latt[1].z = 0;
		latt[2].x = latt[2].y = 0;
		return 1;
	}
	if(ga_info.rcut > volume/ga_info.rcut/ga_info.rcut)
		cout << "Warning: cell factor may not be reasonable " << ga_info.rcut << ' ' << volume << endl;
	while(1){
		alpha = RandomDouble(ga_info.angle_min,ga_info.angle_max)/180*3.1415926;
		beta  = RandomDouble(ga_info.angle_min,ga_info.angle_max)/180*3.1415926;
		gamma = RandomDouble(ga_info.angle_min,ga_info.angle_max)/180*3.1415926;
		if(ga_info.dimen==2) gamma=beta=90.0/180*3.1415926;
		len_ave = cbrt(volume);	
		zz = RandomDouble(len_ave/ga_info.cell_fac,len_ave*ga_info.cell_fac);
		if(ga_info.dimen==2)zz = ga_info.zslab;
		len_ave = sqrt(volume/zz);	
		yy = RandomDouble(len_ave/ga_info.cell_fac,len_ave*ga_info.cell_fac);
		xx = volume / zz / yy;
		latt[0].x = xx;         latt[0].y = 0;         latt[0].z = 0;
		xy=latt[1].x = yy/tan(alpha); latt[1].y = yy;        latt[1].z = 0;
		double tmp = cos(alpha)-cos(beta)*cos(gamma);
		double c = sin(beta)*sin(beta)-tmp*tmp/sin(gamma)/sin(gamma);
		c = zz*zz/c;
		c = sqrt(c);
		xz=latt[2].x = c*cos(beta); yz=latt[2].y = c*tmp/sin(gamma); latt[2].z = zz;
		if(ga_info.dimen==2) {latt[2].x=latt[2].y=0.0; latt[2].z=ga_info.ztotal;}
		if(fabs(latt[1].x)<latt[0].x/2.0 && fabs(latt[2].x)<latt[0].x/2.0 && fabs(latt[2].y)<latt[1].y/2.0 && latt[0].x > ga_info.rcut) break;	
//		if(fabs(xy)<xx/2.0 && fabs(xz)<xx/2.0 && fabs(yz)<yy/2.0 && xx > ga_info.rcut) break;
	}
	latt_in.close();
	return 0;
}

void Align_Cell(Posion *latt,Posion *pos, int nions){
	double a,b,c,alpha,beta,gamma;
	KarDir(latt,pos,nions);
	Get_Cell_Para(latt,a,b,c,alpha,beta,gamma);
	Gen_Cell(latt,a,b,c,alpha,beta,gamma);
	DirKar(latt,pos,nions);
}

void Get_Cell_Para(Posion *latt,double &a,double &b,double &c,double &alpha,double &beta,double &gamma){
	Posion temp;
	a = sqrt(latt[0].x*latt[0].x+latt[0].y*latt[0].y+latt[0].z*latt[0].z);
	b = sqrt(latt[1].x*latt[1].x+latt[1].y*latt[1].y+latt[1].z*latt[1].z);
	c = sqrt(latt[2].x*latt[2].x+latt[2].y*latt[2].y+latt[2].z*latt[2].z);
	temp = latt[0]*latt[1];
	gamma = acos((temp.x+temp.y+temp.z)/a/b);
	temp = latt[1]*latt[2];
	alpha  = acos((temp.x+temp.y+temp.z)/b/c);
	temp = latt[2]*latt[0];
	beta = acos((temp.x+temp.y+temp.z)/c/a);
}

int Gen_Cell(Posion *latt,double a,double b,double c,double alpha,double beta,double gamma){
	latt[0].x = latt[0].y = latt[0].z = 0.0;
	latt[1].x = latt[1].y = latt[1].z = 0.0;
	latt[2].x = latt[2].y = latt[2].z = 0.0;
	latt[0].x = a;
	latt[1].x = b * cos(gamma);
	latt[1].y = b * sin(gamma);
	latt[2].x = c * cos(beta);
	latt[2].y = c*(cos(alpha)-cos(beta)*cos(gamma))/sin(gamma);
	latt[2].z = sqrt(c*c - latt[2].x*latt[2].x - latt[2].y*latt[2].y);
	return 0;
}

int Extend_Cell(Posion *pos, Posion *pos_new,int nions, double a_new, double b_new, double c_new){
	int na,nb,nc,nions_tmp,nions_new;
	Posion *postmp;
	na = ceil(a_new);
	nb = ceil(b_new);
	nc = ceil(c_new);
	nions_tmp = na*nb*nc*nions;
	postmp = new Posion[nions_tmp];
	nions_new = 0;
        for (int i = 0; i < na; i++) 
        for (int j = 0; j < nb; j++) 
        for (int k = 0; k < nc; k++) 
        	for (int n = 0; n < nions; n++) {
			postmp[nions_new].x = pos[n].x + (double)i;
			postmp[nions_new].y = pos[n].y + (double)j;
			postmp[nions_new].z = pos[n].z + (double)k;
			postmp[nions_new].ityp = pos[n].ityp;
			nions_new++;
		}
	nions_new = 0;
        for (int i = 0; i < nions_tmp; i++) 
		if(postmp[i].x <= a_new && postmp[i].y <= b_new && postmp[i].z <= c_new && postmp[i].ityp != 0)
			pos_new[nions_new++] = postmp[i];
	return nions_new;
}
void Mutate_Cell(Posion *latt,double delta){
	double a,b,c,alpha,beta,gamma;
	Get_Cell_Para(latt,a,b,c,alpha,beta,gamma);
	a = RandomDouble(a-delta*a, a+delta*a); // +- delta
	b = RandomDouble(b-delta*b, b+delta*b); // +- delta
	c = RandomDouble(c-delta*c, c+delta*c); // +- delta
	alpha = RandomDouble(alpha-delta*alpha, alpha+delta*alpha); // +- delta
	beta = RandomDouble(beta-delta*beta, beta+delta*beta); // +- delta
	gamma = RandomDouble(gamma-delta*gamma, gamma+delta*gamma); // +- delta
	Gen_Cell(latt,a,b,c,alpha,beta,gamma);
}

void Init_Structure(Posion *latt,Posion *pos, int *atom_type, GAPara ga_info, double *vec_fixedt){
	double volume = 0.0;
	double slabratio=ga_info.zslab/ga_info.ztotal;
	int nions,npos, nsite;
	int *tmp_type = new int[ga_info.ntype];
	string ss;
	int first = atom_type[0];
	Posion *site;
	nions = ga_info.nions-first;
        for (int i = 0; i < ga_info.ntype; i++) {
		volume+=atom_type[i]*ga_info.vol[i];
		tmp_type[i]=atom_type[i];
	}
	Init_Cell(latt, volume, ga_info);
        for (int i = 0; i < atom_type[0]; i++)
		pos[i].x=pos[i].y=pos[i].z=0.0;
	for (int i = 0; i < ga_info.nions; i++) pos[i].ityp=0;
	npos  = Read_pos_head();
	nsite = Read_site_head();

	//interface, if top part is allowed to move as a rigid body
	//randomly choose the move along x and y directions
	if(ga_info.nfixedt !=0 && ga_info.movetop){
		double move1, move2;
		move1 = RandomDouble(0, 0.5);
		move2 = RandomDouble(0, 0.5);
		vec_fixedt[0] = move1 * latt[0].x + move2 * latt[1].x;
		vec_fixedt[1] = move1 * latt[0].y + move2 * latt[1].y;
	}
// pos.in cartesian
// site.in direct
	if( npos!=0 && npos < nions) {
		fstream pos_in("./pos.in", ios::in);
		pos_in >> npos;
		getline(pos_in, ss);
        	for (int i = 0; i < npos; i++){
			pos_in >> pos[i+first].x >> pos[i+first].y >> pos[i+first].z >> pos[i+first].ityp;
			getline(pos_in, ss);
			tmp_type[pos[i+first].ityp%10]--;
		}
		pos_in.close();
		KarDir(latt,pos+first,npos);
		first += npos;
	} else if( npos == nions)
		cout << "Warning: every structures will be the same!" << endl;
	else if(npos != 0)
		cout << "Warning: pos.in will be omitted." << endl;

	if(Read_template_head() || ga_info.systype == 2){
		pos[first].x=RandomDouble(0,1); pos[first].y=RandomDouble(0,1); pos[first].z=(ga_info.dimen==3?RandomDouble(0,1):RandomDouble(0,slabratio));
	} else {
		pos[first].x=pos[first].y=pos[first].z=0.0;
		//if(ga_info.dimen==2)  pos[first].z=0.5;
	}
	if( nsite != 0) {
		site = new Posion[nsite];
		fstream site_in("./site.in", ios::in);
		site_in >> nsite;
		getline(site_in, ss);
        	for (int i = 0; i < nsite; i++){
			site_in >> site[i].x >> site[i].y >> site[i].z >> site[i].ityp;
			getline(site_in, ss);
		}
		site_in.close();
		Shuffle_atom(site+1,nsite-1);
		pos[first] = site[0];
	}
        for (int i = first+1; i < ga_info.nions; i++){
		int accept = 1;
		while(accept){
			int j,bond_count = 1;
			if(nsite == 0){
				bond_count = 0;
				//for cluster search
				if (ga_info.systype==1) {
					pos[i].x=RandomDouble(0,0.3);
	                                pos[i].y=RandomDouble(0,0.3);
                                        pos[i].z=RandomDouble(0,0.3);
				}
				else{
					pos[i].x=RandomDouble(0,1);
					pos[i].y=RandomDouble(0,1);
					pos[i].z=(ga_info.dimen==3?RandomDouble(0,1):RandomDouble(0,slabratio));
				}
			} else  pos[i] = site[i-first];
                	for (j = tmp_type[0]; j < i; j++){
				double tmpbond = Bond_length(latt,pos[i],pos[j]);
				if(tmpbond < ga_info.rcut){accept=1;break;}
				if(tmpbond < ga_info.rcut*3){bond_count++;}
			}
			if (j==i && bond_count != 0) accept = 0;
                }
	}
	int k = first;
        for (int i = 1; i < ga_info.ntype; i++)
        	for (int j = 0; j < tmp_type[i]; j++){
			if(pos[k].ityp==0)pos[k++].ityp = i;
			else {tmp_type[pos[k++].ityp]--;j--;}
		}
	Sort_Type (pos, ga_info.nions);
	DirKar(latt,pos,ga_info.nions);
//	Shuffle_Type(pos,n);
}

int Read_template_head(){ // first test for Au/Si(111)
	int new_nions=0;
	fstream template_in("./template.in", ios::in);
	if(template_in) template_in >> new_nions;
	return new_nions;
}

int Read_Database(Posion *latt[],Posion *pos[],int *id,int *nions){
	int libsize,itmp;
	double dtmp;
	char str[256];
	fstream pos_in("./struc_lib.dat", ios::in);
	if(!pos_in) {
		pos_in.close();
		return 0;
	}
	pos_in >> libsize;
	//latt = new Posion*[libsize];
	//pos  = new Posion*[libsize];
	//nions  = new int[libsize];
	for ( int i = 0 ; i < libsize; i++) {
		pos_in.getline(str,256);
		pos_in.getline(str,256);
		pos_in >> str;
		pos_in >> id[i] >> dtmp >> dtmp >> nions[i];
		latt[i] = new Posion[3];
		pos[i]  = new Posion[nions[i]];
		int nions_tmp = 0;
		while(nions_tmp < nions[i]){
			pos_in >> itmp ;
			nions_tmp += itmp;
		}
                pos_in >> latt[i][0].x >> latt[i][0].y >> latt[i][0].z ;
                pos_in >> latt[i][1].x >> latt[i][1].y >> latt[i][1].z ;
                pos_in >> latt[i][2].x >> latt[i][2].y >> latt[i][2].z ;
		for ( int j = 0 ; j < nions[i]; j++) 
                	pos_in >> pos[i][j].x >> pos[i][j].y >> pos[i][j].z >> pos[i][j].ityp;
	}
	return libsize;
}

int Read_pos_head(){ 
	int new_nions=0;
	fstream pos_in("./pos.in", ios::in);
	if(pos_in) pos_in >> new_nions;
	return new_nions;
}


int Read_site_head(){ 
	int new_nions=0;
	fstream pos_in("./site.in", ios::in);
	if(pos_in) pos_in >> new_nions;
	return new_nions;
}

void Read_template(double *latt, double *pos, int nions){
	int new_nions=0;
	fstream template_in("./template.in", ios::in);
	if(template_in) template_in >> new_nions;
	template_in >> latt[0] >> latt[1] >> latt[2];
	template_in >> latt[4] >> latt[5] >> latt[6];
	template_in >> latt[8] >> latt[9] >> latt[10];
	int offset;
	for ( int i = 0 ; i < nions; i++) {
		offset = i*4;
		template_in >> pos[offset+0] 
			    >> pos[offset+1] 
			    >> pos[offset+2] 
			    >> pos[offset+3];
	}
}

void Merge_template(double *pos,double *pos_template,double *newpos,double *latt, double *latt_template, double *newlatt,int nions, int temp_nions){ 
	int new_nions = nions + temp_nions;
	int i;
	for (i = 0; i < nions*4; i++) newpos[i] = pos[i];
	for (     ; i < new_nions*4; i++) newpos[i] = pos_template[i-nions*4];
	if (temp_nions == 0) for (i = 0; i < 12; i++) newlatt[i] = latt[i];
	else for (i = 0; i < 12; i++) newlatt[i] = latt_template[i];
}

void Remove_template(double *pos1,double *pos2,int nions){ 
	for ( int i = 0; i < nions; i++) {
		pos2[i*4+0] = pos1[i*4+0];
		pos2[i*4+1] = pos1[i*4+1];
		pos2[i*4+2] = pos1[i*4+2];
		pos2[i*4+3] = pos1[i*4+3];
	}
}

void Adjust_volume(Posion *latt, Posion *pos, int *atom_type,double *vol,int ntype, int nions){
	double oldvol = Cell_Volume(latt);
	double newvol = 0;
	for ( int i = 0; i < ntype; i++) 
		newvol += ( atom_type[i]*vol[i] );
	if(newvol == 0.0) return;
	newvol = cbrt(newvol/oldvol);
	KarDir(latt,pos,nions);
	latt[0] = latt[0]*newvol;
	latt[1] = latt[1]*newvol;
	latt[2] = latt[2]*newvol;
	DirKar(latt,pos,nions);
}

void Expand_Cell(Posion *latt, Posion *pos, Posion *lattnew, Posion *posnew,int nions, int nx,int ny, int nz){
	if(nx < 1 || ny < 1 || nz < 1) return;
	int k = 0;
	lattnew[0]=latt[0]*(double)nx;
	lattnew[1]=latt[1]*(double)ny;
	lattnew[2]=latt[2]*(double)nz;
        for (int i = 0; i < nions; i++){
        	for (int l = 0; l < nx; l++)
        	for (int m = 0; m < ny; m++)
        	for (int n = 0; n < nz; n++){
			posnew[k].x = pos[i].x + latt[0].x*(double)l + latt[1].x*(double)m + latt[2].x*(double)n;
			posnew[k].y = pos[i].y + latt[0].y*(double)l + latt[1].y*(double)m + latt[2].y*(double)n;
			posnew[k].z = pos[i].z + latt[0].z*(double)l + latt[1].z*(double)m + latt[2].z*(double)n;
			posnew[k].ityp = pos[i].ityp;
			k++;
		}
	}
}

// Align to triangular form; sort cell angles
void Align_Structure(Posion *latt, Posion *pos, int nions){
	double a,b,c,gamma,alpha,beta;
	int order;
	Posion latt_tmp;
	KarDir(latt,pos,nions);
	a = sqrt(latt[0].x*latt[0].x+latt[0].y*latt[0].y+latt[0].z*latt[0].z);
	b = sqrt(latt[1].x*latt[1].x+latt[1].y*latt[1].y+latt[1].z*latt[1].z);
	c = sqrt(latt[2].x*latt[2].x+latt[2].y*latt[2].y+latt[2].z*latt[2].z);
	latt_tmp  = latt[0]*latt[1];
	gamma = acos((latt_tmp.x+latt_tmp.y+latt_tmp.z)/a/b);
	latt_tmp  = latt[1]*latt[2];
	alpha = acos((latt_tmp.x+latt_tmp.y+latt_tmp.z)/b/c);
	latt_tmp  = latt[2]*latt[0];
	beta  = acos((latt_tmp.x+latt_tmp.y+latt_tmp.z)/c/a);
	if(gamma > alpha && alpha > beta ) order = 0; //  1 2 3
	if(gamma > beta  && beta  > alpha) order = 1; //  1 3 2 b a c
	if(alpha > gamma && gamma > beta ) order = 2; //  2 1 3 c b a
	if(alpha > beta  && beta  > gamma) order = 3; //  2 3 1 c a b
	if(beta  > alpha && alpha > gamma) order = 4; //  3 2 1 a c b
	if(beta  > gamma && gamma > alpha) order = 5; //  3 1 2 b c a
	switch(order){
		case 0:
			break;
		case 1:
			Switch_xy(pos, nions);
			latt_tmp = latt[0];latt[0] = latt[1];latt[1] = latt_tmp;
			break;
		case 2:
			Switch_xz(pos, nions);
			latt_tmp = latt[0];latt[0] = latt[2];latt[2] = latt_tmp;
			break;
		case 3:
			latt_tmp = latt[0];latt[0] = latt[2];latt[2] = latt_tmp;
			latt_tmp = latt[1];latt[1] = latt[2];latt[2] = latt_tmp;
			Switch_xz(pos, nions);
			Switch_yz(pos, nions);
			break;
		case 4:
			latt_tmp = latt[1];latt[1] = latt[2];latt[2] = latt_tmp;
			Switch_yz(pos, nions);
			break;
		case 5:
			latt_tmp = latt[1];latt[1] = latt[2];latt[2] = latt_tmp;
			latt_tmp = latt[0];latt[0] = latt[2];latt[2] = latt_tmp;
			Switch_yz(pos, nions);
			Switch_xz(pos, nions);
			break;
		default:;
	}
	DirKar(latt,pos,nions);
	Align_Cell(latt,pos,nions);
}

// Switch xyz coordinates, used by Align_Structure
void Switch_xy(Posion *pos, int nions){
	double temp;
        for (int i = 0; i < nions; i++){
		temp = pos[i].x; pos[i].x = pos[i].y; pos[i].y = temp;
		temp = pos[i].fx; pos[i].fx = pos[i].fy; pos[i].fy = temp;
	}
}

void Switch_xz(Posion *pos, int nions){
	double temp;
        for (int i = 0; i < nions; i++){
		temp = pos[i].x; pos[i].x = pos[i].z; pos[i].z = temp;
		temp = pos[i].fx; pos[i].fx = pos[i].fz; pos[i].fz = temp;
	}
}

void Switch_yz(Posion *pos, int nions){
	double temp;
        for (int i = 0; i < nions; i++){
		temp = pos[i].z; pos[i].z = pos[i].y; pos[i].y = temp;
		temp = pos[i].fz; pos[i].fz = pos[i].fy; pos[i].fy = temp;
	}
}

// Correct atom number after mating
void Adjust_Structure(Posion *latt, Posion *pos, int cur_nions,int nions, double RCUT){
	KarDir(latt,pos,cur_nions);
	int first;
        for (int i = 0; i < nions; i++)
		if(pos[i].ityp != 0){
			first = i;
			break;
		}

        for (int i = cur_nions; i < nions; i++){
		int accept = 1;
		while(accept){
			pos[i].x=RandomDouble(0,1);
			pos[i].y=RandomDouble(0,1);
			pos[i].z=RandomDouble(0,1);
			int j;
                	for (j = first; j < i; j++)
				if(Bond_length(latt,pos[i],pos[j]) < RCUT){accept=1;break;}
			if (j==i) accept = 0;
                }
		pos[i].ityp = 999;
	}
	Sort_Type(pos, nions);
	DirKar(latt,pos,nions);
}


void Sort_Type(Posion *pos, int nions){
        Posion postmp;
        for ( int i = 0; i < nions; i++)
                for ( int j = 0; j < nions - i - 1; j++){
                        if (pos[j].ityp > pos[j+1].ityp) {
                                //swap 
                                postmp=pos[j]; pos[j]=pos[j+1]; pos[j+1]=postmp;
                        }
                }
}

void Get_Type(Posion *pos, int nions, int *atom_type, int ntype){
	for( int i = 0; i < ntype; i++ ){
		atom_type[i] = 0;
		for( int j = 0; j < nions; j++ )
			if ( pos[j].ityp%10 == i ) atom_type[i]++;
	}
}

void Put_Type(Posion *pos, int nions, int *atom_type, int ntype){
	int k = 0;
	for( int i = 0; i < ntype; i++ )
		for( int j = 0; j < atom_type[i]; j++ )
			pos[k++].ityp = pos[k++].ityp-pos[k++].ityp%10 + i;
}

// correct structure when communication fails
void Correct_structure(Posion *latt,Posion *pos,double &ene, double &press, double *stress, int nions, int ntype){
	int itmp = pos[nions-1].ityp%10;
	if ( itmp <= (ntype-1) ) return;
	double fact = itmp/(ntype - 1);
	for( int i = 0; i < nions; i++ ){
		pos[i] = pos[i]/fact;
		pos[i].ityp /= (int)fact;
		pos[i].fx /= (double)fact;
		pos[i].fy /= (double)fact;
		pos[i].fz /= (double)fact;
	}
	latt[0] = latt[0]/fact;
	latt[1] = latt[1]/fact;
	latt[2] = latt[2]/fact;
	ene = ene/fact;
	press = press/fact;
	for( int i = 0; i < 6; i++ )
		stress[i] = stress[i]/fact;
}

void Adjust_Atomtype(Posion *pos, int nions, int *atom_type, int ntype){
	int *cur_type = new int[ntype];
	int *d_type   = new int[ntype];	
	int undefined = 0;
	for( int i = 0; i < ntype; i++ ){
		cur_type[i] = 0;
		for( int j = 0; j < nions; j++ )
			if ( pos[j].ityp == i ) cur_type[i]++;
		undefined += cur_type[i];
		d_type[i] = cur_type[i] - atom_type[i];
	}
	int cur_pos = 0;
	undefined = nions - undefined;
	for( int i = 0; i < ntype; i++ ){
		if ( d_type[i] <= 0 ) cur_pos += cur_type[i];
		else {
			for(int j = 0; j < d_type[i]; j++){
				while(1){
					int itmp = RandomInt(0,cur_type[i]-1);
					if ( pos[cur_pos + itmp].ityp == 999) continue;
					else {
						pos[cur_pos + itmp].ityp = 999;
						undefined++;
						break;
					}
				}
			}
			cur_pos += cur_type[i];
			d_type[i] = 0;
			cur_type[i] = atom_type[i];
		}
	}
	Sort_Type(pos, nions);
	cur_pos = 0;
	for( int i = 0; i < ntype; i++ ){
		if ( d_type[i] == 0 ) cur_pos += cur_type[i];
		else {
			d_type[i] = -d_type[i];
			for(int j = 0; j < d_type[i]; j++){
				pos[nions-undefined].ityp =i;
				undefined--;
			}
		}
	}
	Sort_Type(pos, nions);
	for( int i = 0; i < nions; i++ )
		if( pos[i].ityp == 0) 
			pos[i].x = pos[i].y = pos[i].z = 0.0;
	for( int i = atom_type[0]; i < atom_type[0]+atom_type[1]; i++ )
		if( pos[i].x == 0.0 && pos[i].y == 0.0 && pos[i].z == 0.0) {
		Posion tmp = pos[i];
			pos[i] = pos[atom_type[0]];
			pos[atom_type[0]] = tmp;
			break;
		}
	delete cur_type;
	delete d_type;
}

double Bond_length(const Posion *latt,const Posion pos1, Posion pos2){
	double dx,dy,dz;
	Posion dr;
	dr.x=dr.y=dr.z=0.0;
	int I1,I2,I3;
	double dis = 9999.9,d;
	for(I1=-1;I1<=1;I1++)
	for(I2=-1;I2<=1;I2++)
	for(I3=-1;I3<=1;I3++){
		dr.x=dr.y=dr.z=0.0;
		dx = pos1.x - pos2.x + 10.5;
		dy = pos1.y - pos2.y + 10.5;
		dz = pos1.z - pos2.z + 10.5;
		dx = dx - int(dx) - 0.5 +I1;
		dy = dy - int(dy) - 0.5 +I2;
		dz = dz - int(dz) - 0.5 +I3;
/*             DX = MOD(POSION(1,NI)-POSION(1,NII)+10.5_q,1._q) -.5+I1
               DY = MOD(POSION(2,NI)-POSION(2,NII)+10.5_q,1._q) -.5+I2
               DZ = MOD(POSION(3,NI)-POSION(3,NII)+10.5_q,1._q) -.5+I3
*/
		dr = dr + latt[0]*dx;
		dr = dr + latt[1]*dy;
		dr = dr + latt[2]*dz;
		d = sqrt(dr.x*dr.x + dr.y*dr.y + dr.z*dr.z);
		if(d<dis) dis = d;
	}

	return dis;
	// periodical boundary condition
}

void Bond_length(const Posion *latt,const Posion pos1, const Posion pos2, double *len){
	double dx,dy,dz;
	Posion dr;
	dr.x=dr.y=dr.z=0.0;
	int I1,I2,I3;
	double dis = 9999.9,d;
	int count = 0;
	for(I1=-2;I1<=2;I1++)
	for(I2=-2;I2<=2;I2++)
	for(I3=-2;I3<=2;I3++){
		dr.x=dr.y=dr.z=0.0;
		dx = pos1.x - pos2.x - I1;
		dy = pos1.y - pos2.y - I2;
		dz = pos1.z - pos2.z - I3;
/*             DX = MOD(POSION(1,NI)-POSION(1,NII)+10.5_q,1._q) -.5+I1
               DY = MOD(POSION(2,NI)-POSION(2,NII)+10.5_q,1._q) -.5+I2
               DZ = MOD(POSION(3,NI)-POSION(3,NII)+10.5_q,1._q) -.5+I3
*/
		dr = dr + latt[0]*dx;
		dr = dr + latt[1]*dy;
		dr = dr + latt[2]*dz;
		d = sqrt(dr.x*dr.x + dr.y*dr.y + dr.z*dr.z);
		len[count++] = d;
	}
	// periodical boundary condition
}

double Bond_angle(double a,double b,double c){
	return  acos(-(c*c-a*a-b*b)/a/b/2.0)/3.1415926*180.0;
}

int Within_Box(Posion *latt,Posion origin,Posion pos){
	// pos in cartesian coordination
	Posion postmp = pos - origin,r;
	Posion latt_b[3];
	double  dtmp;
	Latt_A2B(latt,latt_b);
	r = latt_b[0]*postmp;
	dtmp=r.x+r.y+r.z;
	if( dtmp > 1.0 || dtmp < 0.0) return 1;
	r = latt_b[1]*postmp;
	dtmp=r.x+r.y+r.z;
	if( dtmp > 1.0 || dtmp < 0.0) return 1;
	r = latt_b[2]*postmp;
	dtmp=r.x+r.y+r.z;
	if( dtmp > 1.0 || dtmp < 0.0) return 1;
	return 0;
}

void DirKar(const Posion *latt,Posion *pos,int nions){
	Posion r;
	for (int i = 0; i < nions; i++){
		r.x=r.y=r.z=0.0;
		r = r + latt[0]*pos[i].x;
		r = r + latt[1]*pos[i].y;
		r = r + latt[2]*pos[i].z;
		r.ityp = pos[i].ityp;
		r.fx = pos[i].fx;
		r.fy = pos[i].fy;
		r.fz = pos[i].fz;
		pos[i]=r;
	}
}

void KarDir(const Posion *latt,Posion *pos, int nions){
	Posion latt_b[3];
	Posion r,postmp;
	Latt_A2B(latt,latt_b);
	for (int i = 0; i < nions; i++){
		postmp = pos[i];
		r = latt_b[0]*postmp; pos[i].x=r.x+r.y+r.z;
		r = latt_b[1]*postmp; pos[i].y=r.x+r.y+r.z;
		r = latt_b[2]*postmp; pos[i].z=r.x+r.y+r.z;

		if(pos[i].ityp<10){
		      	pos[i].x=fmod(pos[i].x+50.000000000001,1.0);
		      	pos[i].y=fmod(pos[i].y+50.000000000001,1.0);
	      		pos[i].z=fmod(pos[i].z+50.000000000001,1.0);
		}
	}

}

void DirKar(const double *latt,double *pos,int nions){
	Posion r,pos2,latt2[3];
	for (int i = 0; i < 3; i++){
		latt2[i].x=latt[i*4+0];
		latt2[i].y=latt[i*4+1];
		latt2[i].z=latt[i*4+2];
	}
	for (int i = 0; i < nions; i++){
		r.x=r.y=r.z=0.0;
		pos2.x=pos[i*4+0];
		pos2.y=pos[i*4+1];
		pos2.z=pos[i*4+2];
		r = r + latt2[0]*pos2.x;
		r = r + latt2[1]*pos2.y;
		r = r + latt2[2]*pos2.z;
		pos2=r;
		pos[i*4+0]=pos2.x;
		pos[i*4+1]=pos2.y;
		pos[i*4+2]=pos2.z;
	}
}

void KarDir(const double *latt,double *pos, int nions){
	Posion latt_b[3];
	Posion postmp;
	Posion r,pos2,latt2[3];
	for (int i = 0; i < 3; i++){
		latt2[i].x=latt[i*4+0];
		latt2[i].y=latt[i*4+1];
		latt2[i].z=latt[i*4+2];
	}
	Latt_A2B(latt2,latt_b);
	for (int i = 0; i < nions; i++){
		pos2.x=pos[i*4+0];
		pos2.y=pos[i*4+1];
		pos2.z=pos[i*4+2];
		pos2.ityp=pos[i*4+3];
		postmp = pos2;
		r = latt_b[0]*postmp; pos2.x=r.x+r.y+r.z;
		r = latt_b[1]*postmp; pos2.y=r.x+r.y+r.z;
		r = latt_b[2]*postmp; pos2.z=r.x+r.y+r.z;
		if(pos2.ityp<10){
			pos2.x=fmod(pos2.x+50.000000000001,1.0);
		      	pos2.y=fmod(pos2.y+50.000000000001,1.0);
		      	pos2.z=fmod(pos2.z+50.000000000001,1.0);
		}
		pos[i*4+0]=pos2.x;
		pos[i*4+1]=pos2.y;
		pos[i*4+2]=pos2.z;
	}
}

void Latt_A2B(const double *latt, double *latt_b){
	Posion a[3],b[3];
	double omega;
	a[0].x=latt[0];
	a[0].y=latt[1];
	a[0].z=latt[2];
	a[1].x=latt[4];
	a[1].y=latt[5];
	a[1].z=latt[6];
	a[2].x=latt[8];
	a[2].y=latt[9];
	a[2].z=latt[10];
	XPro(a[1],a[2],b[0]);
	XPro(a[2],a[0],b[1]);
	XPro(a[0],a[1],b[2]);
	omega=b[0].x*a[0].x+b[0].y*a[0].y+b[0].z*a[0].z;
	b[0]=b[0]/omega;
	b[1]=b[1]/omega;
	b[2]=b[2]/omega;
	latt_b[0]=b[0].x;
	latt_b[1]=b[0].y;
	latt_b[2]=b[0].z;
	latt_b[4]=b[1].x;
	latt_b[5]=b[1].y;
	latt_b[6]=b[1].z;
	latt_b[8]=b[2].x;
	latt_b[9]=b[2].y;
	latt_b[10]=b[2].z;
}

void Latt_A2B(const Posion *a, Posion *b){
	double omega;
	XPro(a[1],a[2],b[0]);
	XPro(a[2],a[0],b[1]);
	XPro(a[0],a[1],b[2]);
	omega=b[0].x*a[0].x+b[0].y*a[0].y+b[0].z*a[0].z;
	b[0]=b[0]/omega;
	b[1]=b[1]/omega;
	b[2]=b[2]/omega;
}

double Cell_Volume(const Posion *a){
	Posion b[3];
	XPro(a[1],a[2],b[0]);
	XPro(a[2],a[0],b[1]);
	XPro(a[0],a[1],b[2]);
	return b[0].x*a[0].x+b[0].y*a[0].y+b[0].z*a[0].z;
}

void XPro(Posion a, Posion b, Posion &c){
	c.x=a.y * b.z - a.z * b.y;
	c.y=a.z * b.x - a.x * b.z;
	c.z=a.x * b.y - a.y * b.x;
}

void Regen_Structure(Posion *pos,int nions){
        struct timeval time;
        gettimeofday(&time,NULL);
        srand(time.tv_usec) ;
        for (int i = 0; i < nions; i++)
                        pos[i].ityp=rand()%2;
}

void Shuffle_Type(Posion *pos, int nions){
	// mutate
        double tmp;
	int m,n,first,last=nions-1;
//	Get_Type(pos,nions,atom_type,ntype);
//	int first = atom_type[0];
	int i;
        for (i = 0; i < nions; i++) 
		if(pos[i].ityp != 0) {
			first=i;
			break;
		}
        for (; i < nions; i++) 
		if(pos[i].ityp > 10) {
			last=i-1;
			break;
		}
	if(pos[first].x == 0.0  && pos[first].y == 0.0 && pos[first].z == 0.0 ) first++;
	m = RandomInt(first, last); 
	n = RandomInt(first, last); 
	tmp = pos[m].x; pos[m].x = pos[n].x; pos[n].x = tmp;
	tmp = pos[m].y; pos[m].y = pos[n].y; pos[n].y = tmp;
	tmp = pos[m].z; pos[m].z = pos[n].z; pos[n].z = tmp;
/*        for (int i = nions-1; i > first; i--){
		m = RandomInt(first, i); 
		tmp = pos[m].x; pos[m].x = pos[i].x; pos[i].x = tmp;
		tmp = pos[m].y; pos[m].y = pos[i].y; pos[i].y = tmp;
		tmp = pos[m].z; pos[m].z = pos[i].z; pos[i].z = tmp;
	} */
}

void Shuffle_atom(Posion *pos, int nions){
        double tmp;
	int m;
        for (int i = nions-1; i > 0; i--){
		m = RandomInt(0, i); 
		tmp = pos[m].x; pos[m].x = pos[i].x; pos[i].x = tmp;
		tmp = pos[m].y; pos[m].y = pos[i].y; pos[i].y = tmp;
		tmp = pos[m].z; pos[m].z = pos[i].z; pos[i].z = tmp;
		tmp = pos[m].ityp; pos[m].ityp = pos[i].ityp; pos[i].ityp = tmp;
	}
}

void Convert_structure(Posion *pos1[], double *pos2, int poolsize, int nions){
	int offset;
       	for (int i = 0; i < poolsize; i++)
 		for (int j = 0; j < nions; j++) {
			offset = i*nions*4+4*j;
			pos2[offset+0]=pos1[i][j].x;
			pos2[offset+1]=pos1[i][j].y;
			pos2[offset+2]=pos1[i][j].z;
			pos2[offset+3]=(double)pos1[i][j].ityp;
		}
}

void Convert_structure(const double *pos1, Posion *pos2[], int poolsize, int nions){
	int offset;
       	for (int i = 0; i < poolsize; i++){
 		for (int j = 0; j < nions; j++) {
			offset = i*nions*4+4*j;
			pos2[i][j].x=pos1[offset+0];
			pos2[i][j].y=pos1[offset+1];
			pos2[i][j].z=pos1[offset+2];
			pos2[i][j].ityp=(int)pos1[offset+3];
		}
	}
}

void Convert_structure(const double *pos1, const double *force, Posion *pos2[], int poolsize, int nions){
	int offset;
       	for (int i = 0; i < poolsize; i++){
 		for (int j = 0; j < nions; j++) {
			offset = i*nions*4+4*j;
			pos2[i][j].x=pos1[offset+0];
			pos2[i][j].y=pos1[offset+1];
			pos2[i][j].z=pos1[offset+2];
			pos2[i][j].fx=force[offset+0];
			pos2[i][j].fy=force[offset+1];
			pos2[i][j].fz=force[offset+2];
			pos2[i][j].ityp=(int)pos1[offset+3];
		}
	}
}

void Write_Structure(char *filename,Posion *latt,Posion *pos,double ene,int id,int *atom_type, int ntype, int nions,int app){
	char str[256];
	//Write_Iso("./iso.tmp",latt,pos,0,nions,ntype,0);
	//system("findsym < iso.tmp | grep Space > symm.out");
	//fstream fin("./symm.out", ios::in);
	//fin.getline(str, 256);
	//fin.close();
	KarDir(latt,pos,nions);
	fstream fout;
	if(app == 1) fout.open(filename,ios::app|ios::out);
	else fout.open(filename,ios::out);
	fout << id << ' ' << ene << ' ' << endl;
	fout << " 1.00" << endl;
	fout << latt[0] << endl;
	fout << latt[1] << endl;
	fout << latt[2] << endl;
        for (int i = 1; i < ntype; i++)
		fout << ' ' << atom_type[i];
        fout << endl << "Direct" << endl;
        for (int i = atom_type[0]; i < nions; i++)
                        fout <<  pos[i] << endl;
	fout.close();
	DirKar(latt,pos,nions);
}

void Print_Structure(Posion *latt,Posion *pos,int *atom_type, int ntype, int nions){
	cout << " Si" << endl;
	cout << " 1.00" << endl;
	cout << latt[0] << endl;
	cout << latt[1] << endl;
	cout << latt[2] << endl;
        for (int i = 1; i < ntype; i++)
		cout << ' ' << atom_type[i];
        cout << endl << "Cirect" << endl;
        for (int i = atom_type[0]; i < nions; i++)
                        cout <<  pos[i] << endl;
}

void Copy_posion(Posion *pos, Posion *pos_dest, int nions){
        for (int i = 0; i < nions; i++)
		pos_dest[i] = pos[i];
}


void Write_Poscar(int ntype, int nions){
        fstream fout("./POSCAR",ios::out);
	fout << " Si" << endl;
	fout << " 1.00" << endl;
	fout << 1.0 << ' ' << 0.0 << ' ' << 0.0 << endl;
	fout << 0.0 << ' ' << 1.0 << ' ' << 0.0 << endl;
	fout << 0.0 << ' ' << 0.0 << ' ' << 1.0 << endl;
        for (int i = 0; i < ntype-1; i++)
		fout << ' ' << 1;
	fout << ' ' << nions - ntype+1;
	fout << endl << "S" << endl << "D" << endl;
        for (int i = 0; i < nions; i++)
			fout << 1.0 << ' ' << 1.0 << ' ' << 1.0 << ' ' << "T T T" << endl;
	fout.close();
}

void Print_Structure(const Posion *latt,Posion *pos,int nions){
	cout << " Al" << endl;
	cout << " 1.00" << endl;
	cout << latt[0] << endl;
	cout << latt[1] << endl;
	cout << latt[2] << endl;
        cout << ' '<< nions << endl << "Direct" << endl;
        for (int i = 0; i < nions; i++)
                        cout <<  pos[i] << endl;
}

void Write_Pool(char *filename, Posion *latt[],Posion *pos[],double *ene,double *press,int *struc_id, int poolsize,int nions,int ntype){
	int *atom_type;
	atom_type = new int[ntype];
	fstream fout;
	if(poolsize == 1)
        	fout.open(filename,ios::app|ios::out);
	else {
        	fout.open(filename,ios::out);
        	fout << poolsize << ' ' << nions << ' ' << struc_id[poolsize] << endl;
	}
	cout << "Writing: " << filename << ' ' << poolsize << endl;
        for (int i = 0; i < poolsize; i++){
		Get_Type(pos[i],nions,atom_type,ntype);
		fout << "ID: " << struc_id[i] << setiosflags(ios::fixed) << setw(12) << setprecision(4) << ene[i] << ' ' << press[i] << ' ';
                for (int j = 0; j < ntype; j++) fout << atom_type[j] << ' ';
		fout << endl;
                fout << latt[i][0] << endl;
                fout << latt[i][1] << endl;
                fout << latt[i][2] << endl;
                for (int j = 0; j < nions; j++){
			if(pos[i][j].ityp == 0 && pos[i][j].x > 1e-6)
                        	cout << "possible error " << pos[i][j] << ' ' << pos[i][j].ityp << endl;
			if(pos[i][j].ityp == 0)
				continue;
                        fout << pos[i][j] << ' ' << pos[i][j].ityp << endl;
		}
        }
	fout.flush();
	fout.close();
}

void Write_Pool(char *filename, Posion *latt,Posion *pos,double ene, double press, int struc_id, int nions,int ntype){
	int *atom_type;
	atom_type = new int[ntype];
	fstream fout;
        fout.open(filename,ios::app|ios::out);
	Get_Type(pos,nions,atom_type,ntype);
	cout << "Writing: " << filename << ' ' << 1 << endl;
	fout << "ID: " << struc_id << setiosflags(ios::fixed) << setw(12) << setprecision(4) << ene << ' ' << press << ' ';
        for (int j = 0; j < ntype; j++) fout << atom_type[j] << ' ';
	fout << endl;
        fout << latt[0] << endl;
        fout << latt[1] << endl;
        fout << latt[2] << endl;
        for (int j = 0; j < nions; j++){
       		fout << pos[j] << ' ' << pos[j].ityp << endl;
	}
	fout.flush();
	fout.close();
}
int Write_Potfit(char *filename, Posion *latt[],Posion *pos[],double *ene,double *stress,int *struc_id, int poolsize,int nions,int ntype){
	int *atom_type,j,npool=0;
	char str[256];
	atom_type = new int[ntype];
	fstream fout;
	if(poolsize==1) fout.open(filename,ios::out|ios::app);
	else fout.open(filename,ios::out);
	fstream fin("./potconf.in",ios::in);
        if(fin)
		do{
			fin.getline(str,256);	
			fout << str << endl;
		}while(!fin.eof());
	fin.close();
	
        for (int i = 0; i < poolsize; i++){
		if(ene[i]==ENENONE) continue;
		Get_Type(pos[i],nions,atom_type,ntype);
                for (j = atom_type[0]; j < nions; j++){
                        if( fabs(pos[i][j].fx) > 50.0) break;
                        if( fabs(pos[i][j].fy) > 50.0) break;
                        if( fabs(pos[i][j].fz) > 50.0) break;
		}
		if(pos[i][atom_type[0]].ityp!=1) {cout << j << ' ' << pos[i][atom_type[0]].ityp << " bad structure " << endl; continue;}
		npool++;
		fout << "#N " << nions-atom_type[0] << "  1" << endl;
		fout << "#C Fe P " << endl;
                fout << "## force file generated from GA" << endl;
                fout << "#X " << latt[i][0] << endl;
                fout << "#Y " << latt[i][1] << endl;
                fout << "#Z " << latt[i][2] << endl;
                fout << "#W " << 1.0/double(i+1) << endl;
                fout << "#E " << ene[i]/(nions-atom_type[0]) << endl;
                fout << "#S " << stress[i*6+0] << ' ' 
		              << stress[i*6+1] << ' ' 
		              << stress[i*6+2] << ' ' 
		              << stress[i*6+3] << ' ' 
		              << stress[i*6+4] << ' ' 
		              << stress[i*6+5] << ' ' << endl;
                fout << "#F" << endl;
                for (int j = atom_type[0]; j < nions; j++){
                        fout << pos[i][j].ityp%10-1 << ' ' << pos[i][j] << ' ' << pos[i][j].fx << ' ' << pos[i][j].fy << ' '<< pos[i][j].fz << endl;
		}
        }
	cout << "Writing: " << filename << ' ' << npool << endl;
	fout.close();
	return npool;
}

int Write_Potfit_Suf(char *filename, Posion *latt[],Posion *pos[],double *ene,double *stress,int *struc_id, int poolsize,int nions,int ntype, double *pos_template, double force_queue_dft){
	int *atom_type,j,npool=0;
	char str[256];
	atom_type = new int[ntype];
	fstream fout;
	if(poolsize==1) fout.open(filename,ios::out|ios::app);
	else fout.open(filename,ios::out);
	fstream fin("./potconf.in",ios::in);
        if(fin)
		do{
			fin.getline(str,256);	
			fout << str << endl;
		}while(!fin.eof());
	fin.close();
	
        for (int i = 0; i < poolsize; i++){
		if(ene[i]==ENENONE) continue;
		Get_Type(pos[i],nions,atom_type,ntype);
                for (j = atom_type[0]; j < nions; j++){
                        if( fabs(pos[i][j].fx) > 50.0) break;
                        if( fabs(pos[i][j].fy) > 50.0) break;
                        if( fabs(pos[i][j].fz) > 50.0) break;
		}
		if(pos[i][atom_type[0]].ityp!=1) {cout << j << ' ' << pos[i][atom_type[0]].ityp << " bad structure " << endl; continue;}
		npool++;
		fout << "#N " << nions-atom_type[0] << "  1" << endl;
		fout << "#C Fe P " << endl;
                fout << "## force file generated from GA" << endl;
                fout << "#X " << latt[i][0] << endl;
                fout << "#Y " << latt[i][1] << endl;
                fout << "#Z " << latt[i][2] << endl;
                fout << "#W " << 1.0/double(i+1) << endl;
                fout << "#E " << ene[i]/(nions-atom_type[0]) << endl;
                fout << "#S " << stress[i*6+0] << ' ' 
		              << stress[i*6+1] << ' ' 
		              << stress[i*6+2] << ' ' 
		              << stress[i*6+3] << ' ' 
		              << stress[i*6+4] << ' ' 
		              << stress[i*6+5] << ' ' << endl;
                fout << "#F" << endl;
                for (int j = atom_type[0]; j < nions; j++){
                        fout << pos[i][j].ityp%10-1 << ' ' << pos[i][j] << ' ' << pos[i][j].fx << ' ' << pos[i][j].fy << ' '<< pos[i][j].fz << endl;
		}
        }
	cout << "Writing: " << filename << ' ' << npool << endl;
	fout.close();
	return npool;
}

void Write_LAMMPS(char *filename, Posion *latt[],Posion *pos[],double *ene,double *press,int *struc_id, int poolsize,int nions,int ntype){
	int *atom_type;
	atom_type = new int[ntype];
	fstream fout;
       	fout.open(filename,ios::out);
	cout << "Writing: " << filename << ' ' << poolsize << endl;
        for (int i = 0; i < poolsize; i++){
		Get_Type(pos[i],nions,atom_type,ntype);
	       	fout << "Position data for " << struc_id[i] << endl << endl;
		fout << "     " << nions-atom_type[0] << "  atoms" << endl;
		fout << "     " << ntype-1 << "  atom types" << endl;
                fout << 0.0 << "   " << latt[i][0].x << " xlo xhi"<< endl;
                fout << 0.0 << "   " << latt[i][1].y << " ylo yhi"<< endl;
                fout << 0.0 << "   " << latt[i][2].z << " zlo zhi"<< endl;
                fout <<  latt[i][1].x << " " << latt[i][2].x << " " << latt[i][2].y << " xy xz yz"<< endl << endl;
		fout << " Masses" << endl << endl;
                for (int j = 1; j < ntype; j++)
			fout << "   " << j << "  " << 10.0 << endl;
		fout << endl << " Atoms" << endl << endl;
                for (int j = atom_type[0]; j < nions; j++){
                        fout << j-atom_type[0]+1 << ' ' << pos[i][j].ityp << ' ' << pos[i][j] << endl;
		}
        }
	fout.close();
}



void Write_Iso(char *filename, Posion *latt,Posion *pos, int id, int nions,int ntype,int app){
	int *atom_type;
	double a,b,c,alpha,beta,gamma,tol=5e-3;
	double PI = 3.1415926;
	KarDir(latt,pos,nions);
	atom_type = new int[ntype];
	fstream fout;
	fstream fin("./sym.in",ios::in);
	fin >> tol;
	fin.close();
	if(app == 1) fout.open(filename,ios::app|ios::out);
	else fout.open(filename,ios::out);
	fout << "ID: " << id << endl;
	fout << tol << endl;
	Get_Type(pos,nions,atom_type,ntype);
	Get_Cell_Para(latt,a,b,c,alpha,beta,gamma);
	fout << 2 << endl;
	fout << a << ' ' << b << ' ' << c << ' ' << 
	        alpha/PI*180.0 <<  ' ' << beta/PI*180.0 <<  ' '  << gamma/PI*180.0 << endl;
	fout << '2' << endl << "P" << endl << nions - atom_type[0] << endl;
        for (int j = atom_type[0]; j < nions; j++) fout << pos[j].ityp << ' ';
	fout << endl;
        for (int j = atom_type[0]; j < nions; j++) 
       		fout << pos[j] << endl;
	fout.flush();
	fout.close();
	DirKar(latt,pos,nions);
}

void Write_Xdat(Posion *latt[],Posion *pos[], int poolsize,int nions){
        fstream fout("./XDATCAR",ios::out);
        fout << ' ' << nions << ' ' << nions << ' ' << 200 << endl;
	fout << ' ' << Cell_Volume(latt[0])/nions << 
		' ' << latt[0][0].x <<
		' ' << latt[0][1].y <<
		' ' << latt[0][2].z <<
		' ' << 0.5E-15 << endl;
	fout << " 1000.00" << endl;
	fout << "  CAR" << endl;
	fout << " AuSi" << endl << endl;
        for (int i = 0; i < poolsize; i++){
		KarDir(latt[i],pos[i],nions);
                for (int j = 0; j < nions; j++)
                        fout << pos[i][j] << endl;
		fout << endl;
		DirKar(latt[i],pos[i],nions);
        }
	fout.close();
}

void Write_xyz(char *filename,Posion *pos[], double *ene, int poolsize,int nions){
        fstream fout(filename,ios::out);
	int nions_eff;
	cout << "Writing: " << filename << ' ' << poolsize << endl;
        for (int i = 0; i < poolsize; i++){
                for (int j = 0; j < nions; j++)
			if(pos[i][j].ityp !=0) {nions_eff = nions - j; break;}
        	fout << ' ' << nions_eff << endl << "  " << ene[i] << endl;
                for (int j = 0; j < nions; j++)
			switch (pos[i][j].ityp%10) {
				case 1:
                        		fout << "Si  " << pos[i][j] << endl;
					break;
				case 2:
                        		fout << "Au  " << pos[i][j] << endl;
					break;
				case 3:
                        		fout << "Ag  " << pos[i][j] << endl;
					break;
				case 4:
                        		fout << "Fe  " << pos[i][j] << endl;
					break;
				case 5:
                        		fout << "H  " << pos[i][j] << endl;
					break;
				default : break;
			}
        }
	fout.close();
}

void Write_xyz(char *filename,Posion *pos[], double *ene, int poolsize,int nions, double *pos_template,int temp_nions){
        fstream fout(filename,ios::out);
	int nions_eff;
	cout << "Writing: " << filename << ' ' << poolsize << endl;
        for (int i = 0; i < poolsize; i++){
                for (int j = 0; j < nions; j++)
			if(pos[i][j].ityp !=0) {nions_eff = nions - j; break;}
        	fout << ' ' << nions_eff+temp_nions << endl << "  " << ene[i] << endl;
                for (int j = 0; j < nions; j++)
			switch (pos[i][j].ityp%10) {
				case 1:
                        		fout << "Si  " << pos[i][j] << endl;
					break;
				case 2:
                        		fout << "Au  " << pos[i][j] << endl;
					break;
				case 3:
                        		fout << "Ag  " << pos[i][j] << endl;
					break;
				case 4:
                        		fout << "Fe  " << pos[i][j] << endl;
					break;
				case 5:
                        		fout << "H  " << pos[i][j] << endl;
					break;
				default : break;
			}
                for (int j = 0; j < temp_nions; j++)
			switch ((int)pos_template[j*4+3]%10) {
				case 1:
                        		fout << "Si  " << pos_template[4*j+0] << ' ' <<  pos_template[4*j+1] << ' '  << pos_template[4*j+2] << endl;
					break;
				case 2:
                        		fout << "Au  " << pos_template[4*j+0] << ' ' <<  pos_template[4*j+1] << ' '  << pos_template[4*j+2] << endl;
					break;
				case 3:
                        		fout << "Ag  " << pos_template[4*j+0] << ' ' <<  pos_template[4*j+1] << ' '  << pos_template[4*j+2] << endl;
					break;
				case 4:
                        		fout << "Fe  " << pos_template[4*j+0] << ' ' <<  pos_template[4*j+1] << ' '  << pos_template[4*j+2] << endl;
					break;
				case 5:
                        		fout << "H  " << pos_template[4*j+0] << ' ' <<  pos_template[4*j+1] << ' '  << pos_template[4*j+2] << endl;
					break;
				default : break;
			}

        }
	fout.close();
}

void Print_xyz(Posion *pos, double ene, int nions){
	int nions_eff;
        for (int j = 0; j < nions; j++)
		if(pos[j].ityp !=0) {nions_eff = nions - j; break;}
	cout << ' ' << nions_eff << endl << "  " << ene << endl;
        for (int j = 0; j < nions; j++)
		switch (pos[j].ityp) {
			case 1:
                		cout << "Au  " << pos[j] << endl;
				break;
			case 2:
                		cout << "Si  " << pos[j] << endl;
				break;
			case 3:
                		cout << "Ag  " << pos[j] << endl;
				break;
			case 4:
                		cout << "Fe  " << pos[j] << endl;
				break;
			case 5:
                		cout << "H  " << pos[j] << endl;
				break;
			default : break;
		}
}

void Read_Pool(char *filename, Posion *latt[],Posion *pos[],double *ene, double *press, int *struc_id, int &poolsize,int nions,int ntype){
        fstream fin(filename,ios::in);
        int npool_old,itmp;
        int offset;
	int *tmp_type = new int[ntype];
	char str[16];
	double enetmp,presstmp;
	poolsize = 0;
        if(fin) fin >> poolsize >> nions >> itmp;
        for ( int i = 0; i < poolsize; i++){
                latt[i] = new Posion[3];
                pos[i] = new Posion[nions];
	}
        for ( int i = 0; i < poolsize; i++){
		fin >> str;
		fin >> struc_id[i];
		fin >> enetmp;
		fin >> presstmp;
        	for ( int j = 0; j < ntype; j++)
			fin >> tmp_type[j];
                fin >> latt[i][0].x >> latt[i][0].y >> latt[i][0].z ;
                fin >> latt[i][1].x >> latt[i][1].y >> latt[i][1].z ;
                fin >> latt[i][2].x >> latt[i][2].y >> latt[i][2].z ;
		ene[i] = enetmp;
		press[i] = presstmp;
                for (int j = 0; j < nions; j++)
                        fin >> pos[i][j].x >> pos[i][j].y >> pos[i][j].z >> pos[i][j].ityp;
		if(Read_template_head()==0)
                	for (int j = tmp_type[0]+1; j < nions; j++){
		//		pos[i][j].x -= pos[i][tmp_type[0]].x;
		//		pos[i][j].y -= pos[i][tmp_type[0]].y;
		//		pos[i][j].z -= pos[i][tmp_type[0]].z;
;
			}
        }
        fin.close();
        cout << "Read old pool database. Total " << poolsize << "  structures" << endl;
}

void Read_Pool(char *filename, Posion *latt[],Posion *pos[],double *ene,double *press, int *struc_id, int *comp_status,int *atom_type, GAPara ga_info, double *vec_fixedt){
        fstream fin(filename,ios::in);
        int npool_old,itmp;
	int comp_number = ga_info.atom_type_max[1] - ga_info.atom_type_min[1] + 1;
	int sub_NPOOL = ga_info.NPOOL/comp_number;
        int offset,comp_offset;
	int *tmp_type = new int[ga_info.ntype],*fix_comp=new int[comp_number*ga_info.ntype];
	char str[16];
	double enetmp,presstmp;
        fin >> npool_old >> ga_info.nions >> struc_id[ga_info.NPOOL];
#ifdef ONFLY
        if((NPOOL/comp_number)>N_ONFLY) ga_info.NPOOL = comp_number * N_ONFLY;
#endif
        fstream fcomp("./comp.in",ios::in);
        if(fcomp){
                for (int i = 0; i < comp_number; i++) 
                        for (int j = 0; j < ga_info.ntype; j++)
                                fcomp >> fix_comp[i*ga_info.ntype+j];
                cout << " Compositions read! " << endl;
		fcomp.close();
        } else
                for (int i = 0; i < comp_number; i++) 
			fix_comp[i*ga_info.ntype+1] = ga_info.atom_type_min[1]+i;

	for (int i = 0; i < comp_number; i++) comp_status[i]=0;
        for ( int i = 0; i < ga_info.NPOOL; i++){
                latt[i] = new Posion[3];
                pos[i] = new Posion[ga_info.nions];
	}
	if(npool_old > ga_info.NPOOL) npool_old = ga_info.NPOOL;
	//for interface 
	string tmp;
	ifstream readvec("pool_vec.in");
	if(!readvec.is_open() && ga_info.nfixedt != 0 ){
		cout << "Warning: no file named pool_vec.in !" << endl;
		cout << "         Default will be used." << endl;
	}
	else if(ga_info.nfixedt != 0){
		cout << "Reading pool_vec.in .." << endl;
		int nvec;
		readvec>>nvec; getline(readvec, tmp);
		if(nvec<npool_old)cout << "Do not have enough vec's in pool_vec.in!\n\t\tDefault will be used!"<<endl;
		else nvec=npool_old;
		for (int x=0; x < nvec; x++){
			readvec >> tmp >> tmp >> vec_fixedt[x*3] >> vec_fixedt[x*3+1] >> vec_fixedt[x*3+2];
			getline(readvec, tmp);
		}
	}
	readvec.close();
        for ( int i = 0; i < npool_old; i++){
		fin >> str;
		fin >> struc_id[i];
		if(struc_id[i] > struc_id[ga_info.NPOOL]) struc_id[ga_info.NPOOL] = struc_id[i]+1;
		fin >> enetmp;
		fin >> presstmp;
        	for ( int j = 0; j < ga_info.ntype; j++)
			fin >> tmp_type[j];
        	for ( comp_offset = 0; comp_offset < comp_number; comp_offset++)
			if(tmp_type[1] == fix_comp[comp_offset*ga_info.ntype+1]) break;
		if( comp_status[comp_offset] >= sub_NPOOL ){
			fin >> enetmp >> enetmp >> enetmp;
			fin >> enetmp >> enetmp >> enetmp;
			fin >> enetmp >> enetmp >> enetmp;
                	for (int j = 0; j < ga_info.nions; j++)
				fin >> enetmp >> enetmp >> enetmp >> itmp;
			continue;
		}

		offset = sub_NPOOL*comp_offset + comp_status[comp_offset];
		comp_status[comp_offset]++;
                fin >> latt[offset][0].x >> latt[offset][0].y >> latt[offset][0].z ;
                fin >> latt[offset][1].x >> latt[offset][1].y >> latt[offset][1].z ;
                fin >> latt[offset][2].x >> latt[offset][2].y >> latt[offset][2].z ;
		ene[offset] = enetmp;
		press[offset] = presstmp;
        	for ( int j = 0; j < ga_info.ntype; j++)
			atom_type[offset*ga_info.ntype+j] = tmp_type[j];
                for (int j = 0; j < ga_info.nions; j++)
                        fin >> pos[offset][j].x >> pos[offset][j].y >> pos[offset][j].z >> pos[offset][j].ityp;
	        if(Read_template_head() == 0 && Read_site_head() == 0 && ga_info.systype !=2 && ga_info.dimen != 2){
			//translate the first atom to (0 0 0) 
                	for (int j = tmp_type[0]+1; j < ga_info.nions; j++){
				pos[offset][j].x -= pos[offset][tmp_type[0]].x;
				pos[offset][j].y -= pos[offset][tmp_type[0]].y;
				pos[offset][j].z -= pos[offset][tmp_type[0]].z;
			}
			pos[offset][tmp_type[0]].x=pos[offset][tmp_type[0]].y=pos[offset][tmp_type[0]].z=0.0;
		}
//		Adjust_volume(latt[offset], pos[offset], atom_type+offset*ntype,volume,ntype,nions);
        }
        fin.close();
        cout << "Old pool coordination read." << endl;
	cout << "Starting ID read from pool.in = " << struc_id[ga_info.NPOOL] << endl;
	if(ga_info.cur_id > struc_id[ga_info.NPOOL]) struc_id[ga_info.NPOOL] = ga_info.cur_id;
	for(int j = 0; j < comp_number; j++){
		int new_struc =0;
        	for(int k = comp_status[j]; k < sub_NPOOL; k++){
			new_struc = 1;
			offset = sub_NPOOL*j + k;
	               	Init_Structure(latt[offset],pos[offset], atom_type+offset*ga_info.ntype, ga_info, vec_fixedt+k*3);
			double tmpmindis = Check_bond(latt[offset], pos[offset], ga_info.nions);
			if(tmpmindis < ga_info.rcut*0.8) {k--; continue;}
			struc_id[offset] = struc_id[ga_info.NPOOL]++;
			ene[offset] = ENENONE;
			press[offset] = 0.0;
			comp_status[j]++;
			if (new_struc ==1)cout << "New structure generated" << " (comp: " << j+1 << ")"<< endl;
		}
	}
        if(struc_id[0] == struc_id[1]){ // assign struc ID for old version pool.in
        	struc_id[ga_info.NPOOL] = ga_info.cur_id;
                for(int j = 0; j < ga_info.NPOOL; j++) struc_id[j]=struc_id[ga_info.NPOOL]++;
	}        
        cout << "Pool initialization finished." << endl;
}

int Read_Pool_Size(char *filename){
        fstream fin(filename,ios::in);
        int npool=0;
        if(fin) fin >> npool ;
	fin.close();
	return npool;
}

void Read_Force(char *filename,Posion **pos,int poolsize,int nions){
        fstream fin(filename,ios::in);
	for(int i=0; i < poolsize; i++)
		for(int j=0; j < nions; j++)
        		fin >> pos[i][j].fx >> pos[i][j].fy >> pos[i][j].fz;
	fin.close();
}

void Write_Force(char *filename,Posion **pos,int poolsize,int nions){
        fstream fout(filename,ios::out);
	for(int i=0; i < poolsize; i++)
		for(int j=0; j < nions; j++)
        		fout << pos[i][j].fx << ' ' <<  pos[i][j].fy  << ' ' <<  pos[i][j].fz << endl;
	fout.close();
}

void Read_Stress(char *filename,double *stress,int poolsize){
        fstream fin(filename,ios::in);
	for(int i=0; i < poolsize; i++)
		for(int j=0; j < 6; j++)
        	fin >> stress[i*6+j];
	fin.close();
}

void Write_Stress(char *filename,double *stress,int poolsize){
        fstream fout(filename,ios::out);
	for(int i=0; i < poolsize; i++)
        	fout << stress[i*6] << ' '
			<< stress[i*6+1] << ' '
			<< stress[i*6+2] << ' '
			<< stress[i*6+3] << ' '
			<< stress[i*6+4] << ' '
			<< stress[i*6+5] << endl;
	fout.close();
}

void Print_composition(int *atom_type,int ntype){
	for(int jj = 0; jj< ntype; jj++) {
		cout << setw(2) << atom_type[jj] << ' ' ;
	}
	cout  << endl;
}

void Int_Fact(int x, int &a, int &b, int&c){
	int prime[5]={2,3,5,7,11},save;
	a = b = c = 1;
	save = x;
	for(int i = 0; i< 5; i++) 
		if(x%prime[i] == 0){
			a = prime[i];
			x /= a;
			break;
		}
	for(int i = 0; i< 5; i++) 
		if(x%prime[i] == 0){
			b = prime[i];
			x /= b;
			break;
		}
	c = save/a/b;
}

int Pool2poscar(double *latt, double *pos, double *ene, double *pos_fixedt, double *pos_fixedb, double *pos_bufft, double *pos_buffb, 
		double *latt_fixedt, double *latt_fixedb, double *latt_bufft, double *latt_buffb, double *vec_fixedt, GAPara ga_info, int *struc_id, double *latt_template, double *pos_template){

	int atomn[30], nelement;
	int outn, count, new_nions, offset;
	double *lattall, *posall;
	char filename[30];
	int comp_number = ga_info.atom_type_max[1] - ga_info.atom_type_min[1] + 1;
	int sub_poolsize = ga_info.NPOOL / comp_number;

	outn = ga_info.NPOOL_DFT;
	if(ga_info.onfly && ga_info.NPOOL_DFT > ga_info.NPOOL){
		outn = ga_info.NPOOL;
		cout << "Warning: DFT pool size is larger than the classical pool size. Reset." << endl;
	}
	new_nions = ga_info.nions+ga_info.tmpatoms+ga_info.temp_nions;
	lattall = new double[12];
	posall = new double[4*new_nions];
	if(ga_info.alldft){
		outn = ga_info.NPOOL_DFT;
	}

	int suboutn = outn / comp_number;
	count = 1;
	for(int cc=0; cc<comp_number; cc++){
		for(int i=0; i<suboutn; i++){
			if(ga_info.alldft && ene[i]!=ENENONE)continue;
			offset = 4*ga_info.nions*(i + cc*sub_poolsize);
			if(ga_info.systype == 2){
				Merge_interface(pos+offset,pos_fixedt, pos_fixedb, pos_bufft, pos_buffb, posall, latt+(i+cc*sub_poolsize)*12, latt_fixedt, latt_fixedb, latt_bufft, latt_buffb, lattall, vec_fixedt+3*(i+cc*sub_poolsize), ga_info);
			}else{
				Merge_template(pos+offset, pos_template, posall, latt+(i+cc*sub_poolsize)*12, latt_template, lattall, ga_info.nions, ga_info.temp_nions);
/*
				for(int j=0; j<12; j++)
					lattall[j]=latt[(i+cc*sub_poolsize)*12+j];
				for(int j=0; j<4*ga_info.nions; j++)
					posall[j]=pos[offset+j];
*/
			}
        
			for(int j=0; j<30; j++) atomn[j]=0;
			for(int j=0; j<new_nions; j++){
				posall[j*4+3] = int(posall[j*4+3]+0.01)%10;
				atomn[int(posall[j*4+3]+0.01)]++;
			}
			nelement=0;
			for(int j=0; j<30; j++)
				if(atomn[j]!=0)
					nelement=j+1;
        
			sprintf(filename, "./POSCAR_%d", count);
			ofstream poscar(filename);
			//output POSCAR file
			poscar << struc_id[i + cc*sub_poolsize] << endl;
			poscar << "1.0" << endl;
			for(int x=0; x<3; x++)
				poscar<<setiosflags(ios::fixed)<<setprecision(5)<<setw(11)<<lattall[x*4+0]<<"  "<<setw(11)<<lattall[x*4+1]<<"  "<<setw(11)<<lattall[x*4+2]<< endl;
			for(int j=1; j<nelement; j++)
				if(atomn[j]!=0)poscar << " " << atomn[j];
			poscar << endl;
			poscar << "Cartesian" << endl;
			for(int x=1; x<nelement; x++){
				for(int j=0; j<new_nions; j++){
					if(int(posall[j*4+3]+0.01)==x){
						if(ga_info.dimen == 2)
							poscar << "  "<<setw(11)<<posall[j*4]<<"  "<<setw(11)<<posall[j*4+1]<<"  "<<setw(11)<<posall[j*4+2]<< " T T F " << endl;
						else
							poscar << "  "<<setw(11)<<posall[j*4]<<"  "<<setw(11)<<posall[j*4+1]<<"  "<<setw(11)<<posall[j*4+2]<< endl;
					}
				}
			}
			poscar.close();
			count++;
		}
	}
	return count-1;
}
