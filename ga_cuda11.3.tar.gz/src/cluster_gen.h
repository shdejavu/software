#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <math.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <algorithm>
#include <vector>
#include <list>
#include <iomanip>


#include "seqlist.h"
#include "struc_gen.h"
#include "ga.h"
#include "min.h"
#include "randomlib.h"
#include "mpi.h"
#include "dclock.h"
using namespace std;

void Next_Gen_cluster(Posion *latvec[],Posion *pos[],double *ene, int *struc_id, Posion *site, int nsite, int *atom_type, int *comp_status, vector<float> *bondlist, GAPara ga_info);
double Mating_clusters(const Posion *pos1, const Posion *pos2, const Posion *latt1, const Posion *latt2, Posion *newlatt, Posion *newpos, int *atom_type_target, Posion *site, int nsite, GAPara ga_info);
void gather_atoms(Posion *posop, const Posion *pos, Posion *latt, int nions);
void centerofmass(Posion *pos, double *cofm, double nions);
void rot(Posion *pos, Posion *posop, double *cofm, int nions);
void sort(double *z, int *order, int n);
int isgoodmating(int m, int n, Posion *pos1, Posion *pos2, double rcut);
