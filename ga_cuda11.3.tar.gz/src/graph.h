#ifndef GRAPH_H

#define GRAPH_H

#include <stdio.h>
#include <stdlib.h>
#include <iostream>

#include "seqlist.h"

// graph class

class Graph {
  	protected:
    	SeqList<double> *edgelist;     // store edge weight
        SeqList<int>  *adjacentlist; // store neighor list, both in same vertex order
    	POS RowCol (POS, POS);
  	public:
    	int graphsize;
  	//constructor

        ~Graph();
        Graph(void);
    	Graph(const char *);
    	Graph(const int  *,const int);
    	Graph(const Posion *,const int, const double);
    	Graph(const Posion *,Posion &, Posion &, const int, const double);
        // build nearest neighbor
        void Set_Bin(Posion &, Posion &,Posion&, const double);

  	//graph access methods
    	double GetWeight(const int, const int);
    	int IfNeighbor(const int, const int);
	int GetNeighborNumber(const int& );
    	int GetNeighbors(const int, SeqList<int>&);
    	SeqList<int>& Get_2_Neighbors(const int, const int, int&);
    	SeqList<int>& ShortPath(const int, const int, double&);  //use Dijkstra method
    	void ChangeEdgeWeight(const int,const int, double);
        void SortNeighbors();
/*    	void Change(const int& vertex1, const int& vertex2, const int& edge)
    	{
      		edgelist.Change(RowCol(vertex1, vertex2), edge);
      		if ( edge != MAXVALUE) adjacentlist.Change(RowCol(vertex1, vertex2), 1);
    	}

   ostream& operator<<(ostream&, SeqList& l)
    {
    }   */
};

#endif
