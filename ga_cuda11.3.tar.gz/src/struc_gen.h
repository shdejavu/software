#ifndef STRUC_GEN_H

#define STRUC_GEN_H

#include <iostream>

#include "ga.h"
#include "seqlist.h"
#include "interface_gen.h"

void Generate_composition(int*, int*, int*, int,int,int);
void Generate_composition(int, int, int*, int,int,int,int);
void Adjust_composition(const int *, const int *, int *, int, int);
void Convert_structure(Posion **, double *, int , int );
void Convert_structure(const double *, Posion **, int , int );
void Convert_structure(const double *, const double *,Posion **, int , int );
void Init_Structure( Posion *, Posion *, int*, GAPara, double *);
int Init_Cell(Posion *,double,GAPara);
int Read_Database(Posion **,Posion **,int *,int *);

int Read_template_head(); 
int Read_pos_head(); 
int Read_site_head(); 
void Read_template(double *, double *, int); 
void Merge_template(double *,double *,double*,double*,double*,double*,int,int); 
void Remove_template(double *,double*, int);

void Adjust_Structure(Posion *, Posion *, int,int,double);
void Adjust_Atomtype(Posion *, int , int *, int );
void Adjust_volume(Posion *, Posion *, int *,double *,int, int );
void Sort_Type(Posion *, int );
void Get_Type(Posion *, int , int *, int);
void Put_Type(Posion *, int , int *, int);
void Correct_structure(Posion *,Posion *,double &, double&, double *,int , int);
int Within_Box(Posion *,Posion ,Posion );


void DirKar(const Posion *,Posion *,int);
void KarDir(const Posion *,Posion *,int);
void DirKar(const double *,double *,int);
void KarDir(const double *,double *,int);
void Expand_Cell(Posion *, Posion *, Posion *,Posion *,int, int,int, int);

void Align_Structure(Posion *, Posion *, int);
void Align_Cell(Posion *,Posion *,int);
void Mutate_Cell(Posion *,double);
int Gen_Cell(Posion *latt,double ,double ,double ,double ,double ,double);
void Get_Cell_Para(Posion *latt,double &,double& ,double& ,double& ,double& ,double&);
int Extend_Cell(Posion *, Posion *,int, double, double, double);
void Switch_xy(Posion *, int );
void Switch_xz(Posion *, int );
void Switch_yz(Posion *, int );

void Latt_A2B(const Posion *, Posion *);
void Latt_A2B(const double *, double *);
void XPro(Posion, Posion, Posion &);
double Cell_Volume(const Posion *);
double Bond_length(const Posion *,const Posion, const Posion);
void Bond_length(const Posion *,const Posion, const Posion, double *);
double Bond_angle(double,double,double);
void Shuffle_Type(Posion *, int );
void Shuffle_atom(Posion *, int );

void Regen_Structure(Posion *,int);
void Write_Structure(char *, Posion *,Posion *, double,int, int *, int, int ,int);
void Write_Iso(char *, Posion *,Posion *, int, int ,int, int );
void Print_Structure(Posion *,Posion *, int *, int, int );
void Print_xyz(Posion *, double , int );
void Write_Poscar(int , int);
void Print_Structure(const Posion *,Posion *, int );
void Write_Pool(char *,Posion **,Posion **, double *,double *, int *, int ,int,int );
int  Write_Potfit(char *,Posion **,Posion **, double *,double *, int *, int ,int,int );
int  Write_Potfit_Suf(char *,Posion **,Posion **, double *,double *, int *, int ,int,int );
void Write_LAMMPS(char *,Posion **,Posion **, double *,double *, int *, int ,int,int );
void Write_Pool(char *,Posion *,Posion *, double, double, int, int,int );
void Write_Xdat(Posion **,Posion **, int ,int);
void Write_xyz(Posion **,Posion **, double *, int ,int);
void Write_xyz(char *, double *, double *, int ,int );
void Write_xyz(char *, Posion **, double *, int ,int );
void Write_xyz(char *, Posion **, double *, int ,int ,double *, int);
void Read_Pool(char *,Posion **,Posion **, double *, double *,int *, int*, int *, GAPara, double *);
void Read_Pool(char *,Posion **,Posion **, double *, double *,int *, int&, int, int);
int Read_Pool_Size(char *);
void Read_Stress(char*,double*,int);
void Write_Stress(char*,double*,int);
void Read_Force(char*,Posion**,int,int);
void Write_Force(char*,Posion**,int,int);
void Copy_posion(Posion *, Posion *, int);
void Print_composition(int *,int);
void Int_Fact(int,int&,int&,int&);
int Pool2poscar(double*,double*,double*,double*,double*,double*,double*,double*,double*,double*,double*,double*,GAPara,int*, double*, double*);
#endif
