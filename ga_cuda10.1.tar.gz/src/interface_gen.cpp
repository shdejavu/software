#include "interface_gen.h"
using namespace std;

void Read_interface(char *filename, double *latt_t, double *latt_b, double *pos_t, double *pos_b, int nt, int nb){
	int n1, n2;
	string tmp;
	ifstream fin(filename);
	if(!fin.is_open()){
		cout << "Warning: NO file named " << filename << "!\n";
		n1=0; n2=0;
		if(n1!=nt or n2!=nb){
			cout << "# of atoms in " << filename << "does not match with ga.in!" << endl;
			exit(1);
		}
		for(int x=0; x<12; x++){latt_t[x]=latt_b[x]=0;}
		return;
	}
	//top part
	fin >> n1; getline(fin,tmp);
	if(n1!=nt){
		cout << "# of atoms(top) in " << filename << "does not match with ga.in; " << endl;
		cout << "Please check." << endl;
		exit(1);
	}
	if(n1==0){
		cout << "no atoms(top) in " << filename << endl;
		for(int x=0; x<12; x++)latt_t[x]=0;
	}
	else{
		fin >> latt_t[0] >> latt_t[1] >> latt_t[2];  getline(fin,tmp);
		fin >> latt_t[4] >> latt_t[5] >> latt_t[6];  getline(fin,tmp);
		fin >> latt_t[8] >> latt_t[9] >> latt_t[10]; getline(fin,tmp);
		for(int i=0; i<nt; i++){
			fin >> pos_t[i*4+0]
			    >> pos_t[i*4+1]
			    >> pos_t[i*4+2]
			    >> pos_t[i*4+3];
			getline(fin,tmp);
		}
	}
	//bottom part
        fin >> n2; getline(fin,tmp);
        if(n2!=nb){
                cout << "# of atoms(bottom) in " << filename << " does not match with ga.in;" << endl;
                cout << "Please check." << endl;
                exit(1);
        }
	if(n2==0){
                cout << "no atoms(bottom) in " << filename << endl;
		for(int x=0; x<12; x++)latt_b[x]=0;
	}
	else{
	        fin >> latt_b[0] >> latt_b[1] >> latt_b[2];  getline(fin,tmp);
	        fin >> latt_b[4] >> latt_b[5] >> latt_b[6];  getline(fin,tmp);
	        fin >> latt_b[8] >> latt_b[9] >> latt_b[10]; getline(fin,tmp);
	        for(int i=0; i<nb; i++){
	                fin >> pos_b[i*4+0]
	                    >> pos_b[i*4+1]
	                    >> pos_b[i*4+2]
	                    >> pos_b[i*4+3];
	                getline(fin,tmp);
	        }
	}
	fin.close();
}

void Order_interface(double zbufft, double zbuffb, double *pos_fixedt, double *pos_bufft, double *pos_buffb, double *pos_fixedb, double *vec_fixedt, GAPara ga_info){
	ifstream lattin("latt.in");
	cout << "Checking the fixed/buff atoms read from input ..."<< endl;
	if(!lattin.is_open()){
		cout << "\tNO lattice information for the interface region! " << endl;
		exit(1);
	}
	double temp, zlatt, shift, target, z;
	int count;
	string a;
	for(int i=0; i<3; i++)
		getline(lattin, a);
	lattin >> temp >> temp >> zlatt;
	lattin.close();
	//for top fixed atoms
	if(ga_info.nfixedt!=0){
		//check atom's type
		count = 0;
		for(int x=0; x<ga_info.nfixedt; x++)
			if(int(pos_fixedt[x*4+3]+0.01)/20 != 0)count++;
		if(ga_info.movetop && count==0){
			cout << "ERROR: TOP atoms are allowed to move, however, none of them has type > 20!"<< endl;
			exit(1);
		}
		if(ga_info.movetop==0 && count!=0){
			cout << "\tWarning: TOP atoms are not allowed to move, however, some of them has type > 20;"<<endl;
			cout << "\t\tThey will be treated as fixed in the run."<< endl;
		}
		//initialize the vectors
		target = zlatt + zbufft;
		z=get_minz(pos_fixedt, ga_info.nfixedt);
		shift = target + 1.0 - z;
		for(int i=0; i<ga_info.NPOOL; i++)
			vec_fixedt[i*3+2] += shift;
		cout << "\tInitial vector (default) to indicate positions of the fixed (top) atoms = " << endl;
		cout <<setiosflags(ios::fixed)<<setprecision(4)<<"\t\t(";
		cout <<setw(8)<<vec_fixedt[0]<<setw(8)<<vec_fixedt[1]<<setw(8)<<vec_fixedt[2]<<")."<<endl;
	}
	//for top buff atoms
	if(ga_info.nbufft!=0){
		target = zlatt;
		z=get_minz(pos_bufft, ga_info.nbufft);
		shift = target + 1.0 - z;
		for(int i=0; i<ga_info.nbufft; i++)pos_bufft[i*4+2] += shift;
		cout << "\tBuff atoms(top) are shifted "<<shift<<" along z." << endl;
	}
	//for bottom buff atoms
	if(ga_info.nbuffb!=0){
		target = 0;
		z=get_maxz(pos_buffb, ga_info.nbuffb);
		shift = target - ga_info.b_to_i - z;
		for(int i=0; i<ga_info.nbuffb; i++)pos_buffb[i*4+2] += shift;
		cout << "\tBuff atoms(bottom) are shifted "<<shift<<" along z." << endl;
	}
	//for bottom fixed atoms
	if(ga_info.nfixedb!=0){
		target = 0 - zbuffb;
		z=get_maxz(pos_fixedb, ga_info.nfixedb);
		shift = target - ga_info.b_to_i - z;
		for(int i=0; i<ga_info.nfixedb; i++)pos_fixedb[i*4+2] += shift;
		cout << "\tFixed atoms(bottom) are shifted "<<shift<<" along z." << endl;
	}
	cout << "=================================================="<< endl;
}

void Merge_interface(double *pos, double *pos_fixedt, double *pos_fixedb, double *pos_bufft, double *pos_buffb, double *newpos,
                     double *latt, double *latt_fixedt, double *latt_fixedb, double *latt_bufft, double *latt_buffb, double *newlatt,
                     double *vec_fixedt, GAPara ga_info){

	int new_nions = ga_info.nions+ga_info.nfixedt+ga_info.nfixedb+ga_info.nbufft+ga_info.nbuffb;
	//merge atoms
	int i, M, N;
	M = 0;
	N = ga_info.nions;
	for(i=0; i< N*4; i++) newpos[i] = pos[i-M*4];
	M = N;
	N = M + ga_info.nfixedt;
	//considered as a rigid part, add the change relative to the initial positions;
	//if top atoms are fixed, vec_fixedt will be default;
	for(   ; i< N*4; i=i+4){
		newpos[i+0] = pos_fixedt[i+0-M*4]+vec_fixedt[0];
		newpos[i+1] = pos_fixedt[i+1-M*4]+vec_fixedt[1];
		newpos[i+2] = pos_fixedt[i+2-M*4]+vec_fixedt[2];
		newpos[i+3] = pos_fixedt[i+3-M*4];
	}
	M = N;
	N = M + ga_info.nfixedb;
	for(   ; i< N*4; i++) newpos[i] = pos_fixedb[i-M*4];
        M = N;
        N = M + ga_info.nbufft;
        for(   ; i< N*4; i++) newpos[i] = pos_bufft[i-M*4];
        M = N;
        N = M + ga_info.nbuffb;
        for(   ; i< N*4; i++) newpos[i] = pos_buffb[i-M*4];

	//determine the new lattice
	//a, b
	for(int i=0; i<12; i++)newlatt[i] = latt_fixedb[i];
	//c, assume it's along z direction
	newlatt[10] = latt_fixedb[10]+latt_buffb[10]+latt[10]+latt_bufft[10]+latt_fixedt[10];
	//add vacuum
	newlatt[10] = newlatt[10]+ga_info.vacuum;
}

//return the min(z of the top atoms)
double Split_interface(double *posall, double *pos_fixedt, double *pos_fixedb, double *pos_bufft, double *pos_buffb, double *pos,
                     double *latt, double *latt_bufft, double *latt_buffb, double latt_fixedbz, double *vec_fixedt, GAPara ga_info){

	int i, M, N;
	double mintopz;
	M = 0;
	N = ga_info.nions;
	for(i=0; i<N*4; i++) pos[i] = posall[i];

	M = N + ga_info.nfixedt +ga_info.nfixedb;
	N = M + ga_info.nbufft;
	for(i=M*4; i< N*4; i++) pos_bufft[i-M*4] = posall[i];
	M = N;
	N = M + ga_info.nbuffb;
	for(     ; i< N*4; i++) pos_buffb[i-M*4] = posall[i];

	//determine the new lattice for interface and buff region
	latt[10] = get_maxz(pos, ga_info.nions) + ga_info.rcut;

	if(ga_info.nbuffb!=0)latt_buffb[10] = get_maxdiffz(pos_buffb, ga_info.nbuffb)+ga_info.rcut;
	if(ga_info.nbufft!=0)latt_bufft[10] = get_maxdiffz(pos_bufft, ga_info.nbufft)+ga_info.rcut;

	//for the top fixed atoms, just need the new vector to store its movement
	if(ga_info.nfixedt!=0 && ga_info.movetop){
		vec_fixedt[0]=posall[ga_info.nions*4+0]-pos_fixedt[0];
		vec_fixedt[1]=posall[ga_info.nions*4+1]-pos_fixedt[1];
		vec_fixedt[2]=posall[ga_info.nions*4+2]-pos_fixedt[2];
		mintopz=get_minz(pos_fixedt, ga_info.nfixedt)+vec_fixedt[2];
		
	}
	return mintopz;
}

double get_maxdiffz(const double *pos, int n){
	if(n==0) return 0;
	double disz, maxz;
	maxz = 0;
	for(int i=0; i<n; i++){
		for(int j=i; j<n; j++){
			disz = fabs(pos[i*4+2]-pos[j*4+2]);
			if(disz>maxz) maxz = disz;
		}
	}
	return maxz;
}

double get_maxz(const double *pos, int n){
	if(n==0) return -9999.0;
	double temp, maxz;
	maxz = -9999.0;
	for(int i=0; i<n; i++){
		if(maxz<pos[i*4+2]) maxz = pos[i*4+2];
	}
	return maxz;
}

double get_minz(const double *pos, int n){
	if(n==0) return 9999.0;
	double temp, minz;
	minz = +9999.0;
	for(int i=0; i<n; i++){
		if(minz>pos[i*4+2]) minz = pos[i*4+2];
	}
	return minz;
}

void Next_Gen_interface(Posion *latvec[],Posion *pos[],double *ene, int *struc_id, Posion *site, int nsite, int *atom_type, int *comp_status, vector<float> *bondlist,
                        double *vec_fixedt, GAPara ga_info){
  int tmp_type[10], offset, comp_offset;
  float ave_mating_p=0.0, mating_p=0.0;
  int comp_number = ga_info.atom_type_max[1] - ga_info.atom_type_min[1] + 1;
  int sub_poolsize = ga_info.NPOOL / comp_number;
  double vputim_0,cputim_0,vputim,cputim;
  Posion **posnew = new Posion*[2];
  Posion **latt_new = new Posion*[2];
  posnew[0]=new Posion[ga_info.nions]; latt_new[0]= new Posion[3];
  posnew[1]=new Posion[ga_info.nions]; latt_new[1]= new Posion[3];

  cout << "Mating interface ..." << endl;
  for(int j = 0; j < comp_number; j++){
    for(int k=sub_poolsize/4*3; k<sub_poolsize; k++){
      offset = sub_poolsize*j + k;
      int m, n, compm, compn;

      compm = RandomInt(0,comp_number-1);
      compn = RandomInt(0,comp_number-1);

      while(1){
        m = fabs(RandomGaussian(0,sub_poolsize/2));
        n = fabs(RandomGaussian(0,sub_poolsize/2));
        if(m < n&&n<sub_poolsize){
          m = m+compm*sub_poolsize;
          n = n+compn*sub_poolsize;
          if(ene[m]!=9999.0 && ene[n]!=9999.0) break;
        }
      };
//    cout << "structure # " << m << " & " << n << " are selected ..." << endl;
      if(ga_info.atom_type_max[0] != 0){
        atom_type[offset*ga_info.ntype] = atom_type[offset*ga_info.ntype+1];
        for(int kk = 2; kk < ga_info.ntype; kk++){
          atom_type[offset*ga_info.ntype+kk] = RandomInt(ga_info.atom_type_min[kk],ga_info.atom_type_max[kk]);
          atom_type[offset*ga_info.ntype] +=atom_type[offset*ga_info.ntype+kk];
        }
        atom_type[offset*ga_info.ntype] = ga_info.nions-atom_type[offset*ga_info.ntype];
      }
      //Mating 
      mating_p = Mating_interface(pos[m], pos[n], latvec[m], latvec[n], latt_new, posnew, atom_type+offset*ga_info.ntype, site,nsite,ga_info);

      if(mating_p == 0.0 || mating_p == 1.0) {k--;continue;} //remate

      ave_mating_p += mating_p;
      int l = 0;
      Get_Type(posnew[l],ga_info.nions,tmp_type,ga_info.ntype);
      comp_status[j]++;
      if(ga_info.dimen==3)
        Adjust_volume(latt_new[l], posnew[l], atom_type+offset*ga_info.ntype,ga_info.vol,ga_info.ntype,ga_info.nions);
      Copy_posion(posnew[l],pos[offset],ga_info.nions);
      Copy_posion(latt_new[l],latvec[offset],3);
      ene[offset] = ENENONE;
      struc_id[offset] = struc_id[ga_info.NPOOL]++;
      bondlist[offset].clear();

      //determine the change of the fixed atoms(top) of the new structure
      if(mating_p > 0.5){
        for(int x=0; x<2; x++)vec_fixedt[k*3+x] = vec_fixedt[m*3+x];
      }else{
        for(int x=0; x<2; x++)vec_fixedt[k*3+x] = vec_fixedt[n*3+x];
      }
      //in z direction
      if(vec_fixedt[m*3+2]>vec_fixedt[n*3+2]) vec_fixedt[k*3+2] = vec_fixedt[m*3+2];
      else vec_fixedt[k*3+2] = vec_fixedt[n*3+2];
      //buff atoms

    }
  }
  cout << "Mating completed, average mating percentage: " << ave_mating_p/(comp_number*sub_poolsize/4)<< endl;
  for(int j = 0; j < comp_number; j++){
    for(int k = comp_status[j]; k < sub_poolsize; k++){
      offset = sub_poolsize*j + k;
      Init_Structure(latvec[offset],pos[offset], atom_type+offset*ga_info.ntype, ga_info, vec_fixedt+k*3);
      ene[offset] = ENENONE;
      struc_id[offset] = struc_id[ga_info.NPOOL]++;
      comp_status[j]++;
      bondlist[offset].clear();
      cout << "New structure generated" << endl;
    }
  }
  for(int x=0; x<2; x++){delete[] latt_new[x]; delete[] posnew[x];}
}

//for interface Mating
//based on Mating2()
double Mating_interface(const Posion *pos1, const Posion *pos2, const Posion *latt1, const Posion *latt2, Posion *newlatt[],Posion *newstruc[], 
	      int *atom_type_target, Posion *site,int nsite,GAPara ga_info){
        int i,j,nions=ga_info.nions;
        Posion slice_dir,shift_atom;
        Posion plane_1, plane_2;
	Posion slab_1[2],slab_2[2];
	Posion *postmp1, *postmp2;
	Posion **posdbg;
        double vputim_0,cputim_0,vputim,cputim;
        double a[3],center,width,d,mating_p,mating_width;
        int *inout_1,*inout_2,nin_1,nin_2;
	int *tmp_type = new int[ga_info.ntype];
	postmp1 = new Posion[nions];
	postmp2 = new Posion[nions];
	posdbg = new Posion*[2];
	posdbg[0] = new Posion[nions];
	posdbg[1] = new Posion[nions];
        for (i = 0; i < nions; i++){
		postmp1[i] = pos1[i];
		postmp2[i] = pos2[i]; 
	}
// Lattice mating
	KarDir(latt1,postmp1,nions); KarDir(latt2,postmp2,nions);
	DirKar(latt1,postmp1,nions); DirKar(latt2,postmp2,nions);
	double rcut_new = Check_bond(latt1,postmp1,nions);
	mating_width = rcut_new*2.5;
	rcut_new*=0.6;
	KarDir(latt1,postmp1,nions); KarDir(latt2,postmp2,nions);
	newlatt[0][0]   = (latt1[0] + latt2[0]) / 2;
	newlatt[0][1]   = (latt1[1] + latt2[1]) / 2;
	newlatt[0][2]   = (latt1[2] + latt2[2]) / 2;
	newlatt[1][0] = (latt1[0] + latt2[0]) / 2;
	newlatt[1][1] = (latt1[1] + latt2[1]) / 2;
	newlatt[1][2] = (latt1[2] + latt2[2]) / 2;
	
        inout_1=new int[nions];
        inout_2=new int[nions];

	int which_plane= 0;
        for (i = 0; i < 3; i++)
		a[i]=sqrt(newlatt[0][i].x*newlatt[0][i].x
			 +newlatt[0][i].y*newlatt[0][i].y
		         +newlatt[0][i].z*newlatt[0][i].z);
	double randomx = RandomDouble(0.0, 1.0);
	if(randomx < 0.2){
		if(a[0]>a[1]&&a[0]>a[2]) which_plane=0;
		else if(a[1]>a[0]&&a[1]>a[2]) which_plane=1;
		else which_plane=2;
	}
	else{
		if(a[0]>a[1]) which_plane=0;
		else which_plane=1;
	}
//	cout << "Which plane = " << which_plane << endl;

// determine slice plane direction;        
	mating_width /= a[which_plane]; 
        for (i = 0; i < 2; i=i+2){
// set mating slab
// choose slab direction and width

	        center = RandomDouble(0.0,1.0);
		width  = RandomDouble(0.125,0.4);

	        // plane_1 is center slice + slicewidth, plane_2 is -.
       	 	//width = (center.x+center.y+center.z)/3;
		nin_1=nin_2=0;
                for (j = 0; j < nions; j++){
			newstruc[i][j].x=newstruc[i][j].y=newstruc[i][j].z=newstruc[i][j].ityp = 0;
			newstruc[i+1][j].x=newstruc[i+1][j].y=newstruc[i+1][j].z=newstruc[i+1][j].ityp = 0;
			inout_1[j] = Within_Planes(postmp1[j],center, width, which_plane);
			if(postmp1[j].ityp > 10) inout_1[j]=1;
			nin_1+=inout_1[j];

			inout_2[j] = Within_Planes(postmp2[j],center, width, which_plane);
			if(postmp2[j].ityp > 10) inout_2[j]=1;
			nin_2+=inout_2[j]; 
                }
                int child_1=0,child_2=0; // child atoms generation counting
		// Swap atoms
		mating_p = double(nin_1)/double(nions);
		for (j = nions-1; j >= 0; j--){
                     	if ( inout_1[j]==0 ) {
     				if (child_1 < nions && postmp1[j].ityp != 0){
                             		newstruc[i][child_1]=postmp1[j];
                             		child_1++;
     				}
                     	} else {
     				if (child_2 < nions && postmp1[j].ityp != 0){
                             		newstruc[i+1][child_2]=postmp1[j];
                             		child_2++;
     				}
                     	}
                     	if ( inout_2[j]==1 ) {
     				if (child_1 < nions && postmp2[j].ityp != 0){
                             		newstruc[i][child_1]=postmp2[j];
                       		      	child_1++;
     				}
                     	} else {
     				if (child_2 < nions && postmp2[j].ityp != 0){
                             		newstruc[i+1][child_2]=postmp2[j];
                             		child_2++;
     				}
                     	}
             	}

		double enetmp[2];


        	DirKar(newlatt[i],newstruc[i],nions);
        	KarDir(newlatt[i],newstruc[i],nions);
		Sort_Type(newstruc[i],nions);
		Get_Type(newstruc[i],nions,tmp_type,ga_info.ntype);
		int one_fix=0;
		// looking for atom at origin
		for (j = 0; j < nions; j++)
			if(newstruc[i][j].x == 0.0 && newstruc[i][j].y == 0.0 && newstruc[i][j].z == 0.0 &&
			   newstruc[i][j].ityp == 1 ){
				one_fix = 1;
				newstruc[i][j] = newstruc[i][tmp_type[0]];
				newstruc[i][tmp_type[0]].x=newstruc[i][tmp_type[0]].y=newstruc[i][tmp_type[0]].z=0;
				if(newstruc[i][tmp_type[0]].ityp>10) cout << "*" << endl;
				newstruc[i][tmp_type[0]].ityp = 0;
				tmp_type[0]++;
				tmp_type[1]--;
				atom_type_target[1]--;
				break;
			}

		// adjust structure by type switch
		// choose in slabs
		int undefined = 0;

		for (j = tmp_type[0]; j < nions; j++){
			if( (Within_Planes(newstruc[i][j],center-width,mating_width,which_plane)  ||
			     Within_Planes(newstruc[i][j],center+width,mating_width,which_plane)) &&
			     tmp_type[newstruc[i][j].ityp%10] > atom_type_target[newstruc[i][j].ityp%10]&&
			     newstruc[i][j].ityp < 10 ) {
				tmp_type[newstruc[i][j].ityp]--;
				undefined++;
				if(newstruc[i][j].ityp>10) cout << "***" << endl;
				newstruc[i][j].ityp = 999;
			}
		}
		// choose outside of slabs
		Shuffle_atom(newstruc[i],nions);
		Sort_Type(newstruc[i],nions);
		for (j = tmp_type[0]; j < nions - undefined; j++){
			if( tmp_type[newstruc[i][j].ityp%10] > atom_type_target[newstruc[i][j].ityp%10] && newstruc[i][j].ityp < 10 ) {
				tmp_type[newstruc[i][j].ityp]--;
				if(newstruc[i][j].ityp>10) cout << "*****" << endl;
				newstruc[i][j].ityp = 999;
			}
		}
		// switch
		for (j = tmp_type[0]; j < nions; j++){
			if(newstruc[i][j].ityp == 999) {
				for (int k = 1; k < ga_info.ntype; k++){
					if(tmp_type[k] < atom_type_target[k] ){
						tmp_type[k]++;
						newstruc[i][j].ityp = k;
					}
				}
			}
		}
		for (j = tmp_type[0]; j < nions; j++)
			if(newstruc[i][j].ityp == 999) 
				newstruc[i][j].x=newstruc[i][j].y=newstruc[i][j].z=newstruc[i][j].ityp = 0;

		// adjust structure by adding new atom in slabs.
		Posion add_atom;
		Sort_Type(newstruc[i],nions);
		Get_Type(newstruc[i],nions,tmp_type,ga_info.ntype);

		int insert_ok = 0;
		for (j = 1; j < ga_info.ntype; j++) {
                        int accept = 1;
			if(tmp_type[j] < atom_type_target[j] ){
                                while(accept&&accept<1000){
                                        add_atom.x=RandomDouble(0,1);
                                        add_atom.y=RandomDouble(0,1);
                                        add_atom.z=(ga_info.dimen==3?RandomDouble(0,1):0.0);
					if(nsite != 0) add_atom = site[RandomInt(1,nsite)-1];
					add_atom.ityp = j;
                                        int k;
                                        for (k = 0; k < nions; k++) 
                                                if(Bond_length(newlatt[i],newstruc[i][k],add_atom) < rcut_new ){
							accept++;break;
						}
                                        if (k==nions) 
						if( Within_Planes(add_atom,center-width, mating_width, which_plane) ||
						    Within_Planes(add_atom,center+width, mating_width, which_plane)) {
							accept = 0;
							newstruc[i][tmp_type[0]-1].x = add_atom.x;
							newstruc[i][tmp_type[0]-1].y = add_atom.y;
							newstruc[i][tmp_type[0]-1].z = add_atom.z;
							newstruc[i][tmp_type[0]-1].ityp = j;
							if(newstruc[i][tmp_type[0]-1].ityp>10) cout << "******************" << endl;
							tmp_type[0]--;
							tmp_type[j]++;
						} else accept++;
                                }
				j--;
			}
			if(accept>=100) {insert_ok=1;break;}
		}

		if(one_fix == 1) {
			newstruc[i][tmp_type[0]-1].ityp = 1;
			atom_type_target[1]++;
		}
		if(insert_ok){rcut_new*=0.99;i-=2;continue;};
		Sort_Type(newstruc[i],nions);
		Get_Type(newstruc[i],nions,tmp_type,ga_info.ntype);
        	DirKar(newlatt[i],newstruc[i],nions);
        }
	delete[] postmp1;
	delete[] postmp2;
	delete[] inout_1;
	delete[] inout_2;
	return mating_p;
}

void Write_Vec(char *filename, double *vec, int *struc_id, int nfixedt, int poolsize){
	if(nfixedt == 0) return;
	ofstream fout(filename);
	fout << poolsize << endl;
	for(int i=0; i<poolsize; i++){
		fout << "ID: " << struc_id[i];
		fout << setiosflags(ios::fixed) << setprecision(4) << setw(11) << vec[i*3] << " " << setw(11) << vec[i*3+1] << " " << setw(11) << vec[i*3+2] << endl;
	}
	fout.flush();
	fout.close();
}

