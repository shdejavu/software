#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <math.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <algorithm>
#include <vector>
#include <list>
#include <iomanip>


#include "seqlist.h"
#include "struc_gen.h"
#include "ga.h"
#include "randomlib.h"

void Read_interface(char*, double*, double*, double*, double*, int, int);
void Order_interface(double, double, double *, double *, double *, double *, double *, GAPara);
void Merge_interface(double*,double*,double*,double*,double*,double*,
                     double*,double*,double*,double*,double*,double*,
                     double*,GAPara );
double Split_interface(double*,double*,double*,double*,double*,double*,
                     double*,double*,double*,double, double*,GAPara);
double get_maxdiffz(const double*, int);
double get_minz(const double*, int);
double get_maxz(const double*, int);

void Next_Gen_interface(Posion **,Posion **,double *, int *, Posion *, int, int *, int *, vector<float> *, double *, GAPara );

double Mating_interface(const Posion *, const Posion *, const Posion *, const Posion *, Posion **, Posion **, int *, Posion *, int, GAPara );
void Write_Vec(char*, double *, int *, int, int);

