#ifndef SEQLIST_H

#define SEQLIST_H

#include <stdio.h>
#include <stdlib.h>
#include <iostream>

using namespace std;

typedef int POS;
const int MAXSIZE = 20000000;
const int MAXVALUE = 9999999;
const int DEFAULTSIZE = 24;

struct Posion{
    double x,y,z;
    double fx,fy,fz;
    int ityp;
};

void Pause(void);

void Debug(double info);

void int_to_str(int, char *,int);



Posion operator+(Posion pos1,Posion pos2);
Posion operator-(Posion pos1,Posion pos2);
Posion operator*(Posion pos1,Posion pos2);
Posion operator*(Posion pos1,double c);
Posion operator/(Posion pos1,double c);
Posion operator+(Posion pos1,double c);
Posion operator-(Posion pos1,double c);
void DirKar(Posion *,Posion &);

ostream &operator<<(ostream &stream, Posion pos);
istream &operator>>(istream &stream, Posion pos);

// class SeqList declaration
// Basic Array Operation
template <class Type> class SeqList {
  private:
    Type *itemlist;
    int maxsize, cursize, curpos;
  public:
  //constructer
    SeqList(void);
    SeqList(int);
    SeqList(const SeqList<Type>&);
  //destructor
    ~SeqList(void);
  //list operation methods
    void Insert(const Type);
    void Insert(const Type*, int, int);
    void Insert(SeqList<Type>&, int);
    void Delete(const Type);
    POS Find (Type);
    Type Get (void);
    Type Get (POS);
    void Swap (POS,POS);
    void Change (POS, const Type);
    void Resize (int);
    void EmptyList();
    void Rewind(){curpos = 0;}
    int GetSize ()const;
    int GetMaxSize ()const;
    bool Full()const;
    void Cut(POS pos);
    void Sort();
    Type operator[](const int&);
    SeqList<Type>& operator=(const SeqList<Type>&);
};

template <class Type> ostream &operator<<(ostream &stream,SeqList<Type>& );

template <class Type> SeqList<Type>& SeqList<Type>::operator=(const SeqList<Type>& orig){
        maxsize = orig.maxsize;
        cursize = orig.cursize;
        curpos  = orig.curpos;
        itemlist =  new Type [maxsize];
   	for ( int i = 0; i < cursize; i++) itemlist[i] = orig.itemlist[i];
        return *this;
}
template <class Type> SeqList<Type>::SeqList(void)
 : maxsize(DEFAULTSIZE), cursize(0), curpos(0) {
	itemlist = new Type[ DEFAULTSIZE ];
   	for ( int i = 0; i < DEFAULTSIZE; i++)
    	itemlist[i] = MAXVALUE;
}

template <class Type> SeqList<Type>::SeqList( int size )
 : maxsize(size ), cursize(0), curpos(0) {
  itemlist =  new Type [ size ];
   	for ( int i = 0; i < size; i++) itemlist[i] = -1;
}

template <class Type> SeqList<Type>::SeqList(const SeqList<Type>& orig)
 : maxsize(orig.maxsize), cursize(orig.cursize), curpos(orig.curpos) {
        itemlist =  new Type [maxsize];
   	for ( int i = 0; i < cursize; i++) itemlist[i] = orig.itemlist[i];
}

template <class Type> SeqList<Type>::~SeqList(void){
        delete itemlist;
}

template <class Type> void SeqList<Type>::Insert(const Type item) {
  if ( cursize != maxsize ) {
    itemlist[ cursize ] = item;
    cursize++;
  }
  else {
    cerr << "list is full" << " " << cursize <<endl;
    exit(0);
  }
}

template <class Type> void SeqList<Type>::Insert(const Type *item, int positem, int size) {
	int pos = Find(positem), c1;
	if ( pos == 0 )
		pos == cursize;
	if( size + cursize > maxsize )
		for (c1 = 0; c1 < maxsize - pos - size;c1++)
			itemlist[pos + size + c1] = itemlist[pos + c1];
	else
		for (c1 = 0; c1 <cursize - pos; c1++)
			itemlist[pos + size + c1] = itemlist[pos + c1];
	for ( c1 = 0; c1 < size; c1++)
		itemlist[pos + c1] = item[c1];
    cursize += size;
}

template <class Type> void SeqList<Type>::Insert(SeqList<Type>& item, int positem) {
	int pos = Find(positem), c1, size = (int)item.GetSize();
	if ( pos == 0 )
		pos = cursize;
    else
    	pos--;
	if( size + cursize > maxsize )
    	Resize(size + cursize);
    for (c1 = 0; c1 <cursize - pos; c1++)
    	itemlist[pos + size + c1] = itemlist[pos + c1];
	for ( c1 = 0; c1 < size; c1++)
		itemlist[pos + c1] = item[c1];
    cursize += size;
}

template <class Type> void SeqList<Type>::Delete(const Type item) {
	int i;
        i = Find(item);
        if ( i == 0) return;
        for ( int j = i - 1; j < cursize ; j++) itemlist[j] = itemlist[j + 1];
  	if ( curpos >= i ) curpos--;
  	cursize--;
}

template <class Type> POS SeqList<Type>::Find(const Type item) {
  	POS pos;
  	for ( pos = 0; pos < cursize; pos++)
    	if ( itemlist[ pos ] == item ) return pos + 1;
  	return 0;
}

template <class Type> Type SeqList<Type>::Get(void) {
  if (curpos >= cursize)
    return -1;
  return itemlist[curpos++];
}

template <class Type> void SeqList<Type>::Swap( POS pos1,POS pos2 ) {
        Type tmp;
        if ( pos1 > cursize || pos1 <= 0) return ;
        if ( pos2 > cursize || pos2 <= 0) return ;
        tmp = itemlist[pos1-1];
        itemlist[pos1-1] = itemlist[pos2-1];
        itemlist[pos2-1] = tmp;
}

template <class Type> Type SeqList<Type>::Get( POS pos ) {
  if ( pos > cursize || pos <= 0) return MAXVALUE;
  return itemlist [pos - 1];
}

template <class Type> void SeqList<Type>::Change ( POS pos, const Type item ) {
  if ( pos > maxsize ) return ;
  if ( pos > cursize) cursize = pos;
  itemlist[pos - 1] = item;
}

template <class Type> void SeqList<Type>::Resize( int newsize ) {
  if ( newsize <= maxsize ) return;
  Type *templist = itemlist;
  itemlist = new Type[ newsize ];
  for ( int i = 0; i < cursize; i++)
    itemlist [ i ] = templist [ i ];
  maxsize = newsize ;
  delete templist;
}

template <class Type>void SeqList<Type>::EmptyList() {
//	for (int i = 0; i < cursize; i++)
//    	itemlist[i] = 0;
  	cursize = curpos = 0;
}

template <class Type> int SeqList<Type>::GetSize ()const {
	return cursize;
}

template <class Type> int SeqList<Type>::GetMaxSize ()const {
	return maxsize;
}

template <class Type> bool SeqList<Type>::Full() const {
    if (cursize == maxsize) return true;
    else return false;
}

template <class Type> void SeqList<Type>::Cut(POS pos) {
	Rewind();
	if (pos >= cursize) return;
    else cursize = pos - 1;
}

template <class Type> Type SeqList<Type>::operator[](const int& pos) {
  if ( pos >= cursize )
    return -1;
  return itemlist [pos];
}

template <class Type> void SeqList<Type>::Sort(){
        for (int j = 0; j < cursize; j++)
                for (int k = 0; k < cursize-j-1; k++)
                        if (itemlist[k] > itemlist[k+1]) {
                               Swap(k+1,k+2);
                       }
}

// end of SeqList declaration

template <class Type> ostream &operator<<(ostream &stream,SeqList<Type> &list ){
        int i,size=list.GetSize();
        for (i=0;i<size;i++)
                cout << list[i] << ' ';
        cout << endl;
        return stream;
}

#endif
