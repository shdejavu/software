#include "cluster_gen.h"
using namespace std;

void Next_Gen_cluster(Posion *latvec[],Posion *pos[],double *ene, int *struc_id, Posion *site, int nsite, int *atom_type, int *comp_status, vector<float> *bondlist, GAPara ga_info){
  int tmp_type[10], offset, comp_offset;
  float ave_mating_p=0.0, mating_p=0.0;
  int comp_number = ga_info.atom_type_max[1] - ga_info.atom_type_min[1] + 1;
  int sub_poolsize = ga_info.NPOOL / comp_number;
  double vputim_0,cputim_0,vputim,cputim;
  Posion *posnew, *latt_new;
  posnew=new Posion[ga_info.nions];
  latt_new= new Posion[3];

  cout << "Mating clusters ..." << endl;
  for(int j = 0; j < comp_number; j++){
    for(int k=sub_poolsize/4*3; k<sub_poolsize; k++){
      offset = sub_poolsize*j + k;
      int m, n, compm, compn;

      compm = RandomInt(0,comp_number-1);
      compn = RandomInt(0,comp_number-1);

      while(1){
        m = fabs(RandomGaussian(0,sub_poolsize/3));
        n = fabs(RandomGaussian(0,sub_poolsize/3));
        if(m < n&&n<sub_poolsize){
          m = m+compm*sub_poolsize;
          n = n+compn*sub_poolsize;
          if(ene[m]!=9999.0 && ene[n]!=9999.0) break;
        }
      };
      //cout << "structure # " << m << " & " << n << " are selected ..." << endl;
      if(ga_info.atom_type_max[0] != 0){
        atom_type[offset*ga_info.ntype] = atom_type[offset*ga_info.ntype+1];
        for(int kk = 2; kk < ga_info.ntype; kk++){
          atom_type[offset*ga_info.ntype+kk] = RandomInt(ga_info.atom_type_min[kk],ga_info.atom_type_max[kk]);
          atom_type[offset*ga_info.ntype] +=atom_type[offset*ga_info.ntype+kk];
        }
        atom_type[offset*ga_info.ntype] = ga_info.nions-atom_type[offset*ga_info.ntype];
      }
      //'site', 'nsite' are for fixing sites, to be used 
      mating_p = Mating_clusters(pos[m], pos[n], latvec[m], latvec[n], latt_new, posnew, atom_type+offset*ga_info.ntype, site,nsite,ga_info);
      //remate
      if(mating_p<0) {k--; continue;}
      double tmpmindis = Check_bond(latt_new, posnew, ga_info.nions);
      if(tmpmindis < ga_info.rcut*0.75) {k--; continue;}

      ave_mating_p += mating_p;

      Get_Type(posnew,ga_info.nions,tmp_type,ga_info.ntype);
      comp_status[j]++;
      if(ga_info.dimen==0)
        Adjust_volume(latt_new, posnew, atom_type+offset*ga_info.ntype,ga_info.vol,ga_info.ntype,ga_info.nions);
      Copy_posion(posnew,pos[offset],ga_info.nions);
      Copy_posion(latt_new,latvec[offset],3);
      ene[offset] = ENENONE;
      struc_id[offset] = struc_id[ga_info.NPOOL]++;
      bondlist[offset].clear();
    }
  }
  cout << "Mating completed, average mating percentage: " << ave_mating_p/(comp_number*sub_poolsize/4)<< endl;
  for(int j = 0; j < comp_number; j++){
    for(int k = comp_status[j]; k < sub_poolsize; k++){
      offset = sub_poolsize*j + k;
      double x[3];
      Init_Structure(latvec[offset],pos[offset], atom_type+offset*ga_info.ntype, ga_info, x);
      ene[offset] = ENENONE;
      struc_id[offset] = struc_id[ga_info.NPOOL]++;
      comp_status[j]++;
      bondlist[offset].clear();
      cout << "New structure generated" << endl;
    }
  }
  delete[] posnew;
  delete[] latt_new;
}


//Mating operation for clusters
double Mating_clusters(const Posion *pos1, const Posion *pos2, const Posion *latt1, const Posion *latt2,
                       Posion *newlatt, Posion *newpos, int *atom_type_target, Posion *site, int nsite, GAPara ga_info){
  int nions=ga_info.nions;
  int atomn_1, atomn_2, m, n;
  int judge;
  double cofm1[3], cofm2[3];
  double mating_p;
  double *posz1, *posz2;
  int *ratio_t, *order1, *order2;
  Posion *postmp1, *postmp2;
  Posion *posop1, *posop2, *posrot1, *posrot2;
  postmp1 = new Posion[nions];
  postmp2 = new Posion[nions];
  posop1  = new Posion[nions];
  posop2  = new Posion[nions];
  posrot1  = new Posion[nions];
  posrot2  = new Posion[nions];
  posz1 = new double[nions];
  posz2 = new double[nions];
  ratio_t = new int[ga_info.ntype];
  order1  = new int[nions];
  order2  = new int[nions];

  //copy the lattice vectors
  //assume that lattices are the same for str1 and str2
  for(int i=0; i<3; i++)
    newlatt[i] = latt1[i];

  //gather the atoms together --> posop1 & posop2
  gather_atoms(posop1, pos1, newlatt, nions);
  gather_atoms(posop2, pos2, newlatt, nions);
  //calculate the center of mass
  centerofmass(posop1, &cofm1[0], ga_info.nions);
  centerofmass(posop2, &cofm2[0], ga_info.nions);

  int trial=0;
  do{

    //random rotation
    rot(posop1, posrot1, cofm1, ga_info.nions);
    rot(posop2, posrot2, cofm2, ga_info.nions);

    //move different types of atoms far away from eath other 
    for (int i = 0; i < nions; i++){
        posz1[i] = posrot1[i].z + (posrot1[i].ityp-1)*100000.0;
        posz2[i] = posrot2[i].z + (posrot2[i].ityp-1)*100000.0;
    }
 
    //sort the parents by coordinate z
    sort(posz1, &order1[0], nions);
    sort(posz2, &order2[0], nions);

    //determine the ratio from both parents
    //e.g. mating_p = 0.4 --> cut 40% from structure #1 (bottom), 60% from structure #2 (top)
    //here, mating_p is between [0.25, 0.75]
    mating_p = RandomDouble(0.0, 1.0);
    mating_p = mating_p*0.5+0.25;
    if(mating_p<0.5) mating_p = 1-mating_p;   //always choose bigger part from str#1, since it has lower energy
    atomn_1=0;
    for(int j=0; j<ga_info.ntype; j++){
      ratio_t[j] = int(mating_p*ga_info.atom_type_max[j]+0.5);
      atomn_1+=ratio_t[j];
    }
    atomn_2=nions-atomn_1;

    int start = 0;
    m=0; n=0;
    for(int i=0; i<ga_info.ntype; i++){
      if(i!=0)
        start += ga_info.atom_type_max[i-1];
      for(int j=0; j<ratio_t[i]; j++){
        newpos[j+start] = posrot1[order1[j+start]];
        newpos[j+start].ityp = posrot1[order1[j+start]].ityp;
        postmp1[m] = posrot1[order1[j+start]];
        postmp1[m].ityp = posrot1[order1[j+start]].ityp;
        m++;
      }
      for(int k=ratio_t[i]; k<ga_info.atom_type_max[i]; k++){
        newpos[k+start] = posrot2[order2[k+start]];
        newpos[k+start].ityp = posrot2[order2[k+start]].ityp;
        postmp2[n] = posrot2[order2[k+start]];
        postmp2[n].ityp = posrot2[order2[k+start]].ityp;
        n++;
      }
    }

    judge=isgoodmating(m, n, postmp1, postmp2, ga_info.rcut);
    trial++;
  }while(trial<5 && judge<0);

  // if(judge==0)   successful mating
  if(judge==1){  //successful mating by shifting along z
    int start = 0;
    m=0; n=0;
    for(int i=0; i<ga_info.ntype; i++){
      if(i!=0)
        start += ga_info.atom_type_max[i-1];
      for(int j=0; j<ratio_t[i]; j++){
        newpos[j+start] = postmp1[m];
        m++;
      }
      for(int k=ratio_t[i]; k<ga_info.atom_type_max[i]; k++){
        newpos[k+start] = postmp2[n];
        n++;
      }
    }
  }
  if(judge<0)   //failed mating
    mating_p=-1.0;
  delete[] posz1;
  delete[] posz2;
  delete[] ratio_t;
  delete[] order1;
  delete[] order2;
  delete[] postmp1;
  delete[] postmp2;
  delete[] posop1;
  delete[] posop2;
  delete[] posrot1;
  delete[] posrot2;
  return mating_p;
}

//gather the atoms
void gather_atoms(Posion *posop, const Posion *pos, Posion *latt, int nions){
  double tmp[3], tmpdis, best[3];
  posop[0] = pos[0];
  posop[0].ityp = pos[0].ityp;
  double *dis;
  dis = new double[nions];
  for(int i=0; i<nions; i++)
    dis[i] = pow(pos[i].x-posop[0].x,2)+pow(pos[i].y-posop[0].y,2)+pow(pos[i].z-posop[0].z,2);
  for(int i=1; i<nions; i++){
    best[0]=pos[i].x;
    best[1]=pos[i].y;
    best[2]=pos[i].z;
    for(int n1=-1; n1<=1; n1++){
      for(int n2=-1; n2<=1; n2++){
        for(int n3=-1; n3<=1; n3++){
          tmp[0]=pos[i].x+n1*latt[0].x+n2*latt[1].x+n3*latt[2].x;
          tmp[1]=pos[i].y+n1*latt[0].y+n2*latt[1].y+n3*latt[2].y;
          tmp[2]=pos[i].z+n1*latt[0].z+n2*latt[1].z+n3*latt[2].z;
          tmpdis=pow(tmp[0]-posop[0].x,2)+pow(tmp[1]-posop[0].y,2)+pow(tmp[2]-posop[0].z,2);
          if(tmpdis<dis[i]){
            best[0]=tmp[0]; best[1]=tmp[1]; best[2]=tmp[2];
            dis[i]=tmpdis;
          }
        }
      }
    }
    posop[i].x=best[0];
    posop[i].y=best[1];
    posop[i].z=best[2];
    posop[i].ityp = pos[i].ityp;
  }
  delete[] dis;
}

//center of mass
void centerofmass(Posion *pos, double *cofm, double nions){
  double tmp[3];
  for(int i=0; i<3; i++) tmp[i]=0;
  for(int i=0; i<nions; i++){
    tmp[0] = tmp[0]+pos[i].x;
    tmp[1] = tmp[1]+pos[i].y;
    tmp[2] = tmp[2]+pos[i].z;
  }
  cofm[0] = tmp[0]/nions;
  cofm[1] = tmp[1]/nions;
  cofm[2] = tmp[2]/nions;
}

//randomly rotate the clusters
void rot(Posion *pos, Posion *posrot, double *cofm, int nions){
  double theta, costheta, sintheta, psi, cospsi, sinpsi, phi, cosphi, sinphi;
  double random;
  const double Pi=3.1415926;
  double rot_m[3][3];
  //random numbers for angles theta, psi, phi
  random=RandomDouble(0.0, 1.0);
  theta=Pi*random;
  costheta=cos(theta);  sintheta=sin(theta);
  random=RandomDouble(0.0, 1.0);
  psi=Pi*random;
  cospsi=cos(psi);  sinpsi=sin(psi);
  random=RandomDouble(0.0, 1.0);
  phi=Pi*random;
  cosphi=cos(phi);  sinphi=sin(phi);

  rot_m[0][0] =  cospsi*cosphi-costheta*sinphi*sinpsi;
  rot_m[1][0] = -sinpsi*cosphi-costheta*sinphi*cospsi;
  rot_m[2][0] =  sintheta*sinphi;
  rot_m[0][1] =  cospsi*sinphi+costheta*cosphi*sinpsi;
  rot_m[1][1] = -sinpsi*sinphi+costheta*cosphi*cospsi;
  rot_m[2][1] = -sintheta*cosphi;
  rot_m[0][2] =  sinpsi*sintheta;
  rot_m[1][2] =  cospsi*sintheta;
  rot_m[2][2] =  costheta;

  for(int i=0; i<nions; i++){
    posrot[i].x = (pos[i].x-cofm[0])*rot_m[0][0] + (pos[i].y-cofm[1])*rot_m[0][1] + (pos[i].z-cofm[2])*rot_m[0][2];
    posrot[i].y = (pos[i].x-cofm[0])*rot_m[1][0] + (pos[i].y-cofm[1])*rot_m[1][1] + (pos[i].z-cofm[2])*rot_m[1][2];
    posrot[i].z = (pos[i].x-cofm[0])*rot_m[2][0] + (pos[i].y-cofm[1])*rot_m[2][1] + (pos[i].z-cofm[2])*rot_m[2][2];
    posrot[i].ityp = pos[i].ityp;
  }
}

//sorting
void sort(double *z, int *order, int n){
  double *tmp;
  tmp = new double[n];
  for(int i=0; i<n; i++) {order[i]=0; tmp[i]=0;}
  for(int i=0; i<n; i++)
    for(int j=0; j<n; j++)
      if(z[i]>z[j] || (z[i]==z[j]&&i<j))tmp[i]++;
  int j;
  for(int i=0; i<n; i++){
    for(j=0; j<n; j++)
      if(tmp[j]==i)break;
    order[i]=j;
  }
  delete[] tmp;
}

//check if the structure from mating is good or not
//assume that the problem only comes from atoms between 
//two parents (near the boundary)
int isgoodmating(int m, int n, Posion *pos1, Posion *pos2, double rcut){
  double dis=0.0, disz=0.0, tmp, rannum, shift;
  double mindis = 9999.0, mindisz=9999.0;
  int good_bad;
  for(int i=0; i<m; i++){
    for(int j=0; j<n; j++){
        tmp=pow(pos1[i].x-pos2[j].x,2)+pow(pos1[i].y-pos2[j].y,2)+pow(pos1[i].z-pos2[j].z,2);
        dis=sqrt(tmp);
        if(dis<mindis) mindis = dis;
        disz=pos2[j].z-pos1[i].z;
        if(disz<mindisz) mindisz = disz;
    }
  }

//cout << "rcut = " << rcut << endl;
  if(mindis>rcut && mindisz < 2*rcut){
//  cout << "mating succeeded ..." << endl;
    good_bad=0;
  }
  if(mindis<=rcut){    //if some atoms too close to each other
    rannum = RandomDouble(0.0, 1.0);
    if(rannum<0.6){
      shift = 1.2*rcut-mindis;
//    cout << "shift along -z .. " <<  shift << endl;
      for(int i=0; i<m; i++) pos1[i].z = pos1[i].z - shift;
      //check again, if two parts have overlap
      double newmindis = 9999.0;
      for(int i=0; i<m; i++){
        for(int j=0; j<n; j++){
            tmp=pow(pos1[i].x-pos2[j].x,2)+pow(pos1[i].y-pos2[j].y,2)+pow(pos1[i].z-pos2[j].z,2);
            dis=sqrt(tmp);
            if(dis < newmindis) newmindis=dis;
        }
      }
//    cout << " newmindis = " << newmindis << endl;
      if(newmindis<=rcut){
//      cout << "shift failed .." << endl;
        good_bad=-1;
      }
      else good_bad=1;
    }
    else good_bad=-1;
  }
  if(mindisz>2*rcut){
    rannum = RandomDouble(0.0, 1.0);
    if(rannum<0.5){
      shift = mindisz-1.2*rcut; 
//    cout << "shift along z .." << shift << endl;
      for(int i=0; i<m; i++) pos1[i].z = pos1[i].z + shift;
      good_bad=1;
    }
    else good_bad=-1;
  }
  return good_bad;
}

